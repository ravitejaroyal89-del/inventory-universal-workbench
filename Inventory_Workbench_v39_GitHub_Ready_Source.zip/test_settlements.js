const assert=require('node:assert/strict');const {calculate}=require('./settlements');
const tx=[{reference:'R1',date:'2026-10-01',item:'A',location:'WH1',type:'RECEIPT',qty:10,rate:100},{reference:'S1',date:'2026-10-05',item:'A',location:'WH1',type:'COGS',qty:4},{reference:'S2',date:'2026-10-08',item:'A',location:'WH1',type:'CONSUMPTION',qty:2}];
const adj=[{receipt_reference:'R1',amount:100,effective_date:'2026-10-01',posting_date:'2026-10-25'}];let n=0;function test(name,fn){fn();n++;console.log('PASS',name)}
test('moving allocation',()=>{let r=calculate(tx,adj,'moving','2026-10-31');assert.equal(r.ok,true);assert.equal(r.summary.cogs,40);assert.equal(r.summary.consumption,20);assert.equal(r.summary.closingAdjustment,40)});
test('fifo allocation',()=>{let r=calculate(tx,adj,'fifo','2026-10-31');assert.equal(r.ok,true);assert.equal(r.summary.closingAdjustment,40)});
test('posting cut-off',()=>{let r=calculate(tx,adj,'moving','2026-10-20');assert.equal(r.summary.totalAdjustment,0)});
test('invalid reference blocked',()=>{let r=calculate(tx,[{...adj[0],receipt_reference:'INVALID'}]);assert.equal(r.ok,false)});
test('negative stock blocked',()=>{let r=calculate([...tx,{reference:'S3',date:'2026-10-10',item:'A',location:'WH1',type:'COGS',qty:8}],adj);assert.equal(r.ok,false)});
test('invalid financial date blocked',()=>{let r=calculate(tx,[{...adj[0],effective_date:'2026-10-02'}]);assert.equal(r.ok,false)});
test('zero adjustment balanced',()=>{let r=calculate(tx,[]);assert.equal(r.ok,true);assert.equal(r.summary.allocationVariance,0)});
console.log(`${n} settlement tests passed`)
