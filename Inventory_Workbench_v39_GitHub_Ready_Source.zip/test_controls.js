const assert=require('node:assert/strict'),c=require('./controls');let n=0;function t(name,fn){fn();n++;console.log('PASS',name)}
t('movement mapping',()=>assert.equal(c.mapping([{Date:'2026-10-01',Item:'A',WH:'X',Code:'GRN',Qty:2,Rate:10}],{date:'Date',item:'Item',location:'WH',type:'Code',qty:'Qty',rate:'Rate'}).rows[0].type,'RECEIPT'));
t('unmapped movement flagged',()=>assert.equal(c.mapping([{Date:'2026-10-01',Item:'A',WH:'X',Code:'999'}],{date:'Date',item:'Item',location:'WH',type:'Code'}).errors.length,1));
t('NRV write-down',()=>assert.equal(c.nrv([{item:'A',location:'X',qty:10,value:1000}],[{item:'A',location:'X',nrv_per_unit:90}]).rows[0].write_down,100));
t('NRV reversal capped by historical allowance',()=>{let x=c.nrv([{item:'A',location:'X',qty:10,value:1000}],[{item:'A',location:'X',nrv_per_unit:120}],[{item:'A',location:'X',cumulative_write_down:80}]);assert.equal(x.rows[0].reversal,80);assert.equal(x.rows[0].net_value,1000)});
t('NRV missing flagged',()=>assert.equal(c.nrv([{item:'A',location:'X',qty:1,value:10}],[]).errors.length,1));
t('ERP reconciliation',()=>assert.equal(c.reconcile([{item:'A',location:'X',qty:1,value:10}],[{item:'A',location:'X',qty:1,value:11}])[0].status,'REVIEW'));
t('maker cannot self approve',()=>assert.throws(()=>c.approve({maker:'a',blockingErrors:0},'a')));
t('blocking error prevents approval',()=>assert.throws(()=>c.approve({maker:'a',blockingErrors:1},'b')));
t('independent checker approval',()=>assert.equal(c.approve({maker:'a',blockingErrors:0},'b').status,'APPROVED'));
t('audit sequence',()=>assert.equal(c.audit(c.audit([],'a','IMPORT','1'),'b','REVIEW','2')[1].sequence,2));
console.log(n+' control tests passed');
