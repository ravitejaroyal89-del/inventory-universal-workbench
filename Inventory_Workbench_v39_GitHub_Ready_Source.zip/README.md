# Inventory Workbench v26 — streamlined application

## Active application
- `react/` — responsive React + TypeScript UI
- `node_backend/` — Node.js + TypeScript API, currently calculation endpoint only
- `python_engine/` — independent FIFO/moving-average reference calculator
- `server.py`, `verified_gate.py`, `migrations/` — legacy FastAPI approval backend and its dependencies (retained during migration)
- `test_*.py`, `validation/`, `fixtures/` — accounting and security regression tests

## Cleanup performed
- Removed obsolete standalone HTML interface from the active root and archived it at `archive/legacy_frontend/`.
- Moved historical release notes and generated reconciliation outputs into `archive/`.
- Removed compiled Python caches and corrected obsolete Version 24 / FastAPI-only UI labels.
- Removed broken legacy-inspector navigation from the React screen.
- Preserved accounting logic, evidence, tests, approvals and original source data outputs.

## Limitations
The Node backend has **not** migrated authentication, entity access, maker–checker approvals or audit trails. The React UI currently expects those endpoints on the legacy FastAPI backend; point its `/api` proxy at FastAPI for approvals, or use Node for calculation-only. Do not combine the two as if a single fully migrated backend exists. Production build, browser E2E, PostgreSQL live testing and independent Ind AS certification remain outstanding.

## Run independent Python engine
`echo '{"action":"calculate","method":"moving","rows":[{"date":"2026-10-01","item":"A","location":"C1","type":"OPEN","qty":10,"rate":5}]}' | python3 python_engine/cli.py`
