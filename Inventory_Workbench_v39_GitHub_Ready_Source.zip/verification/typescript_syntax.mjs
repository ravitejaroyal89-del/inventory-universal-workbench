import ts from '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let failures=0,files=0;
for(const dir of ['react/src','node_backend/src'])for(const name of fs.readdirSync(path.join(root,dir))){if(!/\.tsx?$/.test(name))continue;files++;const file=path.join(root,dir,name);const output=ts.transpileModule(fs.readFileSync(file,'utf8'),{fileName:file,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}});for(const d of output.diagnostics||[]){if(d.category===ts.DiagnosticCategory.Error){failures++;console.error(name,ts.flattenDiagnosticMessageText(d.messageText,' '))}}}
console.log(`${files} TypeScript/TSX files syntax-checked; ${failures} syntax errors`);if(failures)process.exitCode=1;
