"""Run against a deployed or locally served React frontend and Node API.
Usage: BASE_URL=http://127.0.0.1:5173 python verification/browser_e2e.py
Requires a reachable site and Playwright Chromium.
"""
import os
from playwright.sync_api import sync_playwright
URL=os.getenv('BASE_URL','http://127.0.0.1:5173')
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True)
    for label,width,height in [('mobile',390,844),('desktop',1440,900)]:
        page=browser.new_page(viewport={'width':width,'height':height})
        page.goto(URL,wait_until='networkidle',timeout=30000)
        page.get_by_role('heading',name='Overview').wait_for()
        for module in ['Import & Valuation','Intercompany Reconciliation','IC Financial','Approvals','Administration']:
            page.get_by_role('navigation',name='Modules').get_by_role('button',name=module).click()
            page.get_by_role('heading',name=module,exact=True).wait_for()
        print(f'PASS {label} navigation')
        page.close()
    browser.close()
