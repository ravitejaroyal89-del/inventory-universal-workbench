#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m pytest -q
(cd react && npm ci --no-audit --no-fund 2>/dev/null || npm install --no-audit --no-fund)
(cd node_backend && npm ci --no-audit --no-fund 2>/dev/null || npm install --no-audit --no-fund)
(cd react && npm run build)
(cd node_backend && npm run check)
if [ -d node_backend/test ]; then (cd node_backend && npm test); fi
printf '\nFrontend built at react_dist. API browser E2E and PostgreSQL/UAT require separate live environment verification.\n'
