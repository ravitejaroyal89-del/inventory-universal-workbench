from decimal import Decimal
from pathlib import Path
from tempfile import TemporaryDirectory
from cogs_analysis_v15 import dec,analyse

def test_decimal_invalid():
 assert dec('#DIV/0!') is None
 assert dec('1,250.50')==Decimal('1250.50')

def test_real_data():
 with TemporaryDirectory() as d:
  result=analyse(Path(__file__).parent.parent,d)
  assert result['centres_sep']==66
  assert result['centres_oct']==66
  assert result['statuses']['OCT_RECONCILED']==65
  assert result['statuses']['OCT_REVIEW_TOTAL']==1
  assert (Path(d)/'cogs_centre_comparison.csv').exists()
