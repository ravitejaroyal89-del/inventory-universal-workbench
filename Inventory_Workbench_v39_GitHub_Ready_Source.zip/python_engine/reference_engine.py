"""Independent Python reference valuation for simple FIFO/moving-average inventories.
Not a substitute for full Ind AS 2 review or complex ERP settlement matching.
"""
from decimal import Decimal, InvalidOperation
from collections import defaultdict
from datetime import date

IN={'OPEN','PURCHASE','RECEIPT','RETURN_IN','ADJUST_IN'}
OUT={'ISSUE','COGS','CONSUMPTION','RETURN_OUT','ADJUST_OUT'}

def D(v):
 try:
  x=Decimal(str(v))
  if not x.is_finite(): raise ValueError('Non-finite number')
  return x
 except (InvalidOperation, TypeError): raise ValueError('Invalid decimal')

def calculate(rows, method='moving'):
 if method not in ('fifo','moving'): raise ValueError('Unsupported reference method')
 if not isinstance(rows,list) or len(rows)>100000: raise ValueError('Invalid transaction count')
 ordered=[]
 for i,r in enumerate(rows):
  if not isinstance(r,dict): raise ValueError('Invalid row')
  t=str(r.get('type','')).upper(); item=str(r.get('item','')).strip(); loc=str(r.get('location','')).strip()
  if t not in IN|OUT or not item or not loc: raise ValueError(f'Unsupported or incomplete row {i+1}')
  dt=date.fromisoformat(str(r.get('date',''))[:10]); q=D(r.get('qty'))
  if q<=0: raise ValueError('Quantity must be positive')
  rate=D(r.get('rate')) if t in IN else None
  if rate is not None and rate<0: raise ValueError('Negative rate')
  ordered.append((dt,i,t,item,loc,q,rate))
 ordered.sort(key=lambda x:(x[0],0 if x[2]=='OPEN' else 1,x[1]))
 states=defaultdict(lambda:{'qty':Decimal(0),'value':Decimal(0),'layers':[]})
 totals=defaultdict(Decimal)
 ledger=[]
 for dt,i,t,item,loc,q,rate in ordered:
  s=states[(item,loc)]
  if t in IN:
   cost=q*rate;s['qty']+=q;s['value']+=cost;s['layers'].append([q,rate]);totals['opening' if t=='OPEN' else 'receipts']+=cost
  else:
   if s['qty']<q: raise ValueError(f'Negative stock: {item}/{loc} at row {i+1}')
   if method=='moving': cost=q*s['value']/s['qty']
   else:
    left=q;cost=Decimal(0)
    while left:
     layer=s['layers'][0];take=min(left,layer[0]);cost+=take*layer[1];left-=take;layer[0]-=take
     if not layer[0]:s['layers'].pop(0)
   s['qty']-=q;s['value']-=cost
   if not s['qty']:s['value']=Decimal(0)
   category='consumption' if t=='CONSUMPTION' else 'returnsOut' if t=='RETURN_OUT' else 'adjustmentsOut' if t=='ADJUST_OUT' else 'cogs'
   totals[category]+=cost
  ledger.append({'row':i+2,'date':dt.isoformat(),'item':item,'location':loc,'type':t,'qty':str(q),'movement_cost':str(cost),'closing_qty':str(s['qty'])})
 valuation=[{'item':item,'location':loc,'qty':str(s['qty']),'value':str(s['value'])} for (item,loc),s in sorted(states.items())]
 totals['closing']=sum((s['value'] for s in states.values()),Decimal(0))
 totals['rollforwardDifference']=totals['opening']+totals['receipts']-totals['cogs']-totals['consumption']-totals['returnsOut']-totals['adjustmentsOut']-totals['closing']
 if abs(totals['rollforwardDifference'])>Decimal('.01'):raise ValueError('Roll-forward failed')
 return {'method':method,'valuation':valuation,'ledger':ledger,'metrics':{k:str(v) for k,v in totals.items()},'scope':'reference_simple_fifo_moving'}
