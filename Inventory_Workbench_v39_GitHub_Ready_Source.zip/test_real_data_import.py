from real_data_import import profile,PROFILES
from pathlib import Path
ROOT=Path('/mnt/data')
def test_profiles_available():assert len(PROFILES)>=6
def test_closing_stock():
 p=profile(ROOT/'Consol_Closing_Stock_25Oct2026_All_Entities.xlsx')
 assert p['detected_profile']=='closing_stock' and p['rows']>4000 and not p['missing_required_columns']
def test_grn():
 p=profile(ROOT/'grn consolidation register sep to oct 2026.xlsx')
 assert p['detected_profile']=='goods_receipts' and p['rows']>2000
def test_purchase():
 p=profile(ROOT/'purchase register sep to 0ct 2026.xlsx')
 assert p['detected_profile']=='purchase_orders' and p['rows']>2000
def test_ivr():
 p=profile(ROOT/'Consol_IVR_Inventory_Oct_2026_All_Entities (2).xlsx')
 assert p['detected_profile']=='inventory_movements' and p['rows']>100000
