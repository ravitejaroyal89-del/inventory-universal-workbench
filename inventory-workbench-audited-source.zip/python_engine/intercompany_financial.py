"""Independent evidence-based intercompany financial reconciliation. No automatic journals."""
from collections import defaultdict
from decimal import Decimal, InvalidOperation

KINDS={'SALES_INVOICE','PURCHASE_INVOICE','AR_OPEN','AP_OPEN','AR_SETTLEMENT','AP_SETTLEMENT','INVENTORY_RECEIPT','INVENTORY_ISSUE','COGS','CLOSING_INVENTORY'}

def money(x, field):
    try: v=Decimal(str(x))
    except (InvalidOperation,ValueError,TypeError): raise ValueError(f'Invalid {field}')
    if not v.is_finite(): raise ValueError(f'Non-finite {field}')
    return v

def fmt(x): return format(x.quantize(Decimal('.01')),'f')

def reconcile_financial(records, policy=None):
    if not isinstance(records,list) or len(records)>100000: raise ValueError('records must be a list of up to 100000 lines')
    policy=policy or {}
    if not isinstance(policy,dict): raise ValueError('Invalid policy')
    currency=str(policy.get('currency','INR')).strip().upper()
    if not currency: raise ValueError('Currency required')
    tolerance=money(policy.get('tolerance','0.01'),'tolerance')
    if tolerance<0: raise ValueError('Negative tolerance')
    groups=defaultdict(list)
    seen=set()
    for i,r in enumerate(records,1):
        if not isinstance(r,dict): raise ValueError(f'Row {i} must be an object')
        kind=str(r.get('type','')).strip().upper()
        if kind not in KINDS: raise ValueError(f'Row {i}: unsupported type {kind}')
        keys=('selling_entity','buying_entity','item','intercompany_order')
        if any(not str(r.get(k,'')).strip() for k in keys): raise ValueError(f'Row {i}: missing entity/item/order')
        if str(r.get('currency','')).strip().upper()!=currency: raise ValueError(f'Row {i}: currency mismatch or missing currency; convert externally using approved FX policy')
        document=str(r.get('document_no','')).strip()
        if not document: raise ValueError(f'Row {i}: document_no required for traceability')
        unique=(kind,document,str(r.get('line_no','1')),*(str(r[k]).strip().upper() for k in keys))
        if unique in seen: raise ValueError(f'Row {i}: duplicate document line {document}')
        seen.add(unique)
        amount=money(r.get('amount'),'amount')
        quantity=money(r.get('quantity','0'),'quantity')
        if quantity<0: raise ValueError(f'Row {i}: negative quantity not supported; normalize returns separately')
        cost=money(r.get('cost','0'),'cost')
        if cost<0: raise ValueError(f'Row {i}: negative cost not supported')
        key=tuple(str(r[k]).strip().upper() for k in keys)
        groups[key].append({'type':kind,'amount':amount,'quantity':quantity,'cost':cost,'document_no':document,'date':str(r.get('date',''))})
    output=[]; exception_counts=defaultdict(int)
    for key,lines in sorted(groups.items()):
        by=defaultdict(list)
        for r in lines: by[r['type']].append(r)
        total=lambda k,f='amount':sum((x[f] for x in by[k]),Decimal(0))
        issues=[]
        def flag(code,detail):
            issues.append({'code':code,'detail':detail});exception_counts[code]+=1
        sales=total('SALES_INVOICE'); purchases=total('PURCHASE_INVOICE')
        if not by['SALES_INVOICE'] or not by['PURCHASE_INVOICE']: flag('MISSING_INVOICE_SIDE','Sales and purchase invoices must both be supplied')
        elif abs(sales-purchases)>tolerance: flag('INVOICE_AMOUNT_DIFFERENCE',fmt(sales-purchases))
        ar=total('AR_OPEN'); ap=total('AP_OPEN')
        if not by['AR_OPEN'] or not by['AP_OPEN']: flag('MISSING_OPEN_BALANCE_SIDE','AR and AP open balance extracts required')
        elif abs(ar-ap)>tolerance: flag('AR_AP_DIFFERENCE',fmt(ar-ap))
        # Settlement lines are disclosed as evidence, never subtracted from already-open balances.
        arsettle=total('AR_SETTLEMENT'); apsettle=total('AP_SETTLEMENT')
        if (by['AR_SETTLEMENT'] or by['AP_SETTLEMENT']) and abs(arsettle-apsettle)>tolerance:flag('SETTLEMENT_DIFFERENCE',fmt(arsettle-apsettle))
        issue_qty=total('INVENTORY_ISSUE','quantity'); receipt_qty=total('INVENTORY_RECEIPT','quantity')
        if by['INVENTORY_ISSUE'] and by['INVENTORY_RECEIPT'] and issue_qty!=receipt_qty:flag('IN_TRANSIT_OR_QTY_DIFFERENCE',str(issue_qty-receipt_qty))
        elif bool(by['INVENTORY_ISSUE'])!=bool(by['INVENTORY_RECEIPT']):flag('MISSING_INVENTORY_MOVEMENT','One inventory movement side is missing')
        issue_cost=total('INVENTORY_ISSUE','cost'); cogs=total('COGS')
        if by['INVENTORY_ISSUE'] and by['COGS'] and abs(issue_cost-cogs)>tolerance:flag('ISSUE_COGS_DIFFERENCE',fmt(issue_cost-cogs))
        elif bool(by['INVENTORY_ISSUE'])!=bool(by['COGS']):flag('MISSING_COST_EVIDENCE','Both inventory issue cost and COGS required')
        # Unrealized margin: requires explicit matched unsold units and cost basis. Never infer from total invoices.
        elimination=None
        closing=by['CLOSING_INVENTORY']
        if closing:
            if not by['SALES_INVOICE'] or not by['INVENTORY_ISSUE'] or issue_qty<=0:
                flag('PROFIT_EVIDENCE_INCOMPLETE','Missing matched selling price or seller cost')
            elif (by['SALES_INVOICE'][0]['quantity']>0 and by['SALES_INVOICE'][0]['quantity']!=issue_qty) or (by['INVENTORY_RECEIPT'] and receipt_qty!=issue_qty):
                flag('PROFIT_EVIDENCE_INCOMPLETE','Invoice or receipt quantities do not match the costed transfer; allocate lots before proposing profit')
            elif len(closing)!=1 or len(by['INVENTORY_ISSUE'])!=1 or len(by['SALES_INVOICE'])!=1:
                flag('PROFIT_EVIDENCE_INCOMPLETE','Multiple lines need lot-level allocation and matching')
            else:
                unsold=closing[0]['quantity']
                if unsold>issue_qty:flag('UNSOLD_QTY_EXCEEDS_TRANSFER','Closing units exceed matched issued units')
                elif unsold>0:
                    unit_price=sales/issue_qty; unit_cost=issue_cost/issue_qty
                    margin=(unit_price-unit_cost)*unsold
                    if margin<0:flag('INTERCOMPANY_LOSS','Negative margin; investigate impairment and valuation')
                    else:
                        elimination={'unrealised_profit':fmt(margin),'unsold_quantity':str(unsold),'seller_unit_cost':fmt(unit_cost),'transfer_unit_price':fmt(unit_price),'status':'PROPOSED_ONLY','note':'Assumes matched unsold units are from this transfer and amounts exclude taxes; verify ownership, tax, FX, NRV and consolidation policy before posting'}
        output.append({'selling_entity':key[0],'buying_entity':key[1],'item':key[2],'intercompany_order':key[3],
          'currency':currency,'sales_invoiced':fmt(sales),'purchase_invoiced':fmt(purchases),'ar_open':fmt(ar),'ap_open':fmt(ap),
          'ar_settlements':fmt(arsettle),'ap_settlements':fmt(apsettle),'inventory_issue_qty':str(issue_qty),'inventory_receipt_qty':str(receipt_qty),
          'seller_issue_cost':fmt(issue_cost),'cogs_recorded':fmt(cogs),'proposed_elimination':elimination,
          'exceptions':issues,'status':'EXCEPTION' if issues else 'EVIDENCE_MATCHED','source_documents':sorted({r['document_no'] for r in lines})})
    return {'groups':output,'summary':{'groups':len(output),'matched':sum(x['status']=='EVIDENCE_MATCHED' for x in output),'exceptions':sum(x['status']=='EXCEPTION' for x in output),'exception_types':dict(exception_counts)},
      'policy':{'currency':currency,'tolerance':fmt(tolerance)},'posting_allowed':False,
      'limitations':['Same-currency signed, normalized evidence required; no implicit FX or tax conversion','AR_OPEN/AP_OPEN are point-in-time open balances; settlements are separate and not double-counted','Costing requires independently verified seller issue cost and COGS; this engine does not derive actual ERP cost','Profit proposal assumes unique matched transfer and unsold stock; no journal is posted','Consolidation, NRV, ownership and entity-level access require independent review']}
