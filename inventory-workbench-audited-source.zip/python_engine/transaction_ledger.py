"""Inventory-only, deterministic transaction reference model.

Supports FIFO and perpetual moving average by item/location/currency; no ERP posting.
Transactions are chronological; a transfer carries source cost into destination.
"""
from collections import defaultdict, deque
from decimal import Decimal
from inventory_controls import dec

RECEIPTS={'OPENING','PURCHASE_RECEIPT','SALES_RETURN','TRANSFER_IN','ADJUSTMENT_IN'}
ISSUES={'SALE_ISSUE','PURCHASE_RETURN','TRANSFER_OUT','ADJUSTMENT_OUT'}

def calculate_ledger(records, method='moving'):
    if method not in ('moving','fifo'): raise ValueError('Unsupported costing method')
    if not isinstance(records,list) or not records or len(records)>100000: raise ValueError('Invalid ledger records')
    state=defaultdict(lambda:{'qty':Decimal(0),'value':Decimal(0),'layers':deque()})
    ids=set(); results=[]; totals=defaultdict(Decimal); previous=None
    used_transfers=set()
    transfers={}  # transfer reference -> cost carried from source issue
    for n,r in enumerate(records,1):
        if not isinstance(r,dict): raise ValueError(f'Row {n}: invalid transaction')
        txid=str(r.get('transaction_id','')).strip()
        item=str(r.get('item','')).strip(); location=str(r.get('location','')).strip()
        entity=str(r.get('entity','')).strip(); currency=str(r.get('currency','')).strip()
        kind=str(r.get('type','')).strip().upper(); day=str(r.get('date','')).strip()
        if not all((txid,item,location,entity,currency,day)) or len(day)!=10: raise ValueError(f'Row {n}: missing required identifiers/date')
        from datetime import date
        try: date.fromisoformat(day)
        except ValueError: raise ValueError(f'Row {n}: invalid date')
        if previous is not None and day<previous: raise ValueError('Transactions must be date-ordered')
        previous=day
        if txid in ids: raise ValueError(f'Duplicate transaction ID: {txid}')
        ids.add(txid)
        if kind not in RECEIPTS|ISSUES: raise ValueError(f'Row {n}: unsupported transaction type')
        if kind in {'TRANSFER_IN','TRANSFER_OUT'} and not str(r.get('transfer_ref','')).strip():
            raise ValueError(f'Row {n}: transfer_ref required for every transfer')
        qty=dec(r.get('quantity'))
        if qty<=0: raise ValueError(f'Row {n}: quantity must be positive')
        key=(entity,item,location,currency)
        s=state[key]; amount=Decimal(0)
        if kind in RECEIPTS:
            transfer_ref=str(r.get('transfer_ref','')).strip()
            if kind=='TRANSFER_IN' and transfer_ref:
                if transfer_ref not in transfers: raise ValueError(f'Row {n}: transfer source not found or out of order')
                t=transfers.pop(transfer_ref)
                if (t['entity'],t['item'],t['currency'])!=(entity,item,currency) or t['quantity']!=qty or t['location']==location:
                    raise ValueError(f'Row {n}: transfer destination mismatch')
                cost=t['amount']/qty
            else:
                cost=dec(r.get('unit_cost'))
            if cost<0: raise ValueError(f'Row {n}: negative unit cost')
            amount=qty*cost
            s['qty']+=qty;s['value']+=amount
            if method=='fifo': s['layers'].append([qty,cost])
            totals['receipts']+=amount
        else:
            if qty>s['qty']: raise ValueError(f'Row {n}: insufficient stock; negative stock blocked')
            if method=='moving':
                amount=qty*(s['value']/s['qty'])
            else:
                remaining=qty
                while remaining:
                    layer_qty,layer_cost=s['layers'][0]
                    taken=min(layer_qty,remaining)
                    amount+=taken*layer_cost
                    remaining-=taken;layer_qty-=taken
                    if layer_qty==0:s['layers'].popleft()
                    else:s['layers'][0][0]=layer_qty
            s['qty']-=qty;s['value']-=amount
            if s['qty']==0:s['value']=Decimal(0)
            totals['issues']+=amount
            if kind=='SALE_ISSUE':totals['cogs']+=amount
            if kind=='TRANSFER_OUT' and str(r.get('transfer_ref','')).strip():
                ref=str(r['transfer_ref']).strip()
                if ref in used_transfers: raise ValueError('Duplicate transfer reference')
                used_transfers.add(ref)
                transfers[ref]={'entity':entity,'item':item,'currency':currency,'location':location,'quantity':qty,'amount':amount}
        results.append({'transaction_id':txid,'type':kind,'entity':entity,'item':item,'location':location,'currency':currency,'quantity':str(qty),'transaction_value':str(amount),'closing_quantity':str(s['qty']),'closing_value':str(s['value'])})
    if transfers: raise ValueError('Unmatched transfer-out references: '+', '.join(sorted(transfers)))
    balances=[{'entity':e,'item':i,'location':l,'currency':c,'quantity':str(s['qty']),'value':str(s['value'])} for (e,i,l,c),s in sorted(state.items())]
    return {'method':method,'transactions':results,'balances':balances,'total_receipts':str(totals['receipts']),'total_issues':str(totals['issues']),'sale_cogs':str(totals['cogs']),'journal_posted':False,'limitations':['Transfer references must be ordered out then in with matching entity/item/currency/quantity; transfer handling is not an ERP shipment/receipt workflow','Cost adjustments, landed cost, settlements, UOM conversion and multi-currency revaluation require separate policies','Use ERP financial-posting and cutoff policy before reconciling to GL']}
