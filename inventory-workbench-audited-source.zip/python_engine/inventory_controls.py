"""Inventory-only controls; reference checks, not ERP settlement replacement."""
from decimal import Decimal, InvalidOperation
from collections import defaultdict
from datetime import date

def dec(x):
    try:
        v=Decimal(str(x))
        if not v.is_finite(): raise ValueError('Non-finite value')
        return v
    except (InvalidOperation,TypeError): raise ValueError('Invalid numeric value')

def reconcile_stock(records, tolerance='0.01'):
    if not isinstance(records,list) or len(records)>100000: raise ValueError('Invalid stock records')
    tol=dec(tolerance)
    if tol<0: raise ValueError('Negative tolerance')
    out=[]
    for i,r in enumerate(records):
        if not isinstance(r,dict): raise ValueError('Invalid record')
        item=str(r.get('item','')).strip();location=str(r.get('location','')).strip()
        if not item or not location: raise ValueError('Missing item/location')
        book=dec(r.get('book_qty'));physical=dec(r.get('physical_qty'))
        if book<0 or physical<0: raise ValueError('Negative stock not supported')
        rate=dec(r.get('unit_cost'))
        if rate<0: raise ValueError('Negative unit cost')
        diff=physical-book
        out.append({'row':i+1,'item':item,'location':location,'book_qty':str(book),'physical_qty':str(physical),'difference_qty':str(diff),'difference_value':str(diff*rate),'status':'MATCH' if abs(diff)<=tol else 'EXCEPTION','action':'INVESTIGATE_NOT_POST'})
    return {'records':out,'exceptions':sum(r['status']=='EXCEPTION' for r in out),'journal_posted':False}

def nrv_test(records):
    if not isinstance(records,list) or len(records)>100000: raise ValueError('Invalid NRV records')
    out=[];total=Decimal(0)
    for i,r in enumerate(records):
        if not isinstance(r,dict) or not str(r.get('item','')).strip(): raise ValueError('Missing item')
        qty=dec(r.get('qty'));cost=dec(r.get('unit_cost'));selling=dec(r.get('selling_price'));completion=dec(r.get('completion_cost',0));selling_cost=dec(r.get('selling_cost',0));previous=dec(r.get('previous_write_down',0))
        if min(qty,cost,selling,completion,selling_cost,previous)<0: raise ValueError('Negative inputs not supported')
        if previous>qty*cost: raise ValueError('Previous write-down cannot exceed historical cost for these units')
        nrv=max(Decimal(0),selling-completion-selling_cost)
        required=max(Decimal(0),(cost-nrv)*qty)
        movement=required-previous
        total+=movement
        out.append({'item':str(r['item']),'nrv_per_unit':str(nrv),'cost_total':str(qty*cost),'nrv_total':str(qty*nrv),'required_write_down':str(required),'write_down_movement':str(movement),'classification':'WRITE_DOWN' if movement>0 else 'REVERSAL_REVIEW' if movement<0 else 'NONE'})
    return {'records':out,'net_proposed_write_down':str(total),'journal_posted':False,'warning':'Reversals require historical cost cap and item-level prior-period review; proposed only.'}

def inventory_rollforward(records):
    if not isinstance(records,list) or len(records)>100000: raise ValueError('Invalid records')
    result=[]
    for r in records:
        if not isinstance(r,dict): raise ValueError('Invalid row')
        item=str(r.get('item','')).strip();location=str(r.get('location','')).strip()
        if not item or not location: raise ValueError('Missing item/location')
        opening=dec(r.get('opening'));receipts=dec(r.get('receipts',0));transfer_in=dec(r.get('transfer_in',0));transfer_out=dec(r.get('transfer_out',0));issues=dec(r.get('issues',0));adjustments=dec(r.get('adjustments',0));reported=dec(r.get('reported_closing'))
        calculated=opening+receipts+transfer_in-transfer_out-issues+adjustments
        result.append({'item':item,'location':location,'calculated_closing':str(calculated),'reported_closing':str(reported),'difference':str(reported-calculated),'status':'MATCH' if abs(reported-calculated)<=Decimal('0.01') else 'EXCEPTION'})
    return {'records':result,'exceptions':sum(x['status']=='EXCEPTION' for x in result),'journal_posted':False}
