"""Independent, stdin/stdout JSON calculation service; no web framework required."""
import json, sys
from reference_engine import calculate
from intercompany import reconcile
from intercompany_financial import reconcile_financial
from inventory_controls import reconcile_stock,nrv_test,inventory_rollforward
from transaction_ledger import calculate_ledger
from gl_reconciliation import reconcile_gl

def run(request):
    if not isinstance(request,dict):
        raise ValueError('Request must be an object')
    if request.get('action')=='inventory_gl_reconcile':
        return reconcile_gl(request.get('records'),request.get('tolerance','0.01'))
    if request.get('action')=='transaction_ledger':
        return calculate_ledger(request.get('records'),request.get('method','moving'))
    if request.get('action')=='stock_count_reconcile':
        return reconcile_stock(request.get('records'),request.get('tolerance','0.01'))
    if request.get('action')=='inventory_nrv':
        return nrv_test(request.get('records'))
    if request.get('action')=='inventory_rollforward':
        return inventory_rollforward(request.get('records'))
    if request.get('action')=='intercompany_financial':
        return reconcile_financial(request.get('records'),request.get('policy'))
    if request.get('action')=='intercompany_reconcile':
        return reconcile(request.get('documents'))
    if request.get('action')!='calculate':
        raise ValueError('Unsupported action')
    return calculate(request.get('rows'),request.get('method','moving'))

if __name__=='__main__':
    try:
        request=json.load(sys.stdin)
        print(json.dumps({'ok':True,**run(request)}))
    except (ValueError,TypeError,KeyError) as e:
        print(json.dumps({'ok':False,'error':str(e)}))
        sys.exit(2)
