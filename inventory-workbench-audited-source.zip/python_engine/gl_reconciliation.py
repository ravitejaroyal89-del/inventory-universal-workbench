"""Inventory subledger-to-GL reconciliation: reference-only; no postings."""
from collections import defaultdict
from decimal import Decimal
from inventory_controls import dec

def reconcile_gl(records,tolerance='0.01'):
    if not isinstance(records,list) or not records or len(records)>100000: raise ValueError('Invalid reconciliation rows')
    tol=dec(tolerance)
    if tol<0: raise ValueError('Tolerance must be nonnegative')
    result=[]; seen=set()
    for n,r in enumerate(records,1):
        if not isinstance(r,dict): raise ValueError(f'Row {n}: invalid record')
        keys=[str(r.get(k,'')).strip() for k in ('entity','account','currency','period')]
        if not all(keys): raise ValueError(f'Row {n}: missing entity/account/currency/period')
        key=tuple(keys)
        if key in seen: raise ValueError(f'Row {n}: duplicate reconciliation key')
        seen.add(key)
        subledger=dec(r.get('inventory_value')); gl=dec(r.get('gl_balance'))
        difference=subledger-gl
        result.append({'entity':keys[0],'account':keys[1],'currency':keys[2],'period':keys[3],
            'inventory_value':str(subledger),'gl_balance':str(gl),'difference':str(difference),
            'status':'MATCHED' if abs(difference)<=tol else 'EXCEPTION',
            'proposed_journal_posted':False})
    return {'rows':result,'exception_count':sum(r['status']=='EXCEPTION' for r in result),
        'limitations':['Compare only matching valuation bases and financial posting dates',
        'Investigate receipts not invoiced, revaluations, timing, dimensions and manual GL postings before adjustment']}
