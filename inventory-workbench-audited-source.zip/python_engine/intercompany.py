"""Independent document-level intercompany movement reconciliation. No ERP dependency."""
from collections import defaultdict
from decimal import Decimal, InvalidOperation

TYPES = ('SO','PO','PACKING_SLIP','GRN','DELIVERY_REPORT')

def reconcile(documents):
    if not isinstance(documents,list) or len(documents)>100000:
        raise ValueError('documents must be a list of at most 100000 records')
    groups=defaultdict(lambda:defaultdict(lambda:{'quantity':Decimal(0),'value':Decimal(0),'count':0,'dates':set(),'refs':[]}))
    for i,doc in enumerate(documents):
        if not isinstance(doc,dict):raise ValueError(f'Invalid document at row {i+1}')
        kind=str(doc.get('type','')).strip().upper().replace(' ','_')
        if kind not in TYPES:raise ValueError(f'Invalid document type at row {i+1}: {kind}')
        fields=['selling_entity','buying_entity','item','intercompany_order']
        if any(not str(doc.get(f,'')).strip() for f in fields):raise ValueError(f'Missing matching key at row {i+1}')
        key=tuple(str(doc[f]).strip().upper() for f in fields)
        try:
            qty=Decimal(str(doc.get('quantity','')))
            value=Decimal(str(doc.get('value',0)))
        except (InvalidOperation,ValueError):raise ValueError(f'Invalid numeric amount at row {i+1}')
        if not qty.is_finite() or not value.is_finite() or qty<0:raise ValueError(f'Invalid quantity/value at row {i+1}')
        rec=groups[key][kind];rec['quantity']+=qty;rec['value']+=value;rec['count']+=1
        if doc.get('date'):rec['dates'].add(str(doc['date']))
        if doc.get('document_no'):rec['refs'].append(str(doc['document_no']))
    results=[]; counts=defaultdict(int)
    for key,types in sorted(groups.items()):
        quantities={k:types[k]['quantity'] for k in TYPES}
        exceptions=[]
        for left,right in [('SO','PO'),('SO','PACKING_SLIP'),('PACKING_SLIP','GRN'),('DELIVERY_REPORT','GRN')]:
            if types[left]['count'] and types[right]['count']:
                if quantities[left]!=quantities[right]:exceptions.append({'code':'QTY_MISMATCH','comparison':f'{left} vs {right}','difference':str(quantities[left]-quantities[right])})
            elif types[left]['count'] or types[right]['count']:
                exceptions.append({'code':'MISSING_DOCUMENT','comparison':f'{left} vs {right}','missing':right if types[left]['count'] else left})
        if quantities['PACKING_SLIP']>quantities['GRN'] and types['PACKING_SLIP']['count']:
            exceptions.append({'code':'POTENTIAL_GOODS_IN_TRANSIT','quantity':str(quantities['PACKING_SLIP']-quantities['GRN'])})
        # Values of SO/PO may use different transfer prices/currencies: report, do not auto-adjust.
        if types['SO']['count'] and types['PO']['count'] and types['SO']['value']!=types['PO']['value']:
            exceptions.append({'code':'ORDER_VALUE_DIFFERENCE','difference':str(types['SO']['value']-types['PO']['value']),'note':'Confirm currency, pricing and valuation basis'})
        for e in exceptions:counts[e['code']]+=1
        results.append({'selling_entity':key[0],'buying_entity':key[1],'item':key[2],'intercompany_order':key[3],
          'documents':{k:{'quantity':str(types[k]['quantity']),'value':str(types[k]['value']),'count':types[k]['count'],'dates':sorted(types[k]['dates']),'references':types[k]['refs'][:20]} for k in TYPES},
          'exceptions':exceptions,'status':'EXCEPTION' if exceptions else 'MATCHED'})
    return {'groups':results,'summary':{'groups':len(results),'matched':sum(x['status']=='MATCHED' for x in results),'exceptions':sum(x['status']=='EXCEPTION' for x in results),'exception_types':dict(counts)},
     'limitations':['Document matching uses entity pair, item and intercompany order; partial shipments require consistent order-level aggregation.','No invoice, ledger, currency conversion, inventory costing or unrealised profit elimination is inferred from these five document types.','Delivery report meaning and signed quantities must be mapped to company-specific policy.']}
