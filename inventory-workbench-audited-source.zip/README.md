# Inventory Universal Workbench

The existing professional website uses a React frontend and a Cloudflare Worker with D1 persistence. Python and Node/FastAPI implementations are retained reference and legacy services; they are not the hosted runtime.

This branch imports the **existing Site version 4 source**, then applies verified audit fixes. It does not replace the professional interface with the older ZIP or publish a new production version. The original ZIP is preserved.

Read [AUDIT_REPORT.md](AUDIT_REPORT.md) for the feature inventory, confirmed defects, evidence, skipped checks, and remaining limitations. Read [LIVE_WORKSPACE.md](LIVE_WORKSPACE.md) for operating scope. Historical release documents describe earlier states and are not current test results.

## Reproduce verification

Use Node 24 and Python 3.12. Install dependencies in an isolated Python environment:

```sh
python -m pip install -r requirements.txt
npm ci --prefix react --no-audit --no-fund
npm ci --prefix node_backend --no-audit --no-fund
python verification/audit/run.py
```

For synthetic desktop/mobile browser workflows:

```sh
python -m pip install playwright
python -m playwright install chromium
python verification/audit/run.py --browser
```

`CHROMIUM_PATH` optionally selects a system Chromium. The browser harness runs only on loopback, with synthetic identities and a disposable SQLite database. It is never deployed. Logs go to ignored `.audit-artifacts/`; the checked-in audit evidence contains the results from this audit run. The GitHub workflow runs the same checks, but remote CI success must be observed separately.

Private workbook tests require `INVENTORY_TEST_DATA_DIR`. Missing workbooks are explicitly skipped, not treated as validated. One retired HTML smoke test is also skipped.

## Development and build

`npm --prefix react run build` builds the frontend. `node scripts/build-worker.mjs` packages the Worker and embedded frontend assets in ignored `deploy/`. The hosting manifest preserves the existing Site identity and D1 binding. Publishing, production data, authentication dispatch, and hosted migrations are separate from local verification.

There is no automatic journal posting. Direct ERP API connections, full inventory operations, landed-cost/FX policies, full NRV and production assurance remain incomplete or unverified; see the audit report for exact scope.
