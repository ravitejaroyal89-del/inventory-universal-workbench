import unittest,sys,os,json,subprocess
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'python_engine'))
from inventory_controls import reconcile_stock,nrv_test,inventory_rollforward
class InventoryControls(unittest.TestCase):
 def test_stock_exception(self):
  r=reconcile_stock([{'item':'A','location':'X','book_qty':10,'physical_qty':9,'unit_cost':20}]);self.assertEqual(r['records'][0]['difference_value'],'-20');self.assertEqual(r['exceptions'],1)
 def test_stock_match(self):
  self.assertEqual(reconcile_stock([{'item':'A','location':'X','book_qty':10,'physical_qty':10,'unit_cost':20}])['exceptions'],0)
 def test_nrv(self):
  self.assertEqual(nrv_test([{'item':'A','qty':10,'unit_cost':20,'selling_price':18,'selling_cost':1}])['net_proposed_write_down'],'30')
 def test_nrv_reversal_proposal(self):
  self.assertEqual(nrv_test([{'item':'A','qty':10,'unit_cost':20,'selling_price':25,'previous_write_down':20}])['net_proposed_write_down'],'-20')
 def test_rollforward(self):
  self.assertEqual(inventory_rollforward([{'item':'A','location':'X','opening':10,'receipts':5,'issues':3,'reported_closing':12}])['exceptions'],0)
 def test_rollforward_difference(self):
  self.assertEqual(inventory_rollforward([{'item':'A','location':'X','opening':10,'receipts':5,'issues':3,'reported_closing':11}])['exceptions'],1)
 def test_cli(self):
  p=subprocess.run([sys.executable,os.path.join(os.path.dirname(__file__),'python_engine','cli.py')],input=json.dumps({'action':'inventory_rollforward','records':[{'item':'A','location':'X','opening':10,'reported_closing':10}]}),text=True,capture_output=True)
  self.assertEqual(p.returncode,0);self.assertTrue(json.loads(p.stdout)['ok'])
 def test_bad_input(self):
  with self.assertRaises(ValueError):reconcile_stock([{'item':'A','location':'X','book_qty':10,'physical_qty':-1,'unit_cost':20}])
if __name__=='__main__':unittest.main()
