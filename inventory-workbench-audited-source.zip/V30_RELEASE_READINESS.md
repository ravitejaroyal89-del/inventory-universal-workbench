# Version 30 — Security and executable testing

## Changes
- Stricter per-IP rate limits on login (10/15 min) and setup (5/15 min), in addition to global API throttling.
- Node server binds to 127.0.0.1 by default rather than all interfaces. Configure HOST explicitly for trusted deployment.
- Added isolated pytest runner to prevent FastAPI import-time SQLite state leaking across unrelated test modules.
- Added Python subprocess tests using the exact CLI Node invokes.

## Limitations
- The React and Node dependencies are unavailable in the offline npm cache. No TypeScript build or Node runtime test is claimed.
- Browser navigation is restricted in this environment. No real browser E2E pass is claimed.
- Node auth store is SQLite, not production PostgreSQL.
- Rate limits are per process and not a replacement for shared distributed rate limiting.
- Independent accounting sign-off and ERP data verification are outstanding.

## Executed verification (2026-11-01)
- Focused pytest: 13 passed (`test_python_subprocess_v30.py`, `test_intercompany_financial_v28.py`, `test_intercompany_v27.py`, `test_entity_access_v21.py`).
- Entire pytest suite: 51 passed, 5 failed in initial combined run. Failures: blocked Chromium navigation; absent archived bridge.js and generated IVR diagnostic CSV; shared FastAPI bootstrap state affecting two tests.
- Isolated per-module run started but did not finish within the execution time budget; do not treat as a pass. Initial modules showed passing and failing results.
- Node and React npm offline installs failed (uncached dependencies). No browser or Node runtime E2E success claimed.
