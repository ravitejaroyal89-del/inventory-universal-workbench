# Inventory Workbench v34 — inventory-only scope correction

**Product:** Full Inventory Accounting, Valuation & Reconciliation Workbench. Intercompany inventory is a subset, not the product focus.

## In scope
1. Inventory masters, item/centre/entity mapping, data imports and source validation.
2. Purchase orders, receipts/GRN, returns, sales orders, dispatch/packing slips, delivery reports, internal transfers and adjustments.
3. Inventory quantity/value movement, inventory costing (FIFO/weighted average), COGS, closing stock and cut-off.
4. Physical vs system stock, inventory ledger vs GL, inventory ageing, negative stock, duplicates and exception investigations.
5. Ind AS 2 cost/NRV, write-down and reversal evidence, inventory-only journal proposals.
6. Intercompany inventory: linked SO/PO, packing slip/GRN, goods in transit, related invoices/AR/AP evidence, intercompany inventory profit elimination.
7. Independent Python calculation engines, formula-based Excel reference models, ERP comparison, audit trails and maker–checker.

## Explicitly out of scope
General AP/AR collections and payments, standalone financial close, tax/GST, payroll, leases, treasury, bank reconciliation, unrelated consolidation and other financial reporting engines.

## What changed in v34
React navigation now gives inventory-wide operations, COGS/closing stock, stock reconciliation, and Ind AS 2/NRV equal prominence. Intercompany is retained as a dedicated submodule. The new screens transparently identify work not yet implemented; they do **not** falsely claim working calculation features. Existing Python, Node, React and Excel artifacts are preserved.

## Outstanding engineering
Implement and test complete operational matching and stock/GL reconciliation, inventory costing policies, Ind AS 2 logic, Node runtime, React build, browser E2E, PostgreSQL and external accounting sign-off. No automatic posting.
