import Decimal from '../react/node_modules/decimal.js/decimal.mjs';
import {reconcile as compareBalances,ReconciliationInput,parseCsv,readReconciliationCsv} from '../react/src/reconciliation';
// v1 is retained only to verify historical evidence hashes. New calculations use
// enough significant digits for 5,000 bounded 21-digit quantity/rate inputs.
const DecimalV1=Decimal.clone({precision:28,rounding:Decimal.ROUND_HALF_EVEN});
const DecimalV2=Decimal.clone({precision:64,rounding:Decimal.ROUND_HALF_EVEN});
const incoming=new Set(['OPEN','PURCHASE','RECEIPT','ADJUST_IN']);
const outgoing=new Set(['ISSUE','COGS','CONSUMPTION','ADJUST_OUT']);
export function canonical(value:any):string{if(value===null||typeof value!=='object')return JSON.stringify(value);if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}'}
export async function sha(value:string){const h=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value));return Array.from(new Uint8Array(h),b=>b.toString(16).padStart(2,'0')).join('')}
export function calculate(kind:string,input:any,entity:string,period:string,version:1|2=2){
 const D=version===1?DecimalV1:DecimalV2;
 if(!/^[A-Za-z0-9_-]{1,64}$/.test(entity)||!/^\d{4}-(0[1-9]|1[0-2])$/.test(period))throw Error('Valid entity and YYYY-MM period required.');
 if(!input||!Array.isArray(input.records)||!input.records.length||input.records.length>5000)throw Error('Provide 1–5,000 source rows.');
 if(input.source_context){const context=input.source_context;if(typeof context.raw_csv!=='string'||context.raw_csv.length>1000000)throw Error('Invalid retained source CSV.');let normalized:any[];
 if(kind==='gl')normalized=readReconciliationCsv(context.raw_csv);else{const table=parseCsv(context.raw_csv),head=table[0]||[];if(new Set(head).size!==head.length)throw Error('Duplicate source column headers.');const mapping=context.column_mapping,types=context.type_mapping||{},format=context.date_format;if(!mapping||!['ISO','DMY_SLASH','DMY_DASH'].includes(format))throw Error('Source mapping and date policy required.');const keys=['source_id','date','item','location','type','qty','rate'];if(keys.some(k=>typeof mapping[k]!=='string'||!head.includes(mapping[k])))throw Error('Incomplete source column mapping.');normalized=table.slice(1).map((row,i)=>{if(row.length!==head.length)throw Error('Source CSV column mismatch at row '+(i+2));const r:any={entity};for(const k of keys)r[k]=(row[head.indexOf(mapping[k])]||'').trim();r.type=types[r.type]||r.type.toUpperCase();if(format!=='ISO'){const parts=r.date.split(format==='DMY_SLASH'?'/':'-');if(parts.length!==3)throw Error('Source date format mismatch.');r.date=parts[2]+'-'+parts[1].padStart(2,'0')+'-'+parts[0].padStart(2,'0')}return r})}
 if(canonical(normalized)!==canonical(input.records))throw Error('Normalized records do not agree to the retained source CSV and mapping.');}
 if(kind==='gl'){
  for(const r of input.records)if(!r||r.entity!==entity||r.period!==period)throw Error('Every balance row must match the selected entity and period.');
  const rows=compareBalances(input.records as ReconciliationInput[],String(input.tolerance??'0.01'));
  return {scope:'two_decimal_balance_comparison_v1',rows,exception_count:rows.filter(r=>r.status==='EXCEPTION').length,journal_posted:false};
 }
 if(kind!=='valuation')throw Error('Unsupported review type.');
 if(!/^[A-Z]{3}$/.test(input.currency||''))throw Error('Choose a single three-letter source currency.');
 if(!['fifo','moving'].includes(input.method))throw Error('Choose FIFO or moving average.');
 const seen=new Set<string>();
 const records=input.records.map((r:any,i:number)=>{
  if(!r||r.entity!==entity||r.currency&&r.currency!==input.currency)throw Error(`Row ${i+1}: selected entity must match.`);
  const id=String(r.source_id??'').trim(),item=String(r.item??'').trim(),location=String(r.location??'').trim(),type=String(r.type??'').toUpperCase();
  if(!id||id.length>150||seen.has(id))throw Error(`Row ${i+1}: unique source_id required (up to 150 characters).`);seen.add(id);
  if(!item||!location||item.length>150||location.length>150||!incoming.has(type)&&!outgoing.has(type))throw Error(`Row ${i+1}: invalid item, location, or transaction type. Returns and transfers require a separate reviewed policy.`);
  const date=String(r.date??'');if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date.slice(0,7)>period)throw Error(`Row ${i+1}: valid date on or before the selected cut-off month required.`);
  function number(v:any,label:string){const s=String(v??'');if(!/^\d{1,15}(?:\.\d{1,6})?$/.test(s))throw Error(`Row ${i+1}: ${label} must be nonnegative, up to six decimals, without separators.`);return new D(s)}
  const qty=number(r.qty,'quantity');if(!qty.gt(0))throw Error(`Row ${i+1}: quantity must be positive.`);const rate=incoming.has(type)?number(r.rate,'rate'):new D(0);
  return {source_id:id,item,location,type,date,qty,rate,index:i};
 }).sort((a:any,b:any)=>a.date.localeCompare(b.date)||(a.type==='OPEN'?0:1)-(b.type==='OPEN'?0:1)||a.index-b.index);
 const states=new Map<string,any>();let opening=new D(0),receipts=new D(0),issues=new D(0);const ledger:any[]=[];
 for(const r of records){const key=canonical([r.item,r.location]);let s=states.get(key);if(!s){s={item:r.item,location:r.location,qty:new D(0),value:new D(0),layers:[],offset:0};states.set(key,s)}let cost=new D(0);
  if(incoming.has(r.type)){cost=r.qty.times(r.rate);s.qty=s.qty.plus(r.qty);s.value=s.value.plus(cost);if(input.method==='fifo')s.layers.push({qty:r.qty,rate:r.rate});if(r.type==='OPEN')opening=opening.plus(cost);else receipts=receipts.plus(cost)}else{if(s.qty.lt(r.qty))throw Error(`Negative stock at source ${r.source_id}: ${r.item}/${r.location}.`);if(input.method==='moving')cost=r.qty.times(s.value).div(s.qty);else{let left=r.qty;while(left.gt(0)){const layer=s.layers[s.offset],take=D.min(left,layer.qty);cost=cost.plus(take.times(layer.rate));left=left.minus(take);layer.qty=layer.qty.minus(take);if(layer.qty.eq(0))s.offset++}}s.qty=s.qty.minus(r.qty);s.value=s.value.minus(cost);if(s.qty.eq(0))s.value=new D(0);issues=issues.plus(cost)}
  ledger.push({source_id:r.source_id,date:r.date,item:r.item,location:r.location,type:r.type,qty:r.qty.toString(),movement_cost:cost.toFixed(6),closing_qty:s.qty.toString(),closing_value:s.value.toFixed(6)});
 }
 const balances=Array.from(states.values()).sort((a,b)=>a.item.localeCompare(b.item)||a.location.localeCompare(b.location)).map(s=>({item:s.item,location:s.location,qty:s.qty.toString(),value:s.value.toFixed(6)}));
 const closing=Array.from(states.values()).reduce((sum,s)=>sum.plus(s.value),new D(0));const diff=opening.plus(receipts).minus(issues).minus(closing);if(diff.abs().gt('0.000001'))throw Error('Inventory roll-forward failed.');
 return {scope:version===1?'simple_fifo_moving_v1':'simple_fifo_moving_v2',currency:input.currency,method:input.method,valuation:balances,ledger,metrics:{opening:opening.toFixed(6),receipts:receipts.toFixed(6),issues:issues.toFixed(6),closing:closing.toFixed(6),rollforwardDifference:diff.toFixed(6)},journal_posted:false};
}
