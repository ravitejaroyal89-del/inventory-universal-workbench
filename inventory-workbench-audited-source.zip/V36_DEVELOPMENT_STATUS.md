# v36 — Inventory transaction reference ledger

## Implemented
- New independent Python transaction ledger (`python_engine/transaction_ledger.py`) with perpetual moving weighted average and FIFO costing by entity, item, location and currency.
- Supports opening balances, purchase receipts, sales issues, purchase returns, sales returns, stock adjustment in/out and standalone transfer in/out transactions.
- Calculates transaction cost, closing quantities/values and sale COGS; rejects negative stock, duplicate transaction IDs, missing identifiers and out-of-order dates.
- Protected Node endpoint `POST /api/transaction-ledger` invokes Python; no ERP journal posting.
- Eight new targeted Python tests passed.

## Known gaps / not production-ready
- Inter-location transfers are not paired automatically and transferred costs are not derived from the source location; users must provide incoming transfer unit cost. No full transaction CRUD/item master yet.
- No cost settlement, landed cost, financial versus physical posting, UOM conversions, historical cost adjustment, multi-currency accounting, inventory-to-GL reconciliation or comprehensive Ind AS 2 policies.
- React UI is not yet wired to the new endpoint; PostgreSQL persistence and security end-to-end verification remain outstanding.
- React/Node production compilation and real browser UAT not verified. Full existing pytest suite timed out in this run; this is not a full regression pass.
- No accounting certification or live ERP connector verification.

The scope remains full inventory accounting, with intercompany inventory only as a submodule. Preserve prior v35 modules and Excel models.
