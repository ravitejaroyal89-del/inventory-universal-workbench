# Live inventory control workspace

This release upgrades the existing private Site from static hosting to a Cloudflare Worker with D1 persistence. The original Python, Node, and historical source artifacts remain available as reference; they are not the hosted runtime.

## Delivered

- ChatGPT-managed sign-in; stable platform identity IDs; owner-restricted initial setup using the runtime `WORKSPACE_OWNER_EMAIL` binding.
- Administrator, maker, and checker memberships, active/disabled access, explicit entity grants, and authorization on every server operation.
- A live overview sourced from up to 500 accessible reviews, with example inventory kept separate.
- ERP-neutral CSV integrations with per-user, per-entity saved mapping profiles and source-system labels for TallyPrime, Zoho, SAP, Dynamics, Oracle, ERPNext, Odoo and others, with source-column mapping, explicit voucher classification, ISO or Indian day/month date formats, source IDs, and retained raw CSV plus mapping metadata. The server checks that normalized rows agree to retained CSV and mapping.
- Server reference FIFO and moving-average valuation with Decimal precision 28 and half-even rounding, checked against the independent Python reference on bounded fixtures.
- Server stock-to-GL comparison using exact two-decimal minor units; separate currencies; mandatory notes on exceptions before saving.
- Persistent source and result snapshots, SHA-256 integrity hashes, duplicate snapshot/policy rejection, independent review transitions, version conflict checks, and server recalculation at submit and decision.
- D1 atomic batches that commit updates and audit events together. A unique previous-hash constraint and a chain-head trigger serialize concurrent writers; conflicts are retried with refreshed authorization and state.
- Immutable source snapshots, permitted state transitions and independent checkers protected by database triggers. Audit events reject updates and deletion.
- Review evidence JSON and administrator audit verification/export. Notes and source metadata are bound into the creation event's evidence hash.

## First use

1. Open the private Site with the owner ChatGPT account. The verified owner administrator is initialized automatically through an authenticated same-origin request; no activation click is required. Deployment does not seed sample records.
2. In **Settings**, add the intended reviewer's verified ChatGPT email and role, then grant the relevant entity. Membership creation sends no email.
3. The reviewer also needs permission to visit the private Site. Hosting access is separate and is not changed by app membership. No Site audience changes were made in this release.
4. Import source files under **Import & Valuation**, confirm mappings, calculate and save a draft. Under **Approvals**, inspect and submit it. Another authorized person must approve or reject it.
5. Review participants can download evidence; administrators can verify and export the retained audit chain.

## Accounting and operating limits

- Simple opening balances, receipts and issues only. Full returns, paired transfers, landed costs, FX, settlement, and broader ERP costing policies are not implemented in the hosted reference engine. Negative stock and unsupported types are rejected.
- One entity and source currency per valuation. All provided movements through the selected cut-off month are included; the user must supply a complete opening position and relevant movements. The tool does not establish source completeness or authenticity.
- No accounting journal posting. Approval records a review decision, not an automatic GL adjustment or an accounting certification.
- Up to 5,000 records, 1 MB source CSV and 1.5 MB total JSON request, six decimal places for valuation quantities/rates, and two decimal places for balance comparisons. These are enforced bounds, not production throughput guarantees.
- Audit verification is bounded to 10,000 events. SHA-256 links and append-only database triggers provide tamper evidence within the retained database. They are not an externally signed or independently anchored immutable archive; a privileged database operator can change the database schema.
- Direct Tally/Zoho/SAP/other ERP API synchronization requires the specific system, authorized credentials, tested mappings and customer environment. File imports are live; direct external connectors are not configured.
- Original intercompany, stock-reconciliation scope, full NRV and other legacy screens are retained as reference modules, with their limitations displayed. They do not run the original Python API in the hosted Worker.
- Independent accounting certification, penetration testing, backup/restore drills and a production SLA are not claimed.

## Reproduce validation

```sh
npm --prefix react install
node verification/test_browser_reconciliation.cjs
node verification/live-api.test.mjs
npm --prefix react run build
node scripts/build-worker.mjs
node react/node_modules/typescript/bin/tsc --noEmit --module esnext --moduleResolution bundler --target ES2022 --lib DOM,ES2022 --skipLibCheck worker/api.ts worker/index.ts worker/engine.ts
```

The generated `deploy/` directory contains `server/index.js`, `.openai/hosting.json` and the Drizzle migrations. Do not edit generated output.

`verification/local-live-server.mjs` is a loopback-only test harness using SQLite to emulate D1 calls and test-only identities. It is not imported into the deployed Worker. Browser tests in `verification/live-browser.py` cover automatic owner setup, distinct maker/checker identities, mapped imports, calculations, persistent reviews, decisions, evidence downloads, audit verification and mobile layouts. Production authentication remains dispatch-owned.

Hosted D1 migrations are declared in `.openai/hosting.json` and applied by Sites publication. Local SQL emulation and hosted D1 are distinct environments; publication and native deployment results are recorded separately from local tests.

## Audit revision (PR; not yet published)

New valuations use 64 significant decimal digits and result scope `simple_fifo_moving_v2`. This resolves loss of fractional currency precision within the accepted 15-integer/six-fractional-digit input bounds. Existing `simple_fifo_moving_v1` results keep their original hashes and remain downloadable. Submit/decision first verifies their original calculation, then checks against the corrected policy; a changed result is blocked and needs a new review. No existing snapshot is rewritten.

The import UI discards a calculation response if source/policy inputs changed while the server request was running. Stock Reconciliation opens the live inventory-to-GL review workflow. Broader physical stock and operational reconciliation remain outside that hosted workflow.

Current evidence and remaining limitations are in `AUDIT_REPORT.md`; earlier statements that builds were blocked or all Node approval routes were missing are historical.
