import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'python_engine'))
import pytest
from transaction_ledger import calculate_ledger
from gl_reconciliation import reconcile_gl

def row(id,kind,location,quantity,unit_cost=None,ref=None):
 d={'transaction_id':id,'date':'2026-10-01','entity':'E1','item':'A','location':location,'currency':'INR','type':kind,'quantity':quantity}
 if unit_cost is not None:d['unit_cost']=unit_cost
 if ref is not None:d['transfer_ref']=ref
 return d

@pytest.mark.parametrize('method', ['moving','fifo'])
def test_transfer_carries_source_cost(method):
 rows=[row('1','OPENING','A',10,12),row('2','TRANSFER_OUT','A',4,ref='T1'),row('3','TRANSFER_IN','B',4,ref='T1')]
 result=calculate_ledger(rows,method)
 assert result['balances'][0]['value']=='72'
 assert result['balances'][1]['value']=='48'
 assert result['sale_cogs']=='0'

def test_transfer_rejects_mismatch():
 with pytest.raises(ValueError,match='mismatch'):
  calculate_ledger([row('1','OPENING','A',10,12),row('2','TRANSFER_OUT','A',4,ref='T1'),row('3','TRANSFER_IN','B',3,ref='T1')])

def test_unmatched_transfer_rejected():
 with pytest.raises(ValueError,match='Unmatched'):
  calculate_ledger([row('1','OPENING','A',10,12),row('2','TRANSFER_OUT','A',4,ref='T1')])

def test_gl_variance():
 result=reconcile_gl([{'entity':'E1','account':'1400','currency':'INR','period':'2026-10','inventory_value':100,'gl_balance':98}])
 assert result['exception_count']==1
 assert result['rows'][0]['difference']=='2'

def test_gl_match():
 result=reconcile_gl([{'entity':'E1','account':'1400','currency':'INR','period':'2026-10','inventory_value':100,'gl_balance':100}])
 assert result['exception_count']==0

def test_duplicate_gl_key_rejected():
 record={'entity':'E1','account':'1400','currency':'INR','period':'2026-10','inventory_value':100,'gl_balance':100}
 with pytest.raises(ValueError,match='duplicate'):reconcile_gl([record,record])
