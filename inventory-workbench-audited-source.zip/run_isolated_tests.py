"""Run independent test modules without shared module-import database state."""
import subprocess,sys,pathlib,json
root=pathlib.Path(__file__).resolve().parent
files=sorted(root.glob('test_*.py'))+sorted((root/'validation').glob('test_*.py'))
results=[]
for f in files:
    if f.name=='test_browser_smoke.py':
        results.append({'module':f.name,'status':'BLOCKED','reason':'Chromium navigation blocked by environment'});continue
    cmd=[sys.executable,'-m','pytest','-q',str(f)]
    r=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
    results.append({'module':str(f.relative_to(root)),'status':'PASS' if r.returncode==0 else 'FAIL','tail':r.stdout[-1800:]})
    print(f'{results[-1]["status"]}: {f.relative_to(root)}',flush=True)
(root/'V30_ISOLATED_TEST_RESULTS.json').write_text(json.dumps(results,indent=2))
print('SUMMARY:',{x:sum(r['status']==x for r in results) for x in ('PASS','FAIL','BLOCKED')})
sys.exit(1 if any(r['status']=='FAIL' for r in results) else 0)
