# Version 32 — build and browser verification

## Verified in this environment
- 3 TypeScript/TSX source files parsed/transpiled without syntax errors. **Not** a complete TypeScript typecheck or Vite production build.
- 5 real Node.js -> independent Python CLI subprocess checks passed, including FIFO, moving average, intercompany response contracts and invalid action rejection.
- 12 focused Python tests passed.
- Frontend version label updated to v32.

## Blocked, not passed
- `npm install` fails with `EAI_AGAIN` resolving registry.npmjs.org. React/Vite and Node/Express dependencies are not available locally. Neither `npm run build` nor `npm run check` could be run.
- Playwright Chromium navigation fails with `net::ERR_BLOCKED_BY_ADMINISTRATOR` even on a `data:` URL in this environment. Thus actual browser end-to-end flows on mobile and desktop have NOT passed.
- The Node HTTP server and full React-to-Node API integration were not executed, as Express dependencies are unavailable.

## To complete in an unrestricted environment
1. In `node_backend`: `npm install && npm run check && ALLOW_BOOTSTRAP=1 npm run start` (configure `AUTH_DB_PATH`, CORS and secrets as appropriate).
2. In `react`: `npm install && npm run build && npm run dev`. Vite proxies `/api` to localhost:3001 for development.
3. `BASE_URL=http://127.0.0.1:5173 python verification/browser_e2e.py` checks mobile and desktop module navigation.
4. Extend Playwright to cover actual login, CSV upload, server valuation, review submission and separate checker approval using isolated test accounts and database. These approval flows are **not** yet verified by the included browser script.
5. Use a secured reverse proxy for production `/api`; Vite's dev proxy does not apply to production static hosting.

## Release status
Development/testing package only. Do not treat as production certified or upload confidential company records to an unverified public deployment.
