"""The retained FastAPI service must not expose source/database files over HTTP."""
from fastapi.testclient import TestClient
import server

def test_project_files_are_not_public():
    client=TestClient(server.app)
    for path in ['/server.py','/requirements.txt','/inventory_v7.db','/.env','/.git/config','/archive/historical_evidence/IMPORT_AUDIT.json']:
        assert client.get(path).status_code==404,path

def test_import_inspection_route_is_not_shadowed():
    client=TestClient(server.app)
    assert client.post('/api/import/inspect',files={'file':('sample.csv',b'a,b\n1,2\n','text/csv')}).status_code==401

def test_legacy_calculations_enforce_entity_permissions(tmp_path,monkeypatch):
    monkeypatch.setattr(server,'URL','sqlite:///'+str(tmp_path/'access.db'))
    monkeypatch.setattr(server,'engine',server.create_engine(server.URL,connect_args={'check_same_thread':False}))
    monkeypatch.setenv('ALLOW_BOOTSTRAP','1');server.init();client=TestClient(server.app)
    pw='AuditFixturePassword123!'
    client.post('/api/setup',json={'username':'admin','password':pw})
    admin=client.post('/api/login',json={'username':'admin','password':pw}).json()['access_token']
    ah={'Authorization':'Bearer '+admin}
    assert client.post('/api/users',json={'username':'maker','password':pw,'role':'maker'},headers=ah).status_code==200
    assert client.post('/api/entity-access',json={'username':'maker','entity':'E1'},headers=ah).status_code==200
    maker=client.post('/api/login',json={'username':'maker','password':pw}).json()['access_token'];mh={'Authorization':'Bearer '+maker}
    row=dict(date='2026-10-01',item='A',location='W',type='OPEN',qty=10,rate=5)
    assert client.post('/api/reference-calculate',json={'rows':[row]},headers=mh).status_code==422
    assert client.post('/api/reference-calculate',json={'rows':[{**row,'entity':'OTHER'}]},headers=mh).status_code==403
    good=client.post('/api/reference-calculate',json={'rows':[{**row,'entity':'E1'}]},headers=mh)
    assert good.status_code==200 and good.json()['metrics']['closing']=='50'
    assert client.post('/api/reviews',json={'entity':'E1','period':'2026-10','payload':{'source_rows':[{**row,'entity':'OTHER'}]}},headers=mh).status_code==422
