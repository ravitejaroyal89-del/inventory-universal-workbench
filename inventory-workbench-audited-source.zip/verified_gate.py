"""Strict server-side valuation verification for the explicitly supported reference scope."""
from decimal import Decimal, InvalidOperation, localcontext
from reference_engine import calculate

def number(value, label):
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError(f'{label} is not a valid number')
    if not result.is_finite():
        raise ValueError(f'{label} must be finite')
    return result

def verify_payload(payload):
    with localcontext() as context:
        context.prec=64
        return _verify_payload(payload)

def _verify_payload(payload):
    if not isinstance(payload, dict):
        raise ValueError('Invalid payload')
    rows = payload.get('source_rows')
    if not isinstance(rows, list) or not rows:
        raise ValueError('Source transactions required for verified approval')
    if payload.get('blocking_errors') != []:
        raise ValueError('Blocking exceptions must be explicitly empty')
    result = calculate(rows, payload.get('method', 'moving'))
    if 'claimed_closing' not in payload:
        raise ValueError('Claimed closing valuation required')
    expected = sum((number(v['value'], 'Calculated value') for v in result['valuation']), Decimal(0))
    if abs(number(payload['claimed_closing'], 'Claimed closing') - expected) > Decimal('0.01'):
        raise ValueError('Closing valuation differs from independently calculated amount')
    claimed_metrics = payload.get('reference_metrics')
    if claimed_metrics is not None:
        if not isinstance(claimed_metrics, dict):
            raise ValueError('Reference metrics must be an object')
        for key, calculated in result['metrics'].items():
            if key not in claimed_metrics:
                raise ValueError(f'Missing reference metric: {key}')
            if abs(number(claimed_metrics[key], key) - number(calculated, key)) > Decimal('0.01'):
                raise ValueError(f'Reference metric mismatch: {key}')
    if payload.get('verification_scope') not in (None, result['scope']):
        raise ValueError('Unsupported verification scope')
    return result
