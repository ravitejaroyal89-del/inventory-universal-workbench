import os,tempfile
p=tempfile.mktemp(suffix='.db');os.environ['DATABASE_URL']='sqlite:///'+p;os.environ['ALLOW_BOOTSTRAP']='1'
from fastapi.testclient import TestClient
import server
from server import app
client=TestClient(app)
def test_workflow(tmp_path, monkeypatch):
 monkeypatch.setattr(server, "engine", server.create_engine("sqlite:///"+str(tmp_path/"workflow.db"),connect_args={"check_same_thread":False}))
 monkeypatch.setattr(server, "URL", "sqlite:///"+str(tmp_path/"workflow.db"))
 monkeypatch.setenv("ALLOW_BOOTSTRAP","1")
 server.init()
 def post(path,data=None,token=None):return client.post('/api'+path,json=data,headers={'Authorization':'Bearer '+token} if token else {})
 assert post('/setup',{'username':'root','password':'VeryLongPassword123!'}).status_code==200
 admin=post('/login',{'username':'root','password':'VeryLongPassword123!'}).json()['access_token']
 for name,role in [('maker','maker'),('checker','checker')]:assert post('/users',{'username':name,'password':'VeryLongPassword123!','role':role},admin).status_code==200
 for username in ('maker','checker'):
  assert post('/entity-access',{'username':username,'entity':'A'},admin).status_code==200
 maker=post('/login',{'username':'maker','password':'VeryLongPassword123!'}).json()['access_token'];checker=post('/login',{'username':'checker','password':'VeryLongPassword123!'}).json()['access_token']
 rid=post('/reviews',{'period':'2026-10','entity':'A','payload':{'source_rows':[{'date':'2026-10-01','item':'A','location':'WH','type':'OPEN','qty':10,'rate':12}],'method':'fifo','claimed_closing':120,'blocking_errors':[]}},maker).json()['id']
 assert post(f'/reviews/{rid}/approve',{'comment':'Approved'},maker).status_code==403
 assert post(f'/reviews/{rid}/submit',{},maker).status_code==200
 assert post(f'/reviews/{rid}/approve',{'comment':'Checked'},checker).status_code==200
 assert client.get('/api/audit/verify',headers={'Authorization':'Bearer '+checker}).json()['valid']
 assert post('/logout',{},maker).status_code==200
 assert post('/reviews',{'period':'2026-10','entity':'A','payload':{}},maker).status_code==401
