"""Auditable source-transaction policy approval gate. Never auto-approve ERP semantics."""
import csv,json
from collections import Counter
from pathlib import Path
from real_reconciliation import records,norm
from wac_cogs_v17 import moving_average
ALLOWED={'OPENING','RECEIPT','ISSUE','EXCLUDE_FINANCIAL_ONLY','TRANSFER_OUT','TRANSFER_IN','UNRESOLVED'}
def template(source,output):
    counts=Counter()
    for r in records(source):
        if not norm(r.get('Company Name')) or not norm(r.get('Item Code')):continue
        counts[norm(r.get('Reference'))]+=1
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['source_reference','source_rows','approved_class','quantity_sign_rule','cost_field','approved_by','approval_date','evidence_reference','review_notes'])
        for ref,count in sorted(counts.items()):w.writerow([ref,count,'UNRESOLVED','REVIEW','REVIEW','','','','Verify physical/financial postings and intercompany treatment'])
    return dict(counts)
def validate_mapping(path):
    rows=list(csv.DictReader(open(path,encoding='utf-8-sig',newline='')))
    errors=[];approved=[];seen=set()
    for i,r in enumerate(rows,2):
        ref=norm(r.get('source_reference'));cl=norm(r.get('approved_class'))
        if not ref or ref in seen:errors.append(f'row {i}: empty or duplicate source reference')
        seen.add(ref)
        if cl not in ALLOWED:errors.append(f'row {i}: unsupported classification')
        if cl!='UNRESOLVED':
            if not all(str(r.get(k) or '').strip() for k in ('approved_by','approval_date','evidence_reference')):errors.append(f'row {i}: approval evidence missing')
            else:approved.append(ref)
    return {'rows':len(rows),'approved_with_evidence':len(approved),'unresolved':len(rows)-len(approved),'errors':errors,'safe_for_actual_costing':len(rows)>0 and len(approved)==len(rows) and not errors,'caution':'Mapping approval is necessary but not sufficient: opening balances, sequence, settlement treatment, entity/centre and GL evidence must also be verified.'}
def run(source,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    counts=template(source,out/'SOURCE_TRANSACTION_REVIEW_TEMPLATE.csv')
    result={'source_reference_types':len(counts),'source_transaction_rows':sum(counts.values()),'approval_gate':validate_mapping(out/'SOURCE_TRANSACTION_REVIEW_TEMPLATE.csv'),'financial_certification':'NOT_CERTIFIED','independent_real_erp_wac':'BLOCKED_UNTIL_SIGNED_MAPPING_AND_COST_EVIDENCE'}
    (out/'SOURCE_MAPPING_REVIEW.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result
if __name__=='__main__':
    import sys
    print(json.dumps(run(sys.argv[1],sys.argv[2]),indent=2))
