# Version 33 — Professional inventory reconciliation and independent Excel validation

## Research benchmark (reviewed 2026-11-01)

| Platform | Publicly documented capability | Workbench design response |
|---|---|---|
| BlackLine Transaction Matching | Large-volume transaction matching, matching rules, recurring exceptions, auditability | Preserve detailed source identifiers, rule-driven matching and exception queue |
| FloQast Transaction Matching | Multi-source reconciliation, configurable rules, anomaly review and audit trail | Present unresolved differences prominently and preserve supporting evidence |
| Trintech Cadency | Intercompany matching, close workflow, maker/checker approvals, reconciliation evidence | Keep intercompany and close controls separate from unapproved postings |
| Oracle Financial Consolidation | Counterparty/entity eliminations with consolidation-scope controls | Do not treat a proposed inventory profit elimination as a posted consolidation journal |
| Oracle NetSuite Intercompany | Intercompany order/transfer and elimination workflow | Maintain separate order, dispatch, receipt, invoice, open balance and elimination evidence |

References:
- https://www.blackline.com/products/financial-close/transaction-matching/
- https://www.floqast.com/automate-the-close/products/ai-transaction-matching
- https://www.trintech.com/cadency/intercompany-accounting/
- https://docs.oracle.com/en/cloud/saas/financial-consolidation-cloud/agfcc/intercompany_eliminations.html
- https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/section_N1486393.html

These are feature benchmarks, not claims that the Workbench has achieved the same scale or assurance.

## Implemented in Version 33

1. Added an **Excel Reference Models** module in the responsive React navigation with a downloadable `.xlsx` reference workbook in `react/public/`.
2. Added independent **Excel formulas** for moving weighted average, illustrative two-layer FIFO, COGS roll-forward, intercompany document matching, intercompany financial invoice and AR/AP comparison, proposed unrealised profit, Ind AS 2 NRV and three-way ERP–Python–Excel variances.
3. Added control and guidance sheet explaining evidence lineage, duplicates, segregation of duties, source mapping, policy and approval.
4. Added Python test cases that independently verify WAC and FIFO examples against the existing calculation engine, and verify workbook formulas exist.
5. Fixed an approval test fixture that was relying on another test's shared administrator account. All regression tests now pass except one intentionally skipped legacy-browser test.

## Formula reference scope and limitations

- WAC reference uses a chronological running average with positive input costs; returns, settlement adjustments, FX, negative stock and other ERP costing behaviors require policy-specific extensions.
- FIFO tab is an **illustrative two-layer scenario**, not a general-purpose arbitrary-layer Excel FIFO engine. The independent Python FIFO engine is more general within its stated constraints.
- Intercompany formula rows use explicitly matched, normalized evidence; do not combine different currencies or legal entities without reviewed policies.
- NRV reference is illustrative: estimated selling price less completion and selling costs. Appropriate measurement, inventory categories and policy require accountant review.
- Unrealised profit model assumes unique matched seller cost, transfer price and unsold quantity; it is a proposal, not an authorized journal.
- The ERP/Python/Excel check tab contains sample values only. Replace them with independently sourced figures.
- Excel formulas may recalculate when opened in Excel; the file includes cached results where the spreadsheet engine supports them.

## Remaining engineering work

- React/Node production builds and actual mobile/desktop browser E2E remain unverified because package registry/browser restrictions prevented earlier attempts.
- Node PostgreSQL persistence, production security hardening, comprehensive Ind AS 2 policies and high-volume performance tests remain pending.
- Excel models do not yet implement all ERP scenarios or a live bidirectional workbook/API import. The workbook is a reference template, not a universal independent accounting certification.
- Actual ERP data should be loaded only after access controls, data-handling approvals and validation of source mapping.

No automatic accounting journals are posted.
