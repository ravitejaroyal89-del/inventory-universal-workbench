import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'python_engine'))
from intercompany_financial import reconcile_financial
import pytest

def line(t,amount,qty=0,cost=0,doc=None):
 return dict(type=t,selling_entity='A',buying_entity='B',item='X',intercompany_order='IC1',currency='INR',document_no=doc or t,amount=str(amount),quantity=str(qty),cost=str(cost))

def test_complete_evidence_and_profit():
 rows=[line('SALES_INVOICE',150),line('PURCHASE_INVOICE',150),line('AR_OPEN',150),line('AP_OPEN',150),line('INVENTORY_ISSUE',0,10,100),line('INVENTORY_RECEIPT',150,10),line('COGS',100),line('CLOSING_INVENTORY',0,4)]
 result=reconcile_financial(rows)
 assert result['summary']['matched']==1
 assert result['groups'][0]['proposed_elimination']['unrealised_profit']=='20.00'
 assert result['posting_allowed'] is False

def test_mismatches():
 result=reconcile_financial([line('SALES_INVOICE',150),line('PURCHASE_INVOICE',145),line('AR_OPEN',150),line('AP_OPEN',140)])
 codes={x['code'] for x in result['groups'][0]['exceptions']}
 assert {'INVOICE_AMOUNT_DIFFERENCE','AR_AP_DIFFERENCE'}<=codes

def test_no_unsupported_fx():
 with pytest.raises(ValueError,match='currency'):reconcile_financial([dict(line('SALES_INVOICE',1),currency='USD')])

def test_no_duplicate_evidence():
 with pytest.raises(ValueError,match='duplicate'):reconcile_financial([line('AR_OPEN',1),line('AR_OPEN',1)])

def test_missing_cost_prevents_profit_proposal():
 r=reconcile_financial([line('SALES_INVOICE',150),line('CLOSING_INVENTORY',0,3)])
 assert r['groups'][0]['proposed_elimination'] is None
 assert 'PROFIT_EVIDENCE_INCOMPLETE' in [x['code'] for x in r['groups'][0]['exceptions']]
