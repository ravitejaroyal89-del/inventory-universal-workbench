"""Retired v19 HTML browser smoke test. The active frontend is React/Vite."""
import pytest

@pytest.mark.skip(reason="Legacy HTML UI retired in v26; use React Playwright E2E suite instead")
def test_browser_sample():
    pass
