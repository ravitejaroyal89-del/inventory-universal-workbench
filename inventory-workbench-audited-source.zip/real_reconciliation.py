"""Read-only reconciliations for mapped real exports. No inventory valuation assertions."""
from collections import defaultdict,Counter
from decimal import Decimal,InvalidOperation
from pathlib import Path
import csv,json,sys
from real_data_import import rows_xlsx

def num(v):
 try:return Decimal(str(v).replace(',','').strip()) if v not in (None,'') else Decimal(0)
 except (InvalidOperation,ValueError):return Decimal(0)
def records(path):
 it=rows_xlsx(path);headers=next(it)
 for row in it:
  yield {str(h).strip():row.get(i) for i,h in headers.items() if h is not None and str(h).strip()}
def norm(v):return str(v or '').strip().upper()
def key(*v):return tuple(norm(x) for x in v)
def write(path,rows,cols):
 with open(path,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows(rows)
def reconcile(folder,out):
 folder=Path(folder);out=Path(out);out.mkdir(parents=True,exist_ok=True)
 purchase=folder/'purchase register sep to 0ct 2026.xlsx';grn=folder/'grn consolidation register sep to oct 2026.xlsx'
 closing=folder/'Consol_Closing_Stock_25Oct2026_All_Entities.xlsx';ivr=folder/'Consol_IVR_Inventory_Oct_2026_All_Entities (2).xlsx'
 po=defaultdict(lambda:{'ordered':Decimal(0),'received_on_po':Decimal(0),'line_amount':Decimal(0),'rows':0})
 for r in records(purchase):
  k=key(r.get('Company'),r.get('Purchase order'),r.get('Item number'))
  if not all(k):continue
  p=po[k];p['ordered']+=num(r.get('Quantity'));p['received_on_po']+=num(r.get('Received Qty'));p['line_amount']+=num(r.get('Line Amount'));p['rows']+=1
 receipts=defaultdict(lambda:{'received':Decimal(0),'net_amount':Decimal(0),'rows':0,'receipt_ids':set()})
 for r in records(grn):
  k=key(r.get('EntityCode'),r.get('Purchase order'),r.get('Item number'))
  if not all(k):continue
  g=receipts[k];g['received']+=num(r.get('Quantity'));g['net_amount']+=num(r.get('Net amount'));g['rows']+=1
  if r.get('GRN Number'):g['receipt_ids'].add(norm(r['GRN Number']))
 matches=[];stats=Counter()
 for k in sorted(po.keys()|receipts.keys()):
  p=po.get(k);g=receipts.get(k)
  if p and g:
   diff=p['received_on_po']-g['received'];status='MATCHED_QTY' if abs(diff)<=Decimal('0.0001') else 'RECEIVED_QTY_DIFFERENCE'
  else:status='PO_ONLY' if p else 'GRN_ONLY';diff=None
  stats[status]+=1
  matches.append({'entity':k[0],'purchase_order':k[1],'item':k[2],'status':status,'po_ordered_qty':str(p['ordered']) if p else '', 'po_report_received_qty':str(p['received_on_po']) if p else '', 'grn_qty':str(g['received']) if g else '', 'po_vs_grn_received_difference':str(diff) if diff is not None else '', 'po_line_amount':str(p['line_amount']) if p else '', 'grn_net_amount':str(g['net_amount']) if g else '', 'grn_documents':len(g['receipt_ids']) if g else 0})
 write(out/'po_grn_reconciliation.csv',matches,list(matches[0]) if matches else ['entity','status'])
 movement=defaultdict(lambda:{'qty':Decimal(0),'value':Decimal(0),'rows':0,'types':Counter(),'missing_qty':0})
 types=Counter();skipped=0
 for r in records(ivr):
  if norm(r.get('Reference'))=='GRAND TOTAL':skipped+=1;continue
  k=key(r.get('Company Name'),r.get('Site'),r.get('Item Code'))
  if not all(k):skipped+=1;continue
  m=movement[k];m['qty']+=num(r.get('Inventory: Quantity'));m['value']+=num(r.get('Inventory: Amount'));m['rows']+=1
  typ=norm(r.get('Reference'));m['types'][typ]+=1;types[typ]+=1
  if r.get('Inventory: Quantity') in (None,''):m['missing_qty']+=1
 stocks=defaultdict(lambda:{'qty':Decimal(0),'value':Decimal(0),'rows':0,'methods':set()})
 for r in records(closing):
  k=key(r.get('Entity Code'),r.get('Centre Code'),r.get('Item Code'))
  if not all(k):continue
  s=stocks[k];s['qty']+=num(r.get('Quantity in Stock'));s['value']+=num(r.get('Total Cost'));s['rows']+=1
  if r.get('Valuation Method'):s['methods'].add(norm(r['Valuation Method']))
 comp=[];status_counts=Counter()
 for k in sorted(movement.keys()|stocks.keys()):
  m=movement.get(k);s=stocks.get(k)
  if m and s:
   qdiff=m['qty']-s['qty'];vdiff=m['value']-s['value'];status='MATCHED_BOTH' if abs(qdiff)<=Decimal('0.0001') and abs(vdiff)<=Decimal('0.01') else 'VARIANCE_REQUIRES_INVESTIGATION'
  else:qdiff=vdiff=None;status='MOVEMENTS_ONLY' if m else 'CLOSING_ONLY'
  status_counts[status]+=1
  comp.append({'entity':k[0],'centre':k[1],'item':k[2],'status':status,'ivr_reported_qty_sum':str(m['qty']) if m else '', 'closing_stock_qty':str(s['qty']) if s else '', 'qty_difference':str(qdiff) if qdiff is not None else '', 'ivr_reported_value_sum':str(m['value']) if m else '', 'closing_stock_value':str(s['value']) if s else '', 'value_difference':str(vdiff) if vdiff is not None else '', 'ivr_rows':m['rows'] if m else 0,'closing_rows':s['rows'] if s else 0,'valuation_methods':';'.join(sorted(s['methods'])) if s else '', 'caution':'IVR sums may contain opening balances, physical/financial movements and settlements; differences are investigative, not proven accounting errors.'})
 write(out/'ivr_closing_stock_comparison.csv',comp,list(comp[0]) if comp else ['entity','status'])
 summary={'po_grn':{'po_keys':len(po),'grn_keys':len(receipts),'statuses':dict(stats),'caution':'PO received quantity is a report snapshot; GRN rows may include multiple posting/invoice states. Investigate duplicates, returns and cut-off before posting.'},'ivr_closing':{'movement_keys':len(movement),'closing_keys':len(stocks),'statuses':dict(status_counts),'movement_types':dict(types),'skipped_rows':skipped,'caution':'Not a validated inventory rollforward. IVR reported quantity/value fields require source-method and period verification.'},'release_gate':'NOT FINANCIALLY CERTIFIED; NOT PRODUCTION READY'}
 (out/'RECONCILIATION_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 return summary
if __name__=='__main__':print(json.dumps(reconcile(sys.argv[1],sys.argv[2]),indent=2))
