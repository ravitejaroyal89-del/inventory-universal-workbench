# Version 25: Node.js/TypeScript + independent Python

- React + TypeScript: responsive interface (preserved from v24).
- Node.js + Express + TypeScript: new backend foundation, health check and independently executed Python calculation endpoint.
- Python 3: standalone inventory calculation engine in `python_engine/`, callable from CLI, without a web framework.
- Legacy FastAPI: retained for secure maker-checker, entity permissions, audit and existing modules during phased migration.
- PostgreSQL: target persistence; live integration with Node remains pending.

## Status
This is a **working architectural slice**, not a complete Node migration. React currently calls `/api` and must be routed to the appropriate backend during transition. Auth, approval, audit and entity access must be implemented in Node before FastAPI can be retired. Python engine supports only simple FIFO and moving WAC; Ind AS 2 full validation, ERP settlement matching and NRV remain pending.
