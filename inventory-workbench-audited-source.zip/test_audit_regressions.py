"""Confirmed legacy reference control defects found during the whole-source audit."""
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).parent/'python_engine'))
from transaction_ledger import calculate_ledger
from inventory_controls import nrv_test
from python_engine.reference_engine import calculate
from reference_engine import calculate as root_calculate

def tx(id,kind,location='W1',ref=None):
    r=dict(transaction_id=id,date='2026-10-01',entity='E1',currency='INR',item='A',location=location,type=kind,quantity=5,unit_cost=10)
    if ref is not None:r['transfer_ref']=ref
    return r

@pytest.mark.parametrize('method',['fifo','moving'])
@pytest.mark.parametrize('kind',['TRANSFER_IN','TRANSFER_OUT'])
def test_transfer_reference_required(method,kind):
    with pytest.raises(ValueError,match='transfer_ref required'):
        calculate_ledger([tx('open','OPENING'),tx('bad',kind)],method)

def test_completed_transfer_reference_cannot_be_reused():
    rows=[tx('open','OPENING'),tx('out','TRANSFER_OUT',ref='T'),tx('in','TRANSFER_IN','W2','T'),tx('out2','TRANSFER_OUT','W2','T'),tx('in2','TRANSFER_IN','W1','T')]
    with pytest.raises(ValueError,match='Duplicate transfer'):calculate_ledger(rows)

@pytest.mark.parametrize('engine',[calculate,root_calculate])
@pytest.mark.parametrize('dimension',['entity','currency'])
def test_single_context_reference_valuation(engine,dimension):
    base=dict(date='2026-10-01',entity='E1',currency='INR',item='A',location='W',type='OPEN',qty=10,rate=5)
    with pytest.raises(ValueError,match='single entity and currency'):
        engine([base,{**base,dimension:'E2' if dimension=='entity' else 'USD'}])

def test_nrv_rejects_impossible_prior_allowance():
    with pytest.raises(ValueError,match='historical cost'):
        nrv_test([dict(item='A',qty=2,unit_cost=10,selling_price=20,previous_write_down=25)])

def test_nrv_reversal_respects_cost_cap():
    r=nrv_test([dict(item='A',qty=2,unit_cost=10,selling_price=20,previous_write_down=20)])
    assert r['records'][0]['write_down_movement']=='-20'
    assert r['journal_posted'] is False

@pytest.mark.parametrize('engine',[calculate,root_calculate])
def test_large_reference_product_is_not_rounded_at_integer_precision(engine):
    from decimal import Decimal
    r=engine([dict(date='2026-10-01',item='A',location='W',type='OPEN',qty='999999999999999.654321',rate='987654321012345.123456')],'fifo')
    assert Decimal(r['metrics']['closing'])==Decimal('987654321012344782044641966773.550068853376')

@pytest.mark.parametrize('engine',[calculate,root_calculate])
def test_reference_precision_limits_are_explicit(engine):
    with pytest.raises(ValueError,match='15 integer digits'):
        engine([dict(date='2026-10-01',item='A',location='W',type='OPEN',qty='1000000000000000',rate='1')])

def test_profit_proposal_blocks_known_invoice_quantity_mismatch():
    from intercompany_financial import reconcile_financial
    base=dict(selling_entity='A',buying_entity='B',item='X',intercompany_order='IC1',currency='INR')
    def line(t,amount,qty=0,cost=0):return dict(base,type=t,document_no=t,amount=amount,quantity=qty,cost=cost)
    r=reconcile_financial([line('SALES_INVOICE',200,20),line('INVENTORY_ISSUE',0,10,80),line('CLOSING_INVENTORY',0,5)])
    assert r['groups'][0]['proposed_elimination'] is None
    assert any(e['code']=='PROFIT_EVIDENCE_INCOMPLETE' for e in r['groups'][0]['exceptions'])
    assert r['posting_allowed'] is False
