# Universal Inventory Workbench v10 — verification status

## Changes
- Replaced legacy browser approval payload with source-row evidence, server reference calculation, server-verified closing amount, and explicit rejection of unsupported movement types.
- Retained original v9 application and backend, rather than replacing them with an unrelated prototype.
- Updated backend workflow test to submit verified source transactions rather than the obsolete unverified evidence shape.

## Executed tests
- Python reference/backend/bridge tests: 7 passed (explicit test files).
- Existing JavaScript controls/universal/settlement tests: 25 passed.
- Browser smoke test: attempted, **blocked by environment policy** (`net::ERR_BLOCKED_BY_ADMINISTRATOR` for both file and localhost). Not passed.

## Not completed / do not claim production readiness
- Full browser end-to-end regression remains blocked/unverified.
- Live PostgreSQL instance, migration execution, backup/restore and deployment security are unverified.
- Full Ind AS 2 treatment, NRV, overhead absorption, landed costs, transfers and settlements are not independently certified.
- Authentic anonymized exports from TallyPrime, SAP, Oracle, D365, BUSY, Zoho and ERPNext were not provided, so compatibility is not verified.
- Entity isolation, MFA, rate limiting, hardened sessions, period locking and external audit anchoring remain pending.
- Server approval gate covers only simple supported reference transactions; other calculations remain informational, not eligible for verified approval.

## Local run
Install requirements from `requirements.txt`, configure `DATABASE_URL`, and run `uvicorn server:app --host 127.0.0.1 --port 8000`. `ALLOW_BOOTSTRAP=1` must be used only for initial administrator creation, then disabled. Do not expose to public internet.
