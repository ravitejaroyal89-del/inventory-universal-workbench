# Version 14 — Transaction-key reconciliation milestone

## What was implemented
- Added `real_reconciliation.py`, a reusable read-only Python reconciliation module for the actual purchase register, GRN, inventory movement and closing stock layouts.
- Aggregates purchase register and GRN by normalized (entity, PO, item), and compares reported PO received quantity with GRN quantity.
- Aggregates IVR and closing stock by normalized (entity, centre, item), comparing source-reported quantities and amounts without misclassifying all transfers as COGS.
- Writes full CSV exception and comparison reports plus machine-readable summary.
- Added regression tests and a link to the reconciliation report explanation from the HTML inspector.

## Key caveats
- This is **not** an independently verified weighted-average valuation engine. IVR may mix opening balances, physical and financial postings, and adjustments; movement sums are not automatically a validated roll-forward.
- PO and GRN files may have different cut-off dates, partial receipts, multiple posting states, returns and unmatched references. Flagged differences need review.
- Source spreadsheets are not redistributed inside the application ZIP. Reconciliation output contains identifiers and amounts from uploaded data and must be handled as confidential.
- No live PostgreSQL deployment, certified Ind AS 2 validation, or full browser regression is claimed.

## Running on your own data
From the application directory:
`python real_reconciliation.py /path/to/source-folder /path/to/output-folder`

The source folder must contain the four report filenames used by the provided exports; subsequent development should replace hard-coded filenames with selectable profiles.
