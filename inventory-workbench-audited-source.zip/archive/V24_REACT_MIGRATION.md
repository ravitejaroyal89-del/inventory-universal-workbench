# Version 24 — React + TypeScript frontend migration

## Implemented
- New React + TypeScript source project in `react/`, using Vite, with a responsive mobile/desktop dashboard.
- React screens: sign-in/initial setup, CSV import, server-side FIFO/moving-WAC reference calculation, valuation preview, maker submission, checker approval/rejection, review queue/evidence, audit verification, user creation and entity access grants.
- The existing Version 23 HTML, JavaScript, Python accounting/reconciliation modules, FastAPI backend and database migrations are preserved unchanged except for an optional React static mount in `server.py`.
- React calls existing `/api` endpoints; it does not bypass server-side maker–checker rules.
- Vite is configured to build at `/app/` and proxy API requests to localhost:8000 during development.

## How to run (requires internet or preinstalled npm packages for first install)
1. In `react/`, run `npm install`.
2. Run `npm run build` to create `../react_dist`.
3. From the package root, run `uvicorn server:app --host 0.0.0.0 --port 8000` (set `DATABASE_URL`, and enable `ALLOW_BOOTSTRAP=1` only for first administrator setup).
4. Open `http://localhost:8000/app/` for React; legacy UI remains at `http://localhost:8000/`.
5. For development, run `npm run dev` in `react/`, then open Vite's local address; its `/api` proxy targets the backend on port 8000.

## Critical limitations
- npm dependency installation/build was attempted but unavailable in this isolated execution environment. This package includes real React source, not a verified compiled React build. Do not represent the React app as browser-tested.
- The new React import currently accepts canonical CSV only; use the existing legacy inspector for Excel. CSV headers: `date,item,location,type,qty,rate`.
- The React UI supports only the existing verified reference scope: FIFO and moving weighted average; not all ERP-specific valuation policies, transfers, NRV or cost settlements.
- The app is **not production ready**. Real browser end-to-end, live PostgreSQL, independent Ind AS 2 verification and production security tests remain outstanding.
