# Universal Inventory Workbench v8 — reference-engine milestone

New: independent Python Decimal-based FIFO and moving-average reference calculation, authenticated `/api/reference-calculate` endpoint, validation of dates, negative inventory, unsupported movements, roll-forward and reference tests. This endpoint is intentionally **not** a production approval gate. The legacy `/api/reviews` workflow still accepts browser-supplied evidence; it does not verify valuation independently. Do not treat approvals as financial certification.

Local test evidence: 6 Python reference/API tests passed, 1 separate legacy backend integration test passed, 25 existing JS tests passed. No live PostgreSQL, browser E2E, independent Ind AS 2 expert sign-off or authentic multi-ERP exports were tested.

Reference engine scope: basic OPEN, PURCHASE, RECEIPT, RETURN_IN, ADJUST_IN, ISSUE, COGS, CONSUMPTION, RETURN_OUT, ADJUST_OUT. FIFO and moving weighted average. Does not handle transfer chains, settlements, landed-cost distribution, NRV history, production cost, currency conversion, GST recoverability, or period close locks. Unsupported transactions are rejected.

Security still pending: rate limiting, MFA, SSO, tenant/entity scoping, external tamper-resistant log archival, database migrations, secure secret rotation, operational backups and production penetration testing. PostgreSQL compatibility is not live verified.

To run: pip install -r requirements.txt ; ALLOW_BOOTSTRAP=1 uvicorn server:app --host 127.0.0.1 --port 8000. Bootstrap admin via POST /api/setup; disable bootstrap and restart. For deployment use secure PostgreSQL DATABASE_URL, TLS and production controls. Do not expose to the internet as-is.
