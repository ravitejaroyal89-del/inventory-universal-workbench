# Version 21 — Entity access enforcement and test results

## Implemented
- Entity grants stored in `entity_access`, with an admin-only grant API.
- Maker draft creation and submission require a grant for that entity; checker review detail, listing, approval and rejection require an entity grant. Admin retains global access.
- Entity grants are audited; migration `002_entity_access.sql` supplied.
- Existing code and data preserved in the copied Version 20 baseline.

## Executed
- `python -m pytest -q test_entity_access_v21.py`: **1 passed**.
- Full inherited test run: **42 passed, 5 failed**. Four failures are due to legacy test setup assumptions or test isolation around bootstrap/entity grants; the fifth is Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` on local navigation. These failures are NOT hidden and must be resolved before release.

## Still pending / NOT certified
- Complete real UI click-through Playwright testing; browser navigation is blocked in this environment.
- PostgreSQL live migration and concurrency/security validation; migration is prepared but not executed against production.
- Full accounting source classification, independent actual-data weighted-average valuation, inventory-to-COGS tie-out, Ind AS 2 independent review, and multi-ERP compatibility tests.
- Rate limiting, session management hardening, deployment security, and full regression repair.
- Entity grant revocation and an administration UI for grants (admin API only at present).

## Local setup
- Install requirements, configure DATABASE_URL and ALLOW_BOOTSTRAP=1 for initial admin setup only; disable bootstrap afterwards.
- Create maker and checker users through `/api/users` as admin.
- Grant each authorized entity via `POST /api/entity-access` with `{"username":"maker1","entity":"ENTITY_A"}` and Bearer admin token.
- Use separate maker and checker accounts; run end-to-end approval workflow against an accessible server.

**Release decision: NOT PRODUCTION READY.**
