# Version 13 — Real-data import milestone

## Implemented
- Preserved v12 application and its existing calculation/approval code.
- Added read-only authenticated FastAPI `/api/import/inspect` endpoint and standalone inspector interface linked from the main page.
- Added ERP-neutral mapping profiles for consolidated closing stock, IVR movements, purchase orders, GRNs, sales and detailed COGS (when matching sheets are selected).
- Added XLSX/CSV streaming parser, required-field checks, centre/entity detection, movement classification and file-size guard.
- Real-data tests: 5 passed; targeted combined Python tests: 19 passed.
- Inspected 4 source report structures: closing stock 4,519 rows; IVR 105,992 rows; purchase orders 2,104 rows; GRN 2,114 rows.

## Limitations
- The sales workbook opens on a working/issues tab, not its actual sales register. Sheet selection is not yet exposed in the interface; its first sheet was not classified.
- No transaction-level PO/GRN/IVR-to-closing reconciliation or verified COGS computation has been completed.
- The importer inspects structure and blanks only; it does not assert accounting correctness, duplicate classification or match results.
- Source workbooks are intentionally excluded from the release ZIP to avoid redistributing confidential data.
- PostgreSQL live migration, comprehensive Ind AS 2 assessment, production security and full browser tests remain outstanding.
- Do not treat this as a production-ready or audit-certified release.

## Running
Install requirements with `pip install -r requirements.txt`, then start `uvicorn server:app --host 127.0.0.1 --port 8000` from the application directory. Login using the existing workflow, open `real_data_inspector.html` on the same server, provide a session token and select a supported source file. The upload endpoint requires authentication and does not retain the uploaded file.
