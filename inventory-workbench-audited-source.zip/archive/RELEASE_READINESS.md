# Inventory Universal Workbench v9 — independent verification gate

## Audit of inherited v8
- KEEP: existing HTML, universal mappings, JS valuation engine, independent Python reference calculator, SQLAlchemy backend, role-separated approval workflow.
- IMPROVE: v8 allowed approval of unverified browser-produced results; v9 adds server-side source transaction recalculation on both submit and approve.
- MERGE: no destructive changes to existing frontend modules.
- REMOVE: none pending dependency review.
- ADD: verified_gate.py, test_verified_gate.py, verification evidence in audit submit event.

## Critical caveats
- **The existing browser approval button still submits legacy browser evidence without `source_rows` and `claimed_closing`; the server will now correctly reject that submission.** The browser must be rewired to submit the exact standardized source transactions and claimed closing balance before approvals are usable end-to-end.
- Approval verification supports only FIFO/moving average and the transaction types allowed by reference_engine.py. Periodic weighted average, specific identification, transfers, landed cost, NRV, production and full Ind AS 2 validation are not certified.
- PostgreSQL production migration, tenant isolation, MFA, rate limiting, period locks, backup/restore, external audit anchoring, deployment hardening and real ERP-file tests are pending.
- Existing backend tests targeting legacy approval payloads must be updated before full regression can pass.
- No authentic Tally/SAP/Oracle/BUSY/Zoho/ERPNext/D365 sample exports supplied for validation.

## Executed tests
- Python reference and new verification gate: 10 passed.
- JS controls: 10 passed; universal: 8 passed; settlement: 7 passed.
- Python syntax compilation passed.
- Not executed: full API regression, live PostgreSQL, browser E2E, production security, independent accounting signoff.

## Safe deployment guidance
Do not expose this build to the public internet or rely on it for statutory inventory valuation. Use an isolated development environment and anonymized test data. Never use the legacy frontend approval workflow as proof of financial accuracy.
