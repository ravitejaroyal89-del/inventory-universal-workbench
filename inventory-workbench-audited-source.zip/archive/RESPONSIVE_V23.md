# Version 23 — mobile and desktop responsive layout

- Retains the Version 22 valuation, import, reconciliation, and approval code.
- Adds mobile/tablet/desktop responsive layout, accessible section navigation, minimum touch targets, focus indicators, horizontal scrolling for dense tables and two-column desktop layout.
- Mobile Safari / Chrome can open the HTML, but many features use adjacent JS files and the server-backed approvals require FastAPI. Use the full ZIP with a web server; the HTML alone is not a standalone working app.
- This is a responsive web application, not a native iOS/Android app or Windows executable.
- CSS/layout smoke tests and existing test suite results are documented separately.
