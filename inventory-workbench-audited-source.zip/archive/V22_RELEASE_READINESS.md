# Version 22 — verified regression repair

## Changes
- Preserved Version 21 server-side entity access enforcement.
- Updated legacy approval tests to explicitly grant entity A to maker/checker accounts, consistent with the new security policy.
- Updated another-maker access test to verify denial even when both makers are authorized for the same entity.
- Repaired malformed docstring in Playwright script and added required test-entity grants.

## Executed checks
- Focused maker/checker and entity permission tests: **4 passed**.
- Wider pytest suite excluding browser smoke: **44 passed, 2 failed** (25.89 seconds). Failures occur because test modules import `server` at collection time and mutate `DATABASE_URL`/bootstrap globals; the tests interfere when collected together. The affected reference API test passes when run in isolation (**1 passed**). Test suite isolation still needs a refactor.
- Playwright Python script syntax check (`py_compile`): **passed**. This does not prove browser navigation or button-click success.

## Not verified / not complete
- Full browser end-to-end UI interaction (login -> submit -> approve/reject) in a real reachable browser.
- Live PostgreSQL migration and production security hardening.
- Independent transaction-level weighted-average reconciliation and inventory issues-to-COGS financial matching.
- Comprehensive Ind AS 2 accounting verification and external sign-off.

**Not production-ready.** This is an incremental regression repair release.
