# Version 18 — transaction classification approval gate

This update preserves Version 17 and adds a real-export source reference inventory, a review template and evidence-based approval validation. The source template is **unapproved by default**. It is not safe to infer transaction directions or WAC from ERP labels alone.

## Test results
..........                                                               [100%]
10 passed in 0.07s


## Remaining blockers
1. Finance-approved transaction classifications, posting sign conventions, physical versus financial quantity policy and settlement semantics.
2. Independently validated opening costs and chronologically ordered movements; item-centre-entity identity.
3. Posted stock issue vouchers and GL COGS details; consumption and provision classification.
4. Independent accounting review and sign-off, NRV/Ind AS 2 validation, database/security and browser production testing.

**Not financially certified.** The new approval gate checks documentary completeness, not correctness of the underlying evidence. No automatic journals or approvals.
