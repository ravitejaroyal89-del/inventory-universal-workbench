# Version 17: independent WAC reference and actual COGS evidence gates

## Implemented
- Deterministic, decimal-based moving-weighted-average reference engine with chronological receipts and issues; rejects negative stock, unsupported value-only adjustment events, and invalid receipts.
- Actual 105k-row IVR evidence completeness audit with explicit blockers for real-world independent WAC calculation.
- Centre-level bridge between reported September/October COGS and IVR centre identities. This is **not** an inventory-issue cost match.
- Preserved existing Version 16 application and source modules.

## Executed tests
......                                                                   [100%]
6 passed in 0.07s

## Actual data outputs
WAC gates: {
  "item_centre_keys": 6820,
  "blocker_key_counts": {
    "MOVEMENT_CLASSIFICATION_AND_POSTING_SEMANTICS_NOT_APPROVED": 6820,
    "VALUE_ONLY_POSTINGS_REQUIRE_SETTLEMENT_POLICY": 2967,
    "SIGNED_ISSUE_AND_RETURN_MAPPING_REQUIRED": 1628
  },
  "independent_wac_reference_engine": "IMPLEMENTED_AND_TESTED_WITH_DETERMINISTIC_EVENTS",
  "real_erp_wac_recalculation": "BLOCKED_PENDING_SOURCE_TRANSACTION_SEMANTICS",
  "financial_certification": "NOT_CERTIFIED"
}
COGS bridge: {
  "cogs_centre_period_rows": 132,
  "centre_period_rows_with_matching_ivr_centre": 114,
  "independent_issues_vs_cogs": "NOT_VERIFIED",
  "reason": "Centre identifiers alone do not prove common period, entity, transaction type or cost basis"
}

## Certification status
**NOT CERTIFIED**. Automated reference arithmetic does not establish that the ERP movement fields are complete and properly classified, nor that the entity/centre periods align. A qualified independent accounting reviewer must confirm transaction signs, settlement semantics, opening values, valuation policy, NRV, consumption classification, reconciliations and disclosures before sign-off. Production database/security/browser gates remain outstanding.

## Additional source evidence needed
- Confirmed inventory movement code-to-type mapping and signs (receipt/issue/return/transfer/adjustment).
- Opening quantity and inventory cost per item, site and entity; dated, ordered receipt and issue evidence.
- Financial-versus-physical inventory transaction treatment and cost settlement rules.
- Centre-to-entity crosswalk and month-end period/cut-off confirmation.
- Posted COGS ledger and stock issue vouchers to bridge independently calculated issue cost to expense.
