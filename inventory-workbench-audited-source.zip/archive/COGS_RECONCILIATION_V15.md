# Version 15 — Real-data COGS reconciliation

## Implemented
- Added `cogs_analysis_v15.py` for read-only inspection of September and October centre COGS files.
- Kept billable dialysis, non-billable dialysis, pharmacy billable, provisions, actual sessions and forecast sessions separate.
- Calculated October component-to-reported-total variances, and diagnostic per-session rates.
- Produced `cogs_outputs/cogs_centre_comparison.csv` and machine-readable summary.
- Preserved v14 application, reconciliation modules, and tests.

## Actual source results
- 66 centre rows inspected in September and 66 in October.
- 65 October reported dialysis totals reconcile to the reported billable, non-billable and provision components within 0.02.
- 1 October centre, `3-PH-CCN-BTK-S`, reports zero total but blank underlying components. This is a missing-evidence review item, not a proved error.
- September report has no comparable explicit provision column in the inspected first worksheet.

## Material limitations
- Reported components are not independently matched to underlying inventory issues or GL postings.
- The September reporting period is September 1–30, while October has October 1–25 actual and October 26–31 forecast session counts. Cross-period changes should not be interpreted as like-for-like.
- No verified weighted-average cost recalculation, no NRV assessment, and no certified Ind AS 2 compliance.
- No production PostgreSQL deployment or end-to-end browser certification.
- All data-derived reports may contain confidential company data; store securely.

## Run
`python cogs_analysis_v15.py /path/to/source_workbooks /path/to/output_directory`

## Tests executed
`python -m pytest -q test_cogs_v15.py test_real_reconciliation.py` — 4 passed.
