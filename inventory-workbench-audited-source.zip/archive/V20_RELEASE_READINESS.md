# Version 20 — Security and browser test preparation

## Implemented
- Fixed a verified authorization gap: a maker could previously fetch any review by ID, including another maker’s full evidence payload. The review detail endpoint now rejects such access.
- Added an isolated SQLite regression test for review-detail access, list isolation and unauthenticated access.
- Added a runnable Playwright Chromium smoke + API approval workflow test script. It is **not** a true UI click-through test and must not be reported as such.

## Not completed
- Live Chromium E2E against FastAPI; full button-click E2E, PostgreSQL live migration, entity-scoped checker access, Ind AS 2 independent signoff, live multi-ERP source validation, production security review.
- This version is NOT production certified.
