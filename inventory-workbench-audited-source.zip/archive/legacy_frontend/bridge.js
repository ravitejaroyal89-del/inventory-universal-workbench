/* Verified server approval bridge. No local approval shortcut. */
let accessToken='',activeReview=null;
async function callApi(path,method='GET',body){const res=await fetch('/api'+path,{method,headers:{'Content-Type':'application/json',...(accessToken?{Authorization:'Bearer '+accessToken}:{})},...(body!==undefined?{body:JSON.stringify(body)}:{})});const data=await res.json();if(!res.ok)throw Error(typeof data.detail==='string'?data.detail:JSON.stringify(data.detail));return data}
function msg(s){document.getElementById('secureStatus').textContent=s}
async function secureLogin(){try{const d=await callApi('/login','POST',{username:document.getElementById('secUser').value,password:document.getElementById('secPass').value});accessToken=d.access_token;document.getElementById('secPass').value='';msg('Authenticated as '+d.role)}catch(e){msg('Login failed: '+e.message)}}
async function secureSetup(){try{await callApi('/setup','POST',{username:document.getElementById('secUser').value,password:document.getElementById('secPass').value});msg('Administrator created; sign in.')}catch(e){msg(e.message)}}
async function secureLogout(){try{if(accessToken)await callApi('/logout','POST')}catch(e){}accessToken='';activeReview=null;msg('Logged out')}
async function secureCreate(){try{
 if(!accessToken)throw Error('Log in first');
 if(typeof rows==='undefined'||!rows.length)throw Error('Import source transactions first');
 if(typeof result==='undefined'||!result||!result.ok)throw Error('Resolve calculation errors first');
 const method=document.getElementById('method').value;
 if(!['fifo','moving'].includes(method))throw Error('This approval gate supports FIFO and moving weighted average only');
 const supported=new Set(['OPEN','PURCHASE','RECEIPT','RETURN_IN','ADJUST_IN','ISSUE','COGS','CONSUMPTION','RETURN_OUT','ADJUST_OUT']);
 const source_rows=rows.map((r,i)=>{const type=String(r.type||'').toUpperCase();if(!supported.has(type))throw Error('Row '+(i+1)+' uses '+type+'; server approval for transfers, cost settlements and NRV is not yet supported');return {date:r.date,item:r.item,location:r.location,type,qty:r.qty,rate:r.rate}});
 if((result.exceptions||[]).some(e=>e.severity==='ERROR'))throw Error('Resolve blocking exceptions');
 const verified=await callApi('/reference-calculate','POST',{rows:source_rows,method});
 const claimed_closing=verified.valuation.reduce((sum,v)=>sum+Number(v.value),0);
 const payload={source_rows,method,claimed_closing,blocking_errors:[],reference_metrics:verified.metrics,verification_scope:verified.scope};
 const d=await callApi('/reviews','POST',{period:document.getElementById('secPeriod').value,entity:document.getElementById('secEntity').value,payload});
 activeReview=d.id;document.getElementById('secReview').value=d.id;msg('Server-verified draft #'+d.id+' created. Submit for independent review.');
 }catch(e){msg('Cannot create: '+e.message)}}
async function secureSubmit(){try{const id=Number(document.getElementById('secReview').value||activeReview);const d=await callApi('/reviews/'+id+'/submit','POST');msg('Review #'+id+': '+d.status)}catch(e){msg(e.message)}}
async function secureApprove(){try{const id=Number(document.getElementById('secReview').value||activeReview);const d=await callApi('/reviews/'+id+'/approve','POST',{comment:document.getElementById('secComment').value});msg('Review #'+id+': '+d.status)}catch(e){msg(e.message)}}
async function secureVerify(){try{msg(JSON.stringify(await callApi('/audit/verify')))}catch(e){msg(e.message)}}

async function secureReject(){try{const id=Number(document.getElementById('secReview').value||activeReview);const d=await callApi('/reviews/'+id+'/reject','POST',{comment:document.getElementById('secComment').value});msg('Review #'+id+': '+d.status);await secureRefresh()}catch(e){msg('Reject failed: '+e.message)}}
async function secureRefresh(){try{const data=await callApi('/reviews');const body=document.getElementById('approvalQueueBody');if(!body)return;body.replaceChildren();for(const r of data.reviews){const tr=document.createElement('tr');for(const field of ['id','entity','period','status','maker','checker']){const td=document.createElement('td');td.textContent=r[field]??'—';tr.appendChild(td)}const td=document.createElement('td');const btn=document.createElement('button');btn.textContent='Select';btn.addEventListener('click',()=>{document.getElementById('secReview').value=r.id;secureInspect()});td.appendChild(btn);tr.appendChild(td);body.appendChild(tr)}msg('Loaded '+data.reviews.length+' review records')}catch(e){msg('Queue failed: '+e.message)}}
async function secureInspect(){try{const id=Number(document.getElementById('secReview').value||activeReview);if(!id)throw Error('Choose a review ID');const r=await callApi('/reviews/'+id);document.getElementById('approvalDetails').textContent=JSON.stringify({id:r.id,status:r.status,entity:r.entity,period:r.period,maker:r.maker,checker:r.checker,created_at:r.created_at,approved_at:r.approved_at,payload_hash:r.payload_hash,method:r.payload?.method,claimed_closing:r.payload?.claimed_closing,reference_metrics:r.payload?.reference_metrics,source_transaction_count:r.payload?.source_rows?.length},null,2);msg('Review #'+id+' inspected')}catch(e){msg('Inspection failed: '+e.message)}}
