# Version 12 — Deployment and evidence requirements

## PostgreSQL
- Create a NEW PostgreSQL database and restricted application user. Back up any existing database before migration.
- Apply `migrations/001_postgresql.sql` using `psql -v ON_ERROR_STOP=1 -f migrations/001_postgresql.sql`.
- Set `DATABASE_URL=postgresql+psycopg://USER:PASSWORD@HOST:5432/DBNAME` through environment secrets.
- Install dependencies from requirements.txt; launch `uvicorn server:app --host 127.0.0.1 --port 8000` behind TLS termination.
- For initial account creation only, temporarily set `ALLOW_BOOTSTRAP=1`, invoke setup once, then disable it.
- Verify migrations, backup/restore, role separation, entity access, rate limiting, and deployment configuration before real data use.

## Limitations
- SQL migration file is authored but NOT executed on live PostgreSQL; existing app still uses runtime CREATE TABLE and has no production-grade migration tracking.
- New accounting tests cover NRV and landed-cost examples only, not all Ind AS 2 rules.
- Illustrative generic CSV is synthetic, NOT evidence of Tally/SAP/Oracle/D365/BUSY/Zoho/ERPNext compatibility.
- Browser end-to-end suite and real ERP data verification remain outstanding.
- Never use for statutory approval until independent accounting, security, UAT and real ERP tests pass.
