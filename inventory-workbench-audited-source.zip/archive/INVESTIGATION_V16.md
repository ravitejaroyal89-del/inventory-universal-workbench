# Version 16 — Inventory transaction evidence investigation

## Implemented
- Preserved Version 15 and added `ivr_diagnostics_v16.py`, an ERP-neutral, read-only inventory movement evidence inspector.
- Groups transaction rows by entity, centre and item; separates opening balances from movements.
- Highlights zero-quantity/nonzero-value postings, missing opening evidence, missing financial fields, and negative net reported quantities.
- Produces CSV and JSON evidence reports without posting journals or assuming that a value-only sales posting represents physical consumption.

## Actual results
```json
{
  "source_transaction_rows": 105991,
  "item_centre_keys": 6820,
  "reference_class_counts": {
    "OPENING": 6820,
    "SALES_REVIEW": 8955,
    "OTHER_REVIEW": 36375,
    "PURCHASE_REVIEW": 2252,
    "TRANSFER_REVIEW": 51589
  },
  "flagged_key_counts": {
    "VALUE_WITH_ZERO_QUANTITY": 2967,
    "NEGATIVE_NET_QUANTITY_REVIEW": 16
  },
  "critical_caution": "Summing inventory financial and physical amounts can double count or misstate valuation. Value-only postings with zero quantity are common. No weighted-average, COGS or closing stock certification is claimed."
}
```

## Important limitations
- IVR reported quantity and amount are not independently verified closing stock. Financial and physical postings may overlap or be revaluations; simple aggregation is diagnostic only.
- True independent moving weighted-average requires confirmed receipt/issue directions, financial/physical posting semantics, opening balances, item/UOM and currency mappings, chronological ordering, cost adjustments and settlement treatment. The supplied exports do not yet prove all these interpretations.
- Actual inventory issues have NOT been independently matched to September/October centre COGS reports; those are aggregated reports and may contain provisions and classification differences.
- No live PostgreSQL migration, complete Ind AS 2 certification, or full browser regression has been performed.

## Run
`python ivr_diagnostics_v16.py "Consol_IVR_Inventory_Oct_2026_All_Entities (2).xlsx" investigation_outputs`
