# Version 19 — Browser-integrated maker/checker

## Added
- Server-backed review queue (maker sees own records; checker/admin sees queue).
- Browser selection, evidence summary inspection, approve and reject actions.
- Server-side rejection requires checker/admin role, a separate user, SUBMITTED state and a reason (3+ characters).
- All actions authenticated using an in-memory bearer token.
- Server stores rejection and approval decisions in the audit chain.

## Run locally
`pip install -r requirements.txt` then `ALLOW_BOOTSTRAP=1 uvicorn server:app --host 127.0.0.1 --port 8000`. Open http://127.0.0.1:8000. Create the first admin once; disable bootstrap and restart. Admin creates separate maker and checker via API POST /api/users. Import supported transactions, calculate, save draft, submit; log in as checker, refresh queue, inspect and approve/reject.

## Limitations
- Tested with SQLite for local integration; no live PostgreSQL migration or production deployment verified.
- The approval gate supports only explicitly supported FIFO/moving-average transaction types; does not certify Ind AS 2.
- The review queue is not entity-restricted for checkers/admins. Do not use with multiple confidential entities until row-level access policies are implemented.
- No password reset, MFA, rate limits, CSRF assessment or independent penetration test.
- No live browser automation completed unless separately evidenced in test results.
