import os, sys, importlib, uuid
from fastapi.testclient import TestClient

def test_maker_cannot_view_another_makers_evidence(tmp_path,monkeypatch):
 monkeypatch.setenv('DATABASE_URL','sqlite:///'+str(tmp_path/'isolated.db'))
 monkeypatch.setenv('ALLOW_BOOTSTRAP','1')
 sys.modules.pop('server',None)
 import server
 importlib.reload(server)
 client=TestClient(server.app)
 def post(path,body,token=None):
  return client.post('/api'+path,json=body,headers={'Authorization':'Bearer '+token} if token else {})
 pw='A-strong-password-2026!'
 assert post('/setup',{'username':'admin','password':pw}).status_code==200
 admin=post('/login',{'username':'admin','password':pw}).json()['access_token']
 for name in ('maker1','maker2'):
  assert post('/users',{'username':name,'password':pw,'role':'maker'},admin).status_code==200
 for username in ('maker1','maker2'):
  assert post('/entity-access',{'username':username,'entity':'A'},admin).status_code==200
 a=post('/login',{'username':'maker1','password':pw}).json()['access_token']
 b=post('/login',{'username':'maker2','password':pw}).json()['access_token']
 r=post('/reviews',{'period':'2026-10','entity':'A','payload':{'secret':'private-source-data'}},a)
 assert r.status_code==200
 rid=r.json()['id']
 assert client.get(f'/api/reviews/{rid}',headers={'Authorization':'Bearer '+a}).status_code==200
 assert client.get(f'/api/reviews/{rid}',headers={'Authorization':'Bearer '+b}).status_code==403
 assert all(x['id']!=rid for x in client.get('/api/reviews',headers={'Authorization':'Bearer '+b}).json()['reviews'])
 assert client.get(f'/api/reviews/{rid}').status_code==401
