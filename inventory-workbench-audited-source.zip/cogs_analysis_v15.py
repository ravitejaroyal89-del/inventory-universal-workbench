"""Read-only reconciliation of reported centre COGS, NOT independent costing certification."""
from pathlib import Path
from decimal import Decimal, InvalidOperation
from collections import Counter
import csv,json,sys
from real_data_import import rows_xlsx

def dec(v):
 try:
  if v is None or str(v).strip()=='':return None
  d=Decimal(str(v).replace(',',''))
  return d if d.is_finite() else None
 except (InvalidOperation,ValueError):return None

def get(row,col):return dec(row.get(col))
def txt(d):return str(d) if d is not None else ''
def centre(v):return str(v or '').strip().upper()
def load(path,period):
 it=rows_xlsx(path); next(it);next(it)
 results={}; problems=[]
 for index,row in enumerate(it,3):
  code=centre(row.get(0))
  if not code or code in ('TOTAL','GRAND TOTAL') or code.startswith('TOTAL '):continue
  if not any(get(row,i) is not None for i in (2,3,4,5,6,7,9,10)):continue
  if code in results:
   problems.append({'period':period,'centre':code,'row':index,'issue':'DUPLICATE_CENTRE'});continue
  if period=='SEP':
   entry={'period':period,'centre':code,'name':str(row.get(1) or ''),'pharmacy_billable':get(row,5),'dialysis_billable':get(row,2),'dialysis_nonbillable':get(row,3),'reported_rate':get(row,4),'provision':None,'dialysis_total':None,'sessions_actual':get(row,9),'sessions_forecast':None}
  else:
   entry={'period':period,'centre':code,'name':str(row.get(1) or ''),'pharmacy_billable':get(row,2),'dialysis_billable':get(row,3),'dialysis_nonbillable':get(row,4),'reported_rate':get(row,5),'provision':get(row,6),'dialysis_total':get(row,7),'sessions_actual':get(row,9),'sessions_forecast':get(row,10)}
  results[code]=entry
 return results,problems

def analyse(folder,out):
 folder=Path(folder);out=Path(out);out.mkdir(parents=True,exist_ok=True)
 sep,ps=load(folder/'09 Item-wise_COGS_Report_Sep 2026.xlsx','SEP')
 oct_,po=load(folder/'10 Item-wise_COGS_Report_25th Oct 2026 - Final.xlsx','OCT')
 data=[];stats=Counter();warnings=ps+po
 for period,entries in [('SEP',sep),('OCT',oct_)]:
  for code,r in sorted(entries.items()):
   bill=r['dialysis_billable'];non=r['dialysis_nonbillable'];provision=r['provision'];reported=r['dialysis_total']
   actual=(bill or Decimal(0))+(non or Decimal(0)) if bill is not None or non is not None else None
   derived=(actual or Decimal(0))+(provision or Decimal(0)) if actual is not None or provision is not None else None
   variance=reported-derived if reported is not None and derived is not None else None
   sessions=r['sessions_actual']; rate=(actual/sessions) if actual is not None and sessions is not None and sessions>0 else None
   rate_variance=r['reported_rate']-rate if r['reported_rate'] is not None and rate is not None else None
   status='NO_REPORTED_TOTAL' if reported is None else ('RECONCILED' if variance is not None and abs(variance)<=Decimal('0.02') else 'REVIEW_TOTAL')
   if sessions==0 and actual is not None and actual!=0:warnings.append({'period':period,'centre':code,'issue':'COGS_WITH_ZERO_SESSIONS'})
   if rate_variance is not None and abs(rate_variance)>Decimal('0.02'):warnings.append({'period':period,'centre':code,'issue':'RATE_MISMATCH_REVIEW_DENOMINATOR'})
   stats[period+'_'+status]+=1
   data.append({'period':period,'centre':code,'centre_name':r['name'],'pharmacy_billable_reported':txt(r['pharmacy_billable']),'dialysis_billable_reported':txt(bill),'dialysis_nonbillable_reported':txt(non),'dialysis_actual_components':txt(actual),'dialysis_provision_reported':txt(provision),'dialysis_total_derived':txt(derived),'dialysis_total_reported':txt(reported),'dialysis_total_variance':txt(variance),'actual_sessions_reported':txt(sessions),'forecast_sessions_reported':txt(r['sessions_forecast']),'reported_cogs_per_session':txt(r['reported_rate']),'computed_actual_component_per_session':txt(rate),'rate_difference':txt(rate_variance),'status':status})
 keys=list(data[0]) if data else ['period','centre','status']
 with open(out/'cogs_centre_comparison.csv','w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(data)
 with open(out/'cogs_review_flags.csv','w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['period','centre','issue','row'],extrasaction='ignore');w.writeheader();w.writerows(warnings)
 summary={'centres_sep':len(sep),'centres_oct':len(oct_),'statuses':dict(stats),'review_flags':len(warnings),'critical_limitations':['Reported billable/non-billable components are not independently validated stock consumption','October provision is separately shown, not automatically assumed to be a posted expense','September file has no equivalent explicit provision column in the inspected sheet','Different periods: September 1-30 vs October 1-25 plus forecast 26-31; do not interpret period changes as like-for-like','COGS per session may use another denominator; calculated rate is diagnostic only','No journal entries generated or posted']}
 (out/'COGS_ANALYSIS_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 return summary
if __name__=='__main__':print(json.dumps(analyse(sys.argv[1],sys.argv[2]),indent=2))
