# Version 37 implementation and remaining gaps

## Newly implemented
- Paired inventory location transfer costing using `transfer_ref` in the Python reference ledger, with source-derived cost and unmatched/mismatched transfer validation.
- Inventory subledger-to-GL reference variance reconciliation, duplicate-key checks and tolerance-based exceptions.
- New Node API `/api/inventory-gl-reconcile` using existing authentication and entity-access middleware.
- Targeted tests in `test_inventory_v37.py`.

## Still unverified or incomplete
- Full ERP posting semantics, cost settlement, valuation dimensions, returns and landed costs.
- PostgreSQL live migration/persistence and complete frontend wiring.
- Independent Excel models are preserved from prior versions, but are not yet expanded to all scenarios.
- Full Node/React build, browser E2E, live ERP connector, security penetration testing and actual user acceptance testing.
- No independent Ind AS 2 certification; no automatic journal posting.

Do not describe this as a production release.
