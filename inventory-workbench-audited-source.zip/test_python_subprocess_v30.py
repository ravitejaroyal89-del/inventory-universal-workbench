import subprocess,sys,json
from pathlib import Path
CLI=Path(__file__).parent/'python_engine'/'cli.py'
def call(obj):
 p=subprocess.run([sys.executable,str(CLI)],input=json.dumps(obj),text=True,capture_output=True,timeout=10)
 return p,json.loads(p.stdout)
def test_calculation_subprocess():
 p,d=call({'action':'calculate','method':'fifo','rows':[{'date':'2026-10-01','item':'A','location':'W','type':'OPEN','qty':10,'rate':5},{'date':'2026-10-02','item':'A','location':'W','type':'ISSUE','qty':2}]})
 assert p.returncode==0 and d['ok'] and float(d['valuation'][0]['value'])==40
def test_rejects_unknown_action():
 p,d=call({'action':'delete_database'})
 assert p.returncode!=0 and not d['ok']
def test_rejects_non_object():
 p,d=call([])
 assert p.returncode!=0 and not d['ok']
