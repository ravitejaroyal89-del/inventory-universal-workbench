# Inventory Workbench website

Professional responsive React interface with an interactive example dashboard. Search, warehouse and stock-status filters, item details, CSV report export and Excel model download operate in the browser.

The dashboard is explicitly illustrative. Original valuation, approval, account administration and reconciliation screens are retained in `react/src/Workbench.tsx`. Their `/api` requests require the separately deployed original API and its authentication, permissions and database. Static Sites hosting does not deploy that backend. See the original README and backend documentation before connecting production records.

Run `npm install` and `npm run dev` in `react/`. `npm run build` emits `dist/`.

The `.openai/hosting.json` manifest records the private hosted Site. The original source and Python accounting engine are retained.

## India benchmark and control desk

`INDIA_COMPETITOR_BENCHMARK.md` and the website's India benchmark cover 13 inventory/accounting products plus two adjacent global close-control platforms. The research uses official vendor documentation, is dated 1 November 2026, and is representative rather than exhaustive. It does not rank market share, prices, or claim feature superiority. The product status page separates working browser functions from incomplete integration.

The new Control desk accepts aligned stock-to-GL balance pairs through CSV and compares by entity/account/currency/period. It uses BigInt minor-unit arithmetic for amounts with at most two decimals. It rejects duplicate keys, invalid amounts, unsupported precision and invalid periods, and exports the exact tolerance, inputs, differences and investigation notes. It does not retrieve source data, validate completeness, perform FX conversion, post journals, persist approvals or create a server audit trail. Results exist only in the mounted component's memory and are cleared when leaving the tool.

Validation: `node verification/test_browser_reconciliation.cjs` tests monetary boundaries, malformed inputs, CSV quotation, duplicate keys, CSV formula escaping, and agreement with the independent Python comparison engine. The React production build and desktop/mobile browser workflows also passed during implementation.

## Live backend upgrade

The later live-workspace release supersedes the static-only deployment limitations above. Read `LIVE_WORKSPACE.md` for delivered functionality, setup, accounting scope and remaining direct ERP connection requirements. Source and schema migrations are retained; the live runtime is a Worker plus D1 rather than the original Node/Python web servers.
