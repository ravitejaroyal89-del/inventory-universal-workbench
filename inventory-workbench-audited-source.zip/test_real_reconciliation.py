from pathlib import Path
from decimal import Decimal
from real_reconciliation import num, key, reconcile

def test_normalization():
 assert key(' phnh ',' po1 ',' p1 ')==('PHNH','PO1','P1')
 assert num('1,250.50')==Decimal('1250.50')

def test_readonly_reconciliation(tmp_path):
 import os,pytest
 source=Path(os.environ.get('INVENTORY_TEST_DATA_DIR','/mnt/data'))
 if not (source/'Consol_IVR_Inventory_Oct_2026_All_Entities (2).xlsx').exists():pytest.skip('Private reconciliation workbooks unavailable; historical outputs are not validation')
 result=reconcile(source,tmp_path)
 assert sum(result['po_grn']['statuses'].values())==2327
 assert sum(result['ivr_closing']['statuses'].values())==7174
 assert (tmp_path/'po_grn_reconciliation.csv').exists()
 assert (tmp_path/'ivr_closing_stock_comparison.csv').exists()
