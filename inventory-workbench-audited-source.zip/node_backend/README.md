# Node.js + TypeScript backend (v25)

Node/Express is the HTTP API. The inventory calculation runs in a **separate Python process**, using only stdin/stdout JSON. The engine does not import Express, FastAPI, React or databases.

Run: `npm install && npm run check && npm run dev` in `node_backend/`. Python 3 must be installed. Test `POST http://localhost:3001/api/reference-calculate` with `{"method":"moving","rows":[{"date":"2026-10-01","item":"A","location":"L","type":"OPEN","qty":10,"rate":5}]}`.

Security note: Node currently implements health and reference calculation only. Authentication, approvals, PostgreSQL persistence and audit remain in the existing FastAPI server; the Node API deliberately returns HTTP 501 for unmigrated endpoints. **Do not replace the existing API for production** until these are ported and tested. No live PostgreSQL or browser E2E verification is claimed.
