import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {attachSecurity,requireAuth,requireEntityRecords} from './security.js';

const app=express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({origin:process.env.CORS_ORIGIN?.split(',')||false}));
app.use(express.json({limit:'5mb'}));
app.use('/api',rateLimit({windowMs:60_000,limit:120,standardHeaders:'draft-7',legacyHeaders:false}));
// Apply a separate, stricter limiter before credential verification.
app.use('/api/login',rateLimit({windowMs:15*60_000,limit:10,standardHeaders:'draft-7',legacyHeaders:false}));
app.use('/api/setup',rateLimit({windowMs:15*60_000,limit:5,standardHeaders:'draft-7',legacyHeaders:false}));
const current=path.dirname(fileURLToPath(import.meta.url));
const cli=path.resolve(current,'../../python_engine/cli.py');
const python=process.env.PYTHON_BIN||'python3';

export function calculateInPython(payload:unknown):Promise<unknown>{
 return new Promise((resolve,reject)=>{
  const child=spawn(python,[cli],{stdio:['pipe','pipe','pipe'],env:{...process.env,PYTHONPATH:path.dirname(cli)}});
  let output='',error='';
  const timer=setTimeout(()=>{child.kill('SIGKILL');reject(new Error('Calculation timed out'))},30000);
  child.stdout.on('data',(b:Buffer)=>{output+=b.toString();if(output.length>20_000_000)child.kill('SIGKILL')});
  child.stderr.on('data',(b:Buffer)=>{error+=b.toString().slice(0,1000)});
  child.on('error',e=>{clearTimeout(timer);reject(e)});
  child.on('close',()=>{clearTimeout(timer);try{resolve(JSON.parse(output))}catch{reject(new Error('Python calculation process failed: '+error.slice(0,200)))}});
  child.stdin.on('error',()=>{});
  child.stdin.end(JSON.stringify(payload));
 });
}
attachSecurity(app,calculateInPython);
app.get('/api/health',(_req,res)=>res.json({ok:true,backend:'node-typescript',engine:'independent-python'}));
app.post('/api/reference-calculate',requireAuth,requireEntityRecords,async(req,res)=>{
 const {rows,method='moving'}=req.body||{};
 if(!Array.isArray(rows)||!rows.length||rows.length>100000||!['moving','fifo'].includes(method))return res.status(400).json({detail:'Invalid rows or method'});
 try{const result=await calculateInPython({action:'calculate',rows,method}) as {ok:boolean;error?:string};if(!result.ok)return res.status(422).json({detail:result.error});res.json(result)}
 catch(e){res.status(503).json({detail:'Independent calculation engine unavailable'})}
});
app.post('/api/intercompany-reconcile',requireAuth,requireEntityRecords,async(req,res)=>{
 const documents=req.body?.documents;
 if(!Array.isArray(documents)||documents.length>100000)return res.status(400).json({detail:'Invalid documents'});
 try{const result=await calculateInPython({action:'intercompany_reconcile',documents}) as {ok:boolean;error?:string};if(!result.ok)return res.status(422).json({detail:result.error});res.json(result)}
 catch(_e){res.status(503).json({detail:'Reconciliation engine unavailable'})}
});
app.post('/api/intercompany-financial',requireAuth,requireEntityRecords,async(req,res)=>{
 const records=req.body?.records;
 if(!Array.isArray(records)||records.length>100000)return res.status(400).json({detail:'Invalid financial records'});
 try{const result=await calculateInPython({action:'intercompany_financial',records,policy:req.body?.policy}) as {ok:boolean;error?:string};if(!result.ok)return res.status(422).json({detail:result.error});res.json(result)}
 catch(_e){res.status(503).json({detail:'Financial reconciliation engine unavailable'})}
});
// Inventory transaction reference ledger; entity access required; no posting.
app.post('/api/transaction-ledger',requireAuth,requireEntityRecords,async(req,res)=>{
 const records=req.body?.records; const method=req.body?.method||'moving';
 if(!Array.isArray(records)||!records.length||records.length>100000||!['moving','fifo'].includes(method))return res.status(400).json({detail:'Invalid ledger records or method'});
 try{const result=await calculateInPython({action:'transaction_ledger',records,method}) as {ok:boolean;error?:string};if(!result.ok)return res.status(422).json({detail:result.error});res.json(result)}
 catch(_e){res.status(503).json({detail:'Inventory ledger engine unavailable'})}
});
// Inventory-only independent controls. All outputs are proposals, never posted journals.
for(const action of ['stock_count_reconcile','inventory_nrv','inventory_rollforward'] as const){
 app.post('/api/'+action,requireAuth,requireEntityRecords,async(req,res)=>{
  const records=req.body?.records;
  if(!Array.isArray(records)||!records.length||records.length>100000)return res.status(400).json({detail:'Invalid records'});
  try{const result=await calculateInPython({action,records,tolerance:req.body?.tolerance}) as {ok:boolean;error?:string};if(!result.ok)return res.status(422).json({detail:result.error});res.json(result)}
  catch(_e){res.status(503).json({detail:'Inventory engine unavailable'})}
 });
}
// Reference inventory-to-GL variance report; server-side entity permission enforced.
app.post('/api/inventory-gl-reconcile',requireAuth,requireEntityRecords,async(req,res)=>{
 const records=req.body?.records;
 if(!Array.isArray(records)||!records.length||records.length>100000)return res.status(400).json({detail:'Invalid records'});
 try{const result=await calculateInPython({action:'inventory_gl_reconcile',records,tolerance:req.body?.tolerance}) as {ok:boolean;error?:string};if(!result.ok)return res.status(422).json({detail:result.error});res.json(result)}
 catch(_e){res.status(503).json({detail:'Inventory reconciliation engine unavailable'})}
});
// Unimplemented endpoints fail closed.
app.use('/api',(_req,res)=>res.status(501).json({detail:'Endpoint not migrated to Node.js; use legacy FastAPI service for approvals'}));
if(process.env.NODE_ENV!=='test'){app.listen(Number(process.env.PORT||3001),process.env.HOST||'127.0.0.1',()=>console.log('Inventory Node API listening'))}
export default app;
