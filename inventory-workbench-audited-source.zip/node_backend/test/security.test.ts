import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import type {AddressInfo} from 'node:net';
process.env.NODE_ENV='test';process.env.ALLOW_BOOTSTRAP='1';
const tmp=mkdtempSync(path.join(tmpdir(),'inventory-node-test-'));process.env.AUTH_DB_PATH=tmp+'/auth.db';
const {default:app}=await import('../src/server.js');
const password='AuditFixturePassword123!';
const rows=[{entity:'E1',date:'2026-10-01',item:'A',location:'W',type:'OPEN',qty:10,rate:5}];
test('retained Node API accounting and review security',async t=>{
 const server=app.listen(0,'127.0.0.1');await new Promise<void>(resolve=>server.once('listening',resolve));const base='http://127.0.0.1:'+(server.address() as AddressInfo).port+'/api';
 const db=new DatabaseSync(process.env.AUTH_DB_PATH!);
 async function call(route:string,body?:unknown,token='',status=200){const res=await fetch(base+route,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});const data=await res.json();assert.equal(res.status,status,JSON.stringify(data));return data}
 try{
 await call('/setup',{username:'admin',password},'',201);const admin=(await call('/login',{username:'admin',password})).access_token;
 for(const role of ['maker','checker']){await call('/users',{username:role,password,role},admin,201);await call('/entity-access',{username:role,entity:'E1'},admin)}
 const maker=(await call('/login',{username:'maker',password})).access_token,checker=(await call('/login',{username:'checker',password})).access_token;
 const draft=async(source_rows=rows)=>await call('/reviews',{entity:'E1',period:'2026-10',payload:{method:'fifo',source_rows,claimed_closing:50}},maker,201);
 await t.test('unauthenticated calculation rejected',async()=>{await call('/reference-calculate',{rows},'',401)});
 await t.test('source entity access enforced',async()=>{await call('/reference-calculate',{rows:[{...rows[0],entity:'OTHER'}]},maker,403)});
 await t.test('verified FIFO closing agrees to hand calculation',async()=>{const r=await call('/reference-calculate',{rows,method:'fifo'},maker);assert.equal(r.metrics.closing,'50')});
 await t.test('cross-entity review payload rejected',async()=>{const r=await draft([{...rows[0],entity:'OTHER'}]);await call('/reviews/'+r.id+'/submit',{},maker,422)});
 await t.test('saved hash tampering blocks submission',async()=>{const r=await draft();db.prepare('UPDATE reviews SET payload=? WHERE id=?').run('{}',r.id);await call('/reviews/'+r.id+'/submit',{},maker,422)});
 const r=await draft();await call('/reviews/'+r.id+'/submit',{},maker);
 await t.test('maker cannot approve own submitted review',async()=>{await call('/reviews/'+r.id+'/approve',{comment:'I checked this'},maker,403)});
 await t.test('concurrent checker decisions commit only once',async()=>{const results=await Promise.all(['approve','approve'].map(action=>fetch(base+'/reviews/'+r.id+'/'+action,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+checker},body:JSON.stringify({comment:'Independent review evidence'})})));assert.deepEqual(results.map(r=>r.status).sort(),[200,409])});
 await t.test('retained audit chain verifies',async()=>{assert.equal((await call('/audit/verify',undefined,admin)).valid,true)});
 }finally{db.close();await new Promise<void>(resolve=>server.close(()=>resolve()));rmSync(tmp,{recursive:true,force:true})}
});
