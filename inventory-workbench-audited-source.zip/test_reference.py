import pytest
from reference_engine import calculate

def rows():return [dict(date='2026-01-01',item='A',location='WH',type='OPEN',qty=10,rate=10),dict(date='2026-01-02',item='A',location='WH',type='PURCHASE',qty=10,rate=20),dict(date='2026-01-03',item='A',location='WH',type='COGS',qty=5)]

def test_fifo():
 r=calculate(rows(),'fifo');assert r['metrics']['cogs']=='50';assert r['metrics']['closing']=='250';assert r['metrics']['rollforwardDifference']=='0'

def test_moving():
 r=calculate(rows(),'moving');assert r['metrics']['cogs']=='75';assert r['metrics']['closing']=='225'

def test_negative_stock():
 with pytest.raises(ValueError,match='Negative stock'):calculate([dict(date='2026-01-01',item='A',location='WH',type='COGS',qty=1)])

def test_backdated_reordering():
 r=rows();r[0]['date']='2026-01-02';r[1]['date']='2026-01-01';assert calculate(r,'fifo')['metrics']['cogs']=='100'

def test_reject_unsupported_transfer():
 with pytest.raises(ValueError,match='Unsupported'):calculate([dict(date='2026-01-01',item='A',location='WH',type='TRANSFER_IN',qty=1,rate=10)])
