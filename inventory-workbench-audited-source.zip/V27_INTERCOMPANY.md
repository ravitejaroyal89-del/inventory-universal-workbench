# V27 Intercompany document reconciliation

Added independent Python order-level matching of SO, PO, packing slip, GRN and delivery report, Node/TypeScript API endpoint `/api/intercompany-reconcile`, and a React import/results tab. CSV header: `type,selling_entity,buying_entity,item,intercompany_order,quantity,value,date,document_no`. Entity/item/order are required. Dates and document numbers are evidence only.

**Limits:** This is not a full financial reconciliation. Sales/purchase invoices, intercompany AR/AP, transfer prices, foreign currencies, COGS, actual inventory valuation and unrealised profit elimination require additional ledgers and accounting policies. No live ERP connector or production browser test. Node dependencies may not be available for compilation.
