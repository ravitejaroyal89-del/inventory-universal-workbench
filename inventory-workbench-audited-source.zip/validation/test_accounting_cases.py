from accounting_cases import nrv, landed_cost
from decimal import Decimal as D
import pytest

def test_nrv_write_down():
 r=nrv(100,90,5,3);assert r['carrying']==D('82') and r['required_write_down']==D('18')
def test_nrv_reversal_limited():
 r=nrv(100,110,0,0,25);assert r['reversal']==D('25') and r['carrying']==D('100')
def test_nrv_partial_reversal():
 r=nrv(100,90,0,0,25);assert r['reversal']==D('15')
def test_landed_cost_excludes_recoverable_tax():
 r=landed_cost(10,100,50,25,180);assert r['capitalizable_cost']==D('1075') and r['unit_cost']==D('107.5')
def test_invalid_landed_cost():
 with pytest.raises(ValueError):landed_cost(0,100)
