"""Independent deterministic inventory accounting checks; NOT a complete Ind AS 2 certification."""
from decimal import Decimal as D

def nrv(cost, selling_price, completion=0, selling_cost=0, previous_write_down=0):
    vals=list(map(lambda x:D(str(x)),(cost,selling_price,completion,selling_cost,previous_write_down)))
    c,s,comp,sell,prev=vals
    if any(x<0 for x in vals): raise ValueError('negative input')
    net=max(D(0),s-comp-sell)
    carrying=min(c,net)
    write_down=max(D(0),c-net)
    # reversal never exceeds original write-down, or amount needed to restore to current lower-of-cost-and-NRV
    reversal=min(prev,max(D(0),prev-write_down))
    return {'nrv':net,'carrying':carrying,'required_write_down':write_down,'reversal':reversal}

def landed_cost(quantity,unit_cost,freight=0,nonrecoverable_duties=0,recoverable_tax=0):
    q,u,f,d,t=map(lambda x:D(str(x)),(quantity,unit_cost,freight,nonrecoverable_duties,recoverable_tax))
    if min(q,u,f,d,t)<0 or q==0:raise ValueError('invalid cost input')
    return {'capitalizable_cost':q*u+f+d,'excluded_recoverable_tax':t,'unit_cost':(q*u+f+d)/q}
