import csv
from pathlib import Path
from decimal import Decimal as D
from reference_engine import calculate

def test_fixture_fifo_and_moving():
 with (Path(__file__).resolve().parents[1]/'fixtures/illustrative_generic_transactions.csv').open() as f: rows=list(csv.DictReader(f))
 a=calculate(rows,'fifo');b=calculate(rows,'moving')
 assert D(a['metrics']['cogs'])==D('1240')
 assert D(a['metrics']['closing'])==D('960')
 assert D(b['metrics']['cogs'])==D('1320')
 assert D(b['metrics']['closing'])==D('880')
