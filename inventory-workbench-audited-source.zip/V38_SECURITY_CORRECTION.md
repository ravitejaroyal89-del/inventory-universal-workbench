# v38: Entity security correction and accounting reference verification

## Verified code change
- Inventory calculation, inventory GL, stock counts, NRV and roll-forward endpoints require one `entity` per row and enforce user entity grants.
- Intercompany routes continue requiring `selling_entity` and `buying_entity` per row, both authorised.
- Reference valuation endpoint now uses entity-access middleware (previously only authenticated).
- This corrects a material v37 bug: inventory-only requests were incorrectly rejected for missing intercompany fields.
- Existing sample payloads lacking entity must be mapped to a valid legal entity before API submission.

## Not complete
- PostgreSQL is not the live auth database; Node security currently uses SQLite.
- React production build and browser E2E remain unverified.
- ERP connectors and user acceptance testing remain pending.
- Excel reference checks are illustrative independent formulas, not accounting certification.
- This package is not production-ready.
