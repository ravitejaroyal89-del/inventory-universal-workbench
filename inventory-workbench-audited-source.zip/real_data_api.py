"""Opt-in read-only upload API. Requires existing bearer login."""
import os,tempfile
from pathlib import Path
from fastapi import APIRouter,UploadFile,File,Depends,HTTPException
from real_data_import import profile

def router(identity):
 r=APIRouter()
 @r.post('/api/import/inspect')
 async def inspect(file:UploadFile=File(...),actor=Depends(identity)):
  name=Path(file.filename or '').name
  ext=Path(name).suffix.lower()
  if ext not in ('.xlsx','.csv'):raise HTTPException(415,'Only xlsx/csv allowed')
  fd,path=tempfile.mkstemp(suffix=ext)
  try:
   size=0
   with os.fdopen(fd,'wb') as out:
    while chunk:=await file.read(1024*1024):
     size+=len(chunk)
     if size>25*1024*1024:raise HTTPException(413,'Maximum upload 25MB')
     out.write(chunk)
   result=profile(path);result['file']=name
   return result
  except (ValueError,KeyError,IndexError) as exc:raise HTTPException(422,str(exc))
  finally:
   try:os.remove(path)
   except OSError:pass
 return r
