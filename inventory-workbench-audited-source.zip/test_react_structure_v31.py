from pathlib import Path

def test_react_entry_and_api_sources_present():
    root=Path(__file__).parent/'react'
    assert (root/'package.json').exists()
    assert (root/'index.html').exists()
    assert list((root/'src').rglob('*.tsx'))
    assert (Path(__file__).parent/'node_backend'/'package.json').exists()
