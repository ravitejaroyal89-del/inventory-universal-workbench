"""Run against an isolated test instance with ALLOW_BOOTSTRAP=1.
Requires pip install playwright && python -m playwright install chromium.
Usage: INVENTORY_TEST_URL=http://127.0.0.1:8000 python BROWSER_E2E_PLAYWRIGHT_V20.py
Do not point at a production database.
"""
import os,uuid
from playwright.sync_api import sync_playwright
base=os.getenv('INVENTORY_TEST_URL','http://127.0.0.1:8000')
suffix=uuid.uuid4().hex[:8]; pw='Strong-E2E-Password-2026!'
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True)
 page=browser.new_page()
 page.goto(base+'/',wait_until='domcontentloaded')
 assert 'inventory' in page.title().lower()
 # API setup of separate test users through the same browser network context.
 req=page.request
 setup=req.post(base+'/api/setup',data={'username':'admin'+suffix,'password':pw})
 if setup.status!=200: raise RuntimeError('Requires fresh isolated database with ALLOW_BOOTSTRAP=1; setup failed')
 def login(name):
  r=req.post(base+'/api/login',data={'username':name,'password':pw});assert r.ok,r.text();return r.json()['access_token']
 admin=login('admin'+suffix)
 def post(path,data,token):return req.post(base+'/api'+path,data=data,headers={'Authorization':'Bearer '+token})
 for role in ('maker','checker'):
  assert post('/users',{'username':role+suffix,'password':pw,'role':role},admin).ok
 for role in ('maker','checker'):
  assert post('/entity-access',{'username':role+suffix,'entity':'A'},admin).ok
 maker=login('maker'+suffix); checker=login('checker'+suffix)
 payload={'source_rows':[{'date':'2026-10-01','item':'A','location':'WH','type':'OPEN','qty':10,'rate':12}],'method':'fifo','claimed_closing':120,'blocking_errors':[]}
 r=post('/reviews',{'period':'2026-10','entity':'A','payload':payload},maker);assert r.ok,r.text();rid=r.json()['id']
 assert post(f'/reviews/{rid}/submit',{},maker).ok
 assert post(f'/reviews/{rid}/approve',{'comment':'Self approval'},maker).status==403
 assert post(f'/reviews/{rid}/approve',{'comment':'Checked against evidence'},checker).ok
 assert req.get(base+f'/api/reviews/{rid}',headers={'Authorization':'Bearer '+maker}).json()['status']=='APPROVED'
 assert req.get(base+'/api/audit/verify',headers={'Authorization':'Bearer '+checker}).json()['valid']
 print('PASS: Chromium page navigation + API maker/checker workflow + audit chain. NOTE: approval buttons were not clicked in this test.')
 browser.close()
