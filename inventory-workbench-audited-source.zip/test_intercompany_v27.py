import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'python_engine'))
from intercompany import reconcile
import pytest

def doc(t,q,v=100):
 return dict(type=t,selling_entity='A',buying_entity='B',item='X',intercompany_order='IC-1',quantity=q,value=v)
def test_match():
 result=reconcile([doc(t,10) for t in ('SO','PO','PACKING_SLIP','GRN','DELIVERY_REPORT')]);assert result['summary']['matched']==1
def test_in_transit():
 result=reconcile([doc('PACKING_SLIP',10),doc('GRN',6)]);assert 'POTENTIAL_GOODS_IN_TRANSIT' in [e['code'] for e in result['groups'][0]['exceptions']]
def test_value_difference():
 result=reconcile([doc('SO',10,100),doc('PO',10,90)]);assert 'ORDER_VALUE_DIFFERENCE' in [e['code'] for e in result['groups'][0]['exceptions']]
def test_invalid():
 with pytest.raises(ValueError):reconcile([doc('UNKNOWN',10)])
