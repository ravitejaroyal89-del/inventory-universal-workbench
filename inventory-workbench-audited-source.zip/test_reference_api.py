import os,tempfile,sys
os.environ['DATABASE_URL']='sqlite:///'+tempfile.mktemp(suffix='.db')
os.environ['ALLOW_BOOTSTRAP']='1'
from fastapi.testclient import TestClient
import server
from server import app

def test_authenticated_reference_api(tmp_path, monkeypatch):
 monkeypatch.setattr(server, "engine", server.create_engine("sqlite:///"+str(tmp_path/"reference.db"),connect_args={"check_same_thread":False}))
 monkeypatch.setattr(server, "URL", "sqlite:///"+str(tmp_path/"reference.db"))
 monkeypatch.setenv("ALLOW_BOOTSTRAP","1")
 server.init()
 c=TestClient(app)
 assert c.post('/api/setup',json={'username':'admin','password':'SecurePassword123!'}).status_code==200
 token=c.post('/api/login',json={'username':'admin','password':'SecurePassword123!'}).json()['access_token']
 payload={'method':'fifo','rows':[{'date':'2026-01-01','item':'X','location':'A','type':'OPEN','qty':10,'rate':12},{'date':'2026-01-02','item':'X','location':'A','type':'COGS','qty':3}]}
 assert c.post('/api/reference-calculate',json=payload).status_code==401
 r=c.post('/api/reference-calculate',json=payload,headers={'Authorization':'Bearer '+token})
 assert r.status_code==200,r.text
 assert r.json()['metrics']['closing']=='84'
