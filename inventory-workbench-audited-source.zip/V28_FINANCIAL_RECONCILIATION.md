# Version 28 — Intercompany financial reconciliation

## Delivered
- Independent `python_engine/intercompany_financial.py` reconciliation engine
- Python CLI action `intercompany_financial`
- Node/TypeScript POST `/api/intercompany-financial`
- React `IC Financial` import, evidence summary, exception and proposed elimination screen
- Five new focused Python tests (9 with v27 tests)

## Input
CSV columns: `type,selling_entity,buying_entity,item,intercompany_order,currency,document_no,amount,quantity,cost,date,line_no`.
Types: SALES_INVOICE, PURCHASE_INVOICE, AR_OPEN, AP_OPEN, AR_SETTLEMENT, AP_SETTLEMENT, INVENTORY_RECEIPT, INVENTORY_ISSUE, COGS, CLOSING_INVENTORY.
All financial amounts must be normalized into one approved currency and comparable basis (tax exclusive where applicable). AR_OPEN/AP_OPEN must be open balances as of the same cutoff. `cost` on INVENTORY_ISSUE is verified seller issue cost; `amount` on COGS is posted cost. CLOSING_INVENTORY `quantity` is unsold units from the matched transfer, not all stock of that SKU. Documents must have traceable unique document/line identifiers. Matching is by selling entity, buying entity, item and intercompany order.

## Calculation and safeguards
- Compare sales and purchase invoice totals, AR/AP open balances and settlements separately (do not double count payments against open balances).
- Compare inventory issue and receipt quantities and seller issue cost against posted COGS.
- Only when a group has one sales invoice, one seller issue record and one closing inventory record, estimate unrealised profit = (invoice value / issued quantity − seller cost / issued quantity) × verified unsold quantity. This is a *proposal*, not a posting. In multi-line, mixed-lot or cross-period cases the engine flags incomplete evidence.
- Detect missing sides, differences, negative margins, duplicates, currency mismatches and invalid input.
- Never auto-post entries. Output includes `posting_allowed: false`.

## Limitations and release gate
- React-to-Node browser integration and Node build have not been tested here. Earlier npm dependency installation was blocked.
- No live PostgreSQL, ERP connection or independent accounting sign-off.
- Entity access controls and maker-checker exist in legacy FastAPI, **not migrated to Node**. The new financial endpoint currently has no authentication: do not expose it publicly or upload sensitive company data to a public deployment. Add Node authentication/authorization and HTTPS before deployment.
- This is evidence-level matching, not general ledger/subledger extraction, actual ERP cost reconstruction, multi-currency FX translation, or a certified Ind AS consolidation model. Confirm inventory ownership, period cutoff, FX, tax, NRV, profit elimination basis and consolidation journals independently.

## Run tests
`python -m pytest -q test_intercompany_financial_v28.py test_intercompany_v27.py`
