# Version 35 — inventory development checkpoint

## Implemented in this update
- Independent Python inventory physical count reconciliation with difference quantity/value, exceptions, and no auto-posting.
- Independent Python Ind AS 2 NRV reference model with proposed write-down/reversal movement. Historical write-down caps and full reversals need additional accounting controls.
- Independent Python item/location quantity roll-forward with exception reporting.
- Three protected Node API routes `/api/stock_count_reconcile`, `/api/inventory_nrv`, `/api/inventory_rollforward` wired to Python subprocess, requiring authentication and entity-record access middleware.
- Additional independent Excel formula models: Physical Count, NRV and Qty Rollforward; existing v33 workbook preserved.
- Eight dedicated Python tests.

## Not complete or not verified
- Full inventory master/transactions/returns/transfer workflow, detailed costing settlement, item/warehouse dimensions, GL and financial stock reconciliation.
- Full React screen-to-endpoint UI workflows, complete PostgreSQL live integration, all-role maker-checker and audit trail testing.
- All inventory intercompany edge cases, complete Ind AS 2 disclosure/reversal policies, live ERP connectors.
- Production React/Node compilation, browser E2E mobile/desktop, real UAT, independent accounting certification.
- No ERP postings or journals are executed by the new reference endpoints.

Do not treat this build as production-ready. The scope remains inventory only.
