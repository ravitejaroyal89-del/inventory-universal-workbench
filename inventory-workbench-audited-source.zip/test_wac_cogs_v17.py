import pytest
from wac_cogs_v17 import moving_average

def test_wac_receipt_issue():
 r=moving_average([{'type':'OPENING','quantity':10,'value':100},{'type':'RECEIPT','quantity':10,'value':140},{'type':'ISSUE','quantity':5}]);assert float(r['issue_cost'])==60;assert float(r['closing_value'])==180

def test_wac_sequential_cost():
 r=moving_average([{'type':'OPENING','quantity':10,'value':100},{'type':'ISSUE','quantity':5},{'type':'RECEIPT','quantity':5,'value':100},{'type':'ISSUE','quantity':4}]);assert float(r['issue_cost'])==110;assert float(r['closing_value'])==90

def test_zero_stock():
 assert moving_average([{'type':'OPENING','quantity':1,'value':7},{'type':'ISSUE','quantity':1}])['closing_value']=='0'
@pytest.mark.parametrize('events',[[{'type':'OPENING','quantity':1,'value':1},{'type':'ISSUE','quantity':2}],[{'type':'OPENING','quantity':0,'value':0},{'type':'ADJUSTMENT','quantity':0,'value':10}],[{'type':'OPENING','quantity':1,'value':1},{'type':'RECEIPT','quantity':0,'value':2}]])
def test_block_unsupported(events):
 with pytest.raises(ValueError):moving_average(events)
