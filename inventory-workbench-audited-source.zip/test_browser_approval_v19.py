from fastapi.testclient import TestClient
import server
import uuid
def test_queue_rejection_and_permissions(tmp_path, monkeypatch):
 monkeypatch.setattr(server, "engine", server.create_engine("sqlite:///"+str(tmp_path/"approval.db"),connect_args={"check_same_thread":False}))
 monkeypatch.setattr(server, "URL", "sqlite:///"+str(tmp_path/"approval.db"))
 monkeypatch.setenv("ALLOW_BOOTSTRAP","1")
 server.init()
 client=TestClient(server.app)
 suffix=uuid.uuid4().hex[:9]
 def post(path,body=None,token=None):
  return client.post('/api'+path,json=body,headers={'Authorization':'Bearer '+token} if token else {})
 pw='StrongPassword12345!'
 # test_server initializes bootstrap only when its workflow runs, so initialize here if needed
 assert post('/setup',{'username':'admin'+suffix,'password':pw}).status_code==200
 admin=post('/login',{'username':'admin'+suffix,'password':pw}).json()['access_token']
 for role in ['maker','checker']:
  assert post('/users',{'username':role+suffix,'password':pw,'role':role},admin).status_code==200
 for username in ('maker'+suffix,'checker'+suffix):
  assert post('/entity-access',{'username':username,'entity':'A'},admin).status_code==200
 maker=post('/login',{'username':'maker'+suffix,'password':pw}).json()['access_token']
 checker=post('/login',{'username':'checker'+suffix,'password':pw}).json()['access_token']
 rid=post('/reviews',{'period':'2026-10','entity':'A','payload':{'source_rows':[{'date':'2026-10-01','item':'A','location':'WH','type':'OPEN','qty':10,'rate':12}],'method':'fifo','claimed_closing':120,'blocking_errors':[]}},maker).json()['id']
 assert post(f'/reviews/{rid}/reject',{'comment':'Need evidence'},checker).status_code==409
 assert post(f'/reviews/{rid}/submit',{},maker).status_code==200
 assert post(f'/reviews/{rid}/reject',{'comment':'Need evidence'},maker).status_code==403
 assert client.get('/api/reviews',headers={'Authorization':'Bearer '+maker}).status_code==200
 queue=client.get('/api/reviews?status=SUBMITTED',headers={'Authorization':'Bearer '+checker}).json()['reviews']
 assert any(x['id']==rid for x in queue)
 assert post(f'/reviews/{rid}/reject',{'comment':'Insufficient evidence'},checker).json()['status']=='REJECTED'
 assert post(f'/reviews/{rid}/approve',{'comment':'Approved'},checker).status_code==409
 assert client.get('/api/reviews/'+str(rid),headers={'Authorization':'Bearer '+maker}).json()['status']=='REJECTED'
 assert client.get('/api/audit/verify',headers={'Authorization':'Bearer '+checker}).json()['valid']
