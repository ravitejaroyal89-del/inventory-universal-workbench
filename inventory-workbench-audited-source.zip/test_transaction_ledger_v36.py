import unittest,sys,os,json,subprocess
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'python_engine'))
from transaction_ledger import calculate_ledger
BASE={'entity':'E1','item':'SKU1','location':'WH1','currency':'INR','date':'2026-10-01'}
def row(tx,typ,qty,cost=None,**kw):
 r={**BASE,'transaction_id':tx,'type':typ,'quantity':qty,**kw}
 if cost is not None:r['unit_cost']=cost
 return r
class LedgerTests(unittest.TestCase):
 def test_moving(self):
  r=calculate_ledger([row('1','OPENING',10,10),row('2','PURCHASE_RECEIPT',10,20),row('3','SALE_ISSUE',5)])
  self.assertEqual(r['sale_cogs'],'75');self.assertEqual(r['balances'][0]['value'],'225')
 def test_fifo(self):
  r=calculate_ledger([row('1','OPENING',10,10),row('2','PURCHASE_RECEIPT',10,20),row('3','SALE_ISSUE',15)],'fifo')
  self.assertEqual(r['sale_cogs'],'200');self.assertEqual(r['balances'][0]['value'],'100')
 def test_returns_and_adjustments(self):
  r=calculate_ledger([row('1','OPENING',10,10),row('2','SALE_ISSUE',2),row('3','SALES_RETURN',1,10),row('4','ADJUSTMENT_OUT',1)])
  self.assertEqual(r['balances'][0]['quantity'],'8')
 def test_negative_stock_blocked(self):
  with self.assertRaisesRegex(ValueError,'insufficient'):calculate_ledger([row('1','SALE_ISSUE',1)])
 def test_duplicate_id(self):
  with self.assertRaisesRegex(ValueError,'Duplicate'):calculate_ledger([row('1','OPENING',1,2),row('1','SALE_ISSUE',1)])
 def test_date_order(self):
  with self.assertRaisesRegex(ValueError,'date-ordered'):calculate_ledger([row('1','OPENING',1,2,date='2026-10-02'),row('2','SALE_ISSUE',1)])
 def test_isolation(self):
  r=calculate_ledger([row('1','OPENING',1,10),row('2','OPENING',1,20,location='WH2')])
  self.assertEqual(len(r['balances']),2)
 def test_cli(self):
  p=subprocess.run([sys.executable,os.path.join(os.path.dirname(__file__),'python_engine','cli.py')],input=json.dumps({'action':'transaction_ledger','records':[row('1','OPENING',1,20)]}),capture_output=True,text=True)
  self.assertEqual(p.returncode,0,p.stderr);self.assertEqual(json.loads(p.stdout)['balances'][0]['value'],'20')
if __name__=='__main__':unittest.main()
