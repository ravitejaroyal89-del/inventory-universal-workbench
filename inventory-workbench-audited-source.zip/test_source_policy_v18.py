import csv
from source_policy_v18 import validate_mapping

def test_unresolved_is_blocked(tmp_path):
 p=tmp_path/'x.csv';p.write_text('source_reference,approved_class,approved_by,approval_date,evidence_reference\nSALES,UNRESOLVED,,,\n');assert not validate_mapping(p)['safe_for_actual_costing']
def test_approval_without_evidence_is_blocked(tmp_path):
 p=tmp_path/'x.csv';p.write_text('source_reference,approved_class,approved_by,approval_date,evidence_reference\nSALES,ISSUE,,,\n');assert validate_mapping(p)['errors']
def test_signed_complete_mapping_is_eligible_not_certified(tmp_path):
 p=tmp_path/'x.csv';p.write_text('source_reference,approved_class,approved_by,approval_date,evidence_reference\nSALES,ISSUE,Reviewer,2026-11-01,GL-123\n');r=validate_mapping(p);assert r['safe_for_actual_costing'] and 'not sufficient' in r['caution']
def test_duplicate_mapping_rejected(tmp_path):
 p=tmp_path/'x.csv';p.write_text('source_reference,approved_class,approved_by,approval_date,evidence_reference\nSALES,ISSUE,Reviewer,2026-11-01,GL-123\nSALES,ISSUE,Reviewer,2026-11-01,GL-123\n');assert validate_mapping(p)['errors']
