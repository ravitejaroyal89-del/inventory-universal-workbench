# Inventory Universal Workbench audit — 1 November 2026

This is a source audit and bounded functional verification, **not a claim of 100% functionality, accounting certification, or production readiness**. Findings distinguish the deployed application, retained reference services, illustrative screens, and features that have not been delivered.

## Pull request publication status

All code and evidence are committed on local branch `audit/workbench-verification-fixes`. Git transport rejected the push with HTTP 403 (permission denied), and the connected GitHub API independently rejected branch creation with HTTP 403, `Resource not accessible by integration`. Consequently **no remote branch or pull request was created**. The integration needs repository Contents write and Pull requests write access. This is an external authorization blocker, not a request for new task approval. A Git bundle, patch series and ready-to-use PR description are supplied for review and resumption.

## Source, preservation, and scope

The connected Site is **Inventory Workbench**, project `appgprj_6ae7902e391481918068f4bea14e7fee`, URL https://inventory-workbench-royal.moltencrane.chatgpt.site. Sites version history identifies version **4** with source commit **7788bf525defd5233fffa46afbc9fb2068d69622**. That exact source was retrieved and imported into this PR before applying fixes.

GitHub `main` at `bbed001` contained only README and `Inventory_Workbench_v39_GitHub_Ready_Source.zip`; it did not contain the later professional frontend/Worker source as individual files. The first PR commit imports the existing hosted source; subsequent commits isolate audit fixes and evidence. The original ZIP remains unchanged. Original navigation, professional styling, demo inventory, reference workbooks, accounting engines, and working live review features are preserved.

The hosted runtime is **React + Cloudflare Worker + D1**, not the retained Node/FastAPI services. Historical v25–v39 documents are retained history; statements there about missing Node approval routes or blocked frontend builds do not describe the current audited source. Production records and Site access settings were not modified. This request produces a reviewable PR; these changes have not been published or merged.

## Feature inventory

“Implemented / verified” below means the stated bounded behavior passed local checks, using synthetic records. It does not establish every policy, dataset, security property, or production deployment behavior.

| Feature | Audit classification | Evidence and practical limit |
| --- | --- | --- |
| Professional navigation, responsive layout | Implemented / verified | Current frontend builds; desktop and mobile browser checks. Preserved styling. |
| Demo stock dashboard, search, warehouse/status filters, details, CSV export | Implemented illustrative functionality | Uses five hard-coded example items, example trends/alerts, not a live item master or stock ledger. Search/details/export exercised in browser; filter logic inspected. |
| Live overview and recent review status | Implemented / verified | API and browser tests; counts describe the latest 500 accessible reviews, not the entire history or actual stock on hand. |
| ChatGPT sign-in and automatic owner initialization | Implemented; production identity unverified this audit | Synthetic dispatch headers test owner restriction, stable IDs, joining and bootstrap concurrency. Actual authentication and header stripping remain Sites dispatch responsibilities. |
| Team registration, roles, active access, entity grants/revocation | Implemented / verified locally | API covers maker/checker/admin restrictions, revocation and entity isolation; browser setup and separate identities exercised. Adding members sends no email and does not grant Site audience access. |
| CSV upload/paste and column/date/voucher mapping | Implemented / verified | Retained raw CSV must agree with normalized records. Indian date mapping, source IDs, unsupported classification and source mismatch checked. Bound: 5,000 rows, 1 MB CSV, 1.5 MB JSON. No source authenticity/completeness guarantee. |
| Saved mapping profiles | Implemented / verified | Per-user/entity persistence, duplicate names, isolated access and browser save. ERP labels identify files; they are not live connectors. |
| FIFO / moving weighted average | Implemented bounded reference policy; precision defect fixed | Opening, receipts and issues; single entity and currency; negative stock blocked. Independent rational oracle checks 86 scenarios, including every movement/closing amount. No FX, actual-cost settlement, landed cost, returns or paired transfers in the hosted engine. |
| Inventory-to-GL comparison and exception notes | Implemented / verified | Exact two-decimal arithmetic and currency isolation; CSV validation, duplicate keys, tolerance boundaries, required exception explanations and persistent reviews. Compares supplied balances, not underlying transactions. |
| Browser Control desk | Implemented / verified reference tool | Comparison, exception filtering, notes, invalidation and CSV export. Memory-only, explicitly unapproved; leaving/remounting loses its state. No server audit or approval in this separate tool. |
| Persistent source/result snapshots and integrity hashes | Implemented / verified locally | D1 emulation tests immutable evidence, source mismatch, hashes, duplicate snapshots, atomic audit writes and reopen persistence. Not a backup/restore or hosted D1 availability test. |
| Maker submission / independent checker approval and rejection | Implemented / verified locally | Recalculation, self-approval denial (including admin), optimistic versions, competing decisions, revoked grants, evidence export. A decision is not a journal posting or accounting certification. |
| Audit verification and JSON evidence downloads | Implemented / verified within bounds | Append-only triggers and linked SHA-256 events; global verification admin-only and capped at 10,000 events. Not externally signed/anchored; privileged DB administrators can alter schema. |
| Stock Reconciliation navigation | Defective route fixed | Now opens the implemented live GL workflow. Physical counts, receipt/dispatch/cut-off matching and complete operational stock reconciliation remain incomplete in the hosted product. |
| Original intercompany document matching | Retained reference implementation; not deployed in Worker | Python tests and subprocess contract run. Order-level SO/PO/packing-slip/GRN/delivery aggregation; no full ERP transaction matching or automatic adjustment. Original UI requires its separately operated API. |
| Original intercompany financial / unrealized profit | Retained bounded reference implementation | Python tests; known quantity mismatch now blocks an unsupported profit proposal. No automatic FX, tax, lot allocation or consolidation posting. Missing invoice quantities still rely on the stated matched-transfer assumption; real evidence review is required. |
| Original transaction ledger and paired transfers | Retained reference implementation / tested fixtures | FIFO/moving, negative-stock/duplicate/date checks, paired transfer cost carrying. Missing/reused references fixed. Not a shipment, receipt, ownership or ERP settlement workflow. |
| Physical count, NRV, roll-forward Python controls | Retained bounded calculations / verified examples | Quantity/value variances, write-down/reversal arithmetic and roll-forward tests pass; impossible prior allowances now rejected. No hosted transaction integration, accounting-policy approval or full Ind AS 2 certification. |
| Item masters, purchasing, sales, packing slips, deliveries, ageing, stock count workflows | Incomplete hosted product | Legacy scope pages and reference functions do not constitute operational CRUD, a complete inventory system or finished ERP integrations. |
| COGS and closing stock | Partial | Simple reference valuation/roll-forward tests pass. Full ERP cost close, adjustments, settlement, complete COGS classification and source-to-GL traceability are incomplete. Private workbook reconciliation not rerun. |
| Excel reference models | Delivered illustrative artifacts; partial verification | Download tested; ZIP/formula structure and selected corresponding calculation cases checked. Workbooks were not recalculated in Excel/LibreOffice; all formulas, datasets and accounting policies remain unverified. |
| India benchmark and capability/roadmap pages | Implemented presentation and browser interactions | Search, status/roadmap navigation, and source links retained. Vendor claims, pricing and market coverage were not independently re-researched during this audit. |
| Original Node API | Retained and tested; not hosted runtime | Typecheck and 8 end-to-end subtests (9 runner results) cover authentication, entity access, arithmetic, hash tampering, self approval, competing decisions and audit links. Uses SQLite and Python subprocesses, not the declared PostgreSQL production architecture. |
| Original FastAPI API and read-only import profiling | Retained; SQLite tests pass | Source-file HTTP exposure and shadowed import route fixed; entity checks added. Production deployment, operational hardening and PostgreSQL concurrency remain unverified. |
| PostgreSQL migrations | Source reviewed; live execution unverified | Added migration 003 to allow REJECTED, which migration 001 omitted. No PostgreSQL server was available; migration compatibility, rollback and upgrades on populated customer databases are not established. Hosted runtime uses separate Drizzle/D1 migrations. |
| Direct ERP integrations (Tally, Zoho, SAP, Dynamics, Oracle, ERPNext, Odoo, etc.) | Not configured | File mappings/system labels work; no API credentials, live synchronization or customer ERP UAT available. |
| Production security, throughput, backup/restore, monitoring, SLA, accessibility certification | Unverified / not established | Functional access tests and selected keyboard/layout behavior are not penetration testing, a full accessibility audit, load testing, incident readiness or business continuity evidence. |
| Journal posting | Deliberately absent | Reference outputs and approval decisions never post accounting journals. |

## Confirmed defects and source fixes

| ID | Confirmed problem | Fix and regression evidence |
| --- | --- | --- |
| A01 | GitHub's ZIP-only source omitted the professional live application | Imported exact Site v4 source before fixes; original ZIP retained; provenance above. |
| A02 | Decimal precision 28 rounded accepted large valuations at integer precision | New Worker policy uses precision 64 and scope v2; reference Python uses bounded precision 64. For qty `999999999999999.654321` × rate `987654321012345.123456`, v1 returned `987654321012344782044641966800.000000`; correct six-decimal result is `987654321012344782044641966773.550069`, a 26.449931 overstatement. Rational oracle is independent of both engines. |
| A03 | Changing source/policy during an in-flight calculation could display/save stale results | Revision guard discards superseded responses; browser holds the request, changes method, and proves no save button appears for the stale response. |
| A04 | Stock Reconciliation opened a scope-only legacy screen despite a working live GL tool | Routes to the live GL review workflow; browser verifies initial review type is GL. Broader operational reconciliation is still marked incomplete. |
| A05 | JSON `null`, arrays and primitive mutation bodies caused server errors | Worker rejects non-object bodies with 400; regression API cases. |
| A06 | Concurrent duplicate saves could produce an internal error after a uniqueness race | Transaction retry maps supported uniqueness collisions to 409; regression proves one draft/event and one conflict. |
| A07 | Legacy ledger accepted transfers with no reference and allowed reuse after a pair completed | Require every transfer reference and retain used references; FIFO/moving regressions and original paired-transfer tests. |
| A08 | Reference valuation pooled identical item/location balances across entities/currencies | Both retained Python entrypoints reject mixed contexts; parameterized tests. Hosted engine already enforces single context. |
| A09 | NRV accepted a prior allowance exceeding historical cost for the supplied units | Reject impossible allowance; test both invalid input and maximum valid reversal. |
| A10 | Legacy FastAPI served its project directory, exposing source/data paths and shadowing later upload APIs | Removed project-directory mount; serve built frontend only, retain service root response. HTTP tests require 404 for source/config/database paths and 401 for unauthenticated inspection. |
| A11 | Retained Node approvals did not check source-row entity/hash and could race across verification | Bind evidence rows to review entity; verify hash; compare-and-set status and audit within a transaction. Actual HTTP tests cover cross-entity evidence, tampering and competing decisions. |
| A12 | Retained React CSV parsing/sums used binary Number and omitted entity required by Node | Preserve numeric strings, decimal sums/display, explicit valuation entity; parser regression verifies long fractional input survives import. Node/Python calculations remain decimal. |
| A13 | IC profit proposal could use an invoice quantity known to differ from costed transfer quantity | Suppress proposal and report incomplete evidence for known invoice/receipt quantity mismatch; targeted financial regression. No inferred replacement profit is posted. |
| A14 | Original PostgreSQL status constraint did not permit API-supported REJECTED | Added migration 003; **source correction only, not validated against a live PostgreSQL instance**. |
| A15 | Tests used nonexistent JS paths, machine-specific TypeScript, outdated browser targets, zero Node tests and silent real-data “passes” | Portable paths, current UI browser checks, real Node tests, locked npm installs, unified runner and CI workflow. Missing private sources explicitly skip; the former silent-return reconciliation check now reports skipped. |
| A17 | Mobile example-item dialog expanded to 440px in a 390px viewport; its close button was offscreen | Constrain grid track/modal width and scrolling; browser verifies close-control bounds and closes the dialog at desktop and mobile sizes. |
| A18 | npm scan identified a high-severity Vite development-tool finding and vulnerable transitive esbuild versions | Upgraded Vite to 8.3.5, added direct esbuild 0.28.2 and a matching override for old tooling, regenerated the lockfile, and bound development/preview to loopback. Frontend/Worker builds, Drizzle metadata check and both browser suites pass. Final npm scans report 0 known advisories in both JS trees; this is not a security certification. |
| A16 | Legacy calculation endpoint lacked row entity permission checks; maker queue ignored revoked grants | Require source entity for non-admin calculations, check grants, reject cross-entity reviews, and filter maker queue by current grants. SQLite HTTP regression exercises allowed/missing/forbidden entity cases. |

## Historical evidence compatibility

No saved review input, result or hash is rewritten. Existing v1 evidence is first recomputed with its original arithmetic to check its original hash, then compared with the corrected v2 calculation. A safe historical review can still submit and receive an independent decision with its original result hash. If its rounded output differs under v2, transition returns 409 and instructs creation of a corrected review. Old evidence remains inspectable/downloadable. Local regressions cover both cases and prove that a corrected v2 replacement can be saved for the same source. The new valuation policy is included in its duplicate fingerprint. **Existing production records were not scanned**, so the number of affected saved reviews is unknown. Rejected/approved prior decisions are retained; this audit is not a retroactive certification.

## Tests and independent accounting evidence

The recorded run and command logs are under [`verification/audit/evidence/`](verification/audit/evidence/). Dependency versions, source hashes and source provenance are retained there. The runner exits nonzero on any executed failure; omitted browser checks are explicitly recorded as NOT_RUN. GitHub CI results must be observed independently; configuring a workflow does not mean it has passed remotely.

- Python suite: **98 passed, 7 skipped** in the recorded final run. Seven skips comprise six unavailable private-data checks and one retired HTML smoke test, listed below.
- Retained Node API: **9 test-runner results passed**, including 8 substantive HTTP/security/accounting subtests.
- Hosted accounting: **86 scenarios** checked against an independent Python `Fraction` oracle (no production accounting imports). Exact rational expectations are rounded only at the output boundary using half-even rounding. Cases cover FIFO/moving average, full depletion, fractional rates, multiple locations, chronological movements and the large accepted input bound. Every movement cost, closing value and aggregate metric is compared. Separate checks exercise row limit and cutoff rejection.
- Known-value examples: opening 10 × 5 + purchase 10 × 7 − issue 8 yields moving COGS 48 / closing 72 and FIFO COGS 40 / closing 80. GL 0.30 − 0.29 equals 0.01 exactly and matches a 0.01 tolerance. Stock book 10 versus count 9 at cost 20 yields −20. NRV 10 units at cost 20, selling 18 less selling cost 1 yields a proposed write-down of 30.
- Existing live API suite plus added API regressions pass synthetic identity, source mapping, permissions, workflow, persistence, hash/trigger, concurrent-decision and historical-policy checks.
- Browser monetary checks pass exact arithmetic, CSV quoting, formula escaping, duplicate keys and comparison with Python. The 25 named preserved JavaScript checks pass (10 controls, 7 settlements, 8 universal mapping checks); these do not certify archived engines at arbitrary scale/precision.
- Frontend production build, Node typecheck, Worker bundle and typecheck, Drizzle migration metadata checks, and TypeScript syntax checks pass. The metadata check does not execute PostgreSQL or hosted D1 migrations.
- npm audit: initial React tree had 5 affected packages (1 high, 4 moderate); after upgrades/override, React and Node trees each report 0 known advisories. JSON responses are retained in the evidence folder. Python dependency vulnerability scanning was not performed.
- Desktop/mobile browser checks cover current live review workflows, stale response rejection, live GL navigation, demo search/details/export, control-desk notes/exports/validation, Excel download, benchmark navigation and layout. Both suites passed; no application JavaScript errors were observed.

All **19 executed check groups** in the final local runner returned exit code 0.

The first full Python execution found **five missing-workbook failures**, not calculation failures; another real-data check was silently returning. Those environmental checks were corrected to report skips. Early browser test runs also exposed stale test selectors, which were corrected to the current UI labels. Earlier compile/test failures were repaired before the final evidence run; final logs are the current evidence, not historical release claims.

### Explicitly unverified private-data checks

1. Historical centre COGS comparison: private September/October source workbooks absent.
2. Closing-stock workbook profiling: source absent.
3. GRN workbook profiling: source absent.
4. Purchase workbook profiling: source absent.
5. Inventory movements workbook profiling: source absent.
6. Historical PO/GRN and IVR/closing reconciliation: source workbooks absent.
7. Retired legacy HTML browser smoke: intentionally skipped; current React browser suites are separate.

Set `INVENTORY_TEST_DATA_DIR` to authorized originals to rerun private-data checks. Archived output CSV/JSON files cannot substitute for original inputs or prove current arithmetic accuracy.

## Remaining limitations and release conditions

These are material limits, not passing checks: real customer source completeness/authenticity; direct ERP APIs; complete inventory operations and valuation policies; full returns, landed cost, settlement, FX and NRV; true hosted D1 concurrency/latency and migration behavior; deployed ChatGPT authentication boundaries; populated PostgreSQL migrations; load, backup/restore, monitoring and incident handling; full accessibility assessment; security/accounting certification; and retroactive inspection of existing production reviews.

The legacy services remain reference implementations with different authentication/storage and weaker operational assurance than the Worker; running them publicly requires a separate deployment/security review. The original archived browser bundle is preserved historical code, not the active application. The new CI workflow and migration have not been represented as remotely passed or deployed. Review this PR and run the relevant customer/hosted acceptance checks before a production release; merging a PR alone does not publish a new Site version.
