import pytest
from verified_gate import verify_payload
ROWS=[{'date':'2026-04-01','item':'A','location':'W','type':'OPEN','qty':'10','rate':'10'},{'date':'2026-04-02','item':'A','location':'W','type':'COGS','qty':'4'}]
def payload():return {'source_rows':ROWS,'method':'fifo','claimed_closing':'60','blocking_errors':[]}
def test_valid():assert verify_payload(payload())['valuation'][0]['value']=='60'
def test_tamper():
 p=payload();p['claimed_closing']='61'
 with pytest.raises(ValueError):verify_payload(p)
def test_missing():
 with pytest.raises(ValueError):verify_payload({'claimed_closing':'60','blocking_errors':[]})
def test_negative():
 p=payload();p['source_rows']=[dict(ROWS[1])]
 with pytest.raises(ValueError):verify_payload(p)
def test_blocking():
 p=payload();p['blocking_errors']=['unmatched']
 with pytest.raises(ValueError):verify_payload(p)
def test_metric_tamper():
 p=payload();p['reference_metrics']={'opening':'999'}
 with pytest.raises(ValueError,match='Reference metric'):verify_payload(p)
def test_nonfinite_claim():
 p=payload();p['claimed_closing']='NaN'
 with pytest.raises(ValueError,match='finite'):verify_payload(p)
def test_scope_mismatch():
 p=payload();p['verification_scope']='full_ind_as_2'
 with pytest.raises(ValueError,match='scope'):verify_payload(p)
