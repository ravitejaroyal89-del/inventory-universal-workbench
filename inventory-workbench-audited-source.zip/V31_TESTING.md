# Version 31 — regression corrections

- Restored legacy bridge test to read the archived legacy JS instead of reintroducing it into the React app.
- Updated historical IVR diagnostics test to read the archived evidence CSV.
- Isolated database state for reference API and maker–checker workflow tests.
- Marked obsolete HTML browser test as skipped, not passed; actual React browser E2E remains pending.
- Added a React/Node source-structure regression check.

The legacy FastAPI test suite is retained for compatibility; Node production integration still requires independent testing.
