import fs from 'node:fs';import path from 'node:path';import {build} from '../react/node_modules/esbuild/lib/main.js';
const map={};const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','.svg':'image/svg+xml','.md':'text/markdown; charset=utf-8'};
function walk(dir){for(const f of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,f.name);if(f.isDirectory())walk(p);else map['/'+path.relative('dist',p).split(path.sep).join('/')]={body:fs.readFileSync(p).toString('base64'),type:types[path.extname(p)]||'application/octet-stream'}}}
walk('dist');fs.writeFileSync('worker/assets.generated.ts','export const assets:Record<string,{body:string;type:string}>='+JSON.stringify(map));
fs.rmSync('deploy',{recursive:true,force:true});fs.mkdirSync('deploy/server',{recursive:true});fs.mkdirSync('deploy/.openai',{recursive:true});
await build({entryPoints:['worker/index.ts'],outfile:'deploy/server/index.js',bundle:true,format:'esm',platform:'browser',target:'es2022',minify:true});
fs.copyFileSync('.openai/hosting.json','deploy/.openai/hosting.json');fs.cpSync('drizzle','deploy/drizzle',{recursive:true});
console.log('Built deploy/server/index.js with embedded frontend assets and D1 migrations.');
