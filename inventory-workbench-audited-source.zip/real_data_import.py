"""ERP-neutral, read-only inventory workbook profiling. No valuation or journal posting."""
from __future__ import annotations
import csv, io, re, zipfile, xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
PROFILES={
 'closing_stock':{'required':['Entity Code','Item Code','Centre Code','Quantity in Stock','Total Cost'],'map':{'Entity Code':'entity','Item Code':'item','Centre Code':'centre','Quantity in Stock':'quantity','Total Cost':'amount','Valuation Method':'cost_method','Unit Price':'unit_cost'}},
 'inventory_movements':{'required':['Company Name','Item Code','Site','Date','Reference'],'map':{'Company Name':'entity','Item Code':'item','Site':'centre','Date':'posting_date','Reference':'movement_type','Inventory: Financial Quantity':'financial_quantity','Inventory: Financial Amount':'financial_amount','Inventory: Physical Quantity':'physical_quantity','Voucher':'voucher','Number':'document'}},
 'purchase_orders':{'required':['Company','Site','Purchase order','Item number'],'map':{'Company':'entity','Site':'centre','Purchase order':'purchase_order','Item number':'item','PO Date':'order_date','Vendor Account':'vendor'}},
 'goods_receipts':{'required':['EntityCode','Purchase order','Item number','Quantity','GRN Number'],'map':{'EntityCode':'entity','Purchase order':'purchase_order','Item number':'item','Quantity':'quantity','Net amount':'amount','GRN Number':'receipt','Invoice Number':'invoice'}},
 'sales_register':{'required':['Legal Entity','Item Id','Qty'],'map':{'Legal Entity':'entity','Item Id':'item','Qty':'quantity','Amount Excd. Tax':'amount','SO-Center':'centre'}},
 'cogs_detail':{'required':['Center Code','Item Code','COGS'],'map':{'Center Code':'centre','Item Code':'item','COGS':'cogs','COGS Group':'cogs_group','Category':'billing_class','Total Consumption':'quantity'}},
}
def rows_xlsx(path, sheet_index=0):
 with zipfile.ZipFile(path) as z:
  names=z.namelist(); shared=[]
  if 'xl/sharedStrings.xml' in names:
   with z.open('xl/sharedStrings.xml') as f:
    for _,e in ET.iterparse(f,events=('end',)):
     if e.tag==NS+'si':
      shared.append(''.join(t.text or '' for t in e.iter(NS+'t')));e.clear()
  target=f'xl/worksheets/sheet{sheet_index+1}.xml'
  if target not in names:raise ValueError('Worksheet XML not found')
  with z.open(target) as f:
   for _,e in ET.iterparse(f,events=('end',)):
    if e.tag!=NS+'row':continue
    row={}
    for c in e.findall(NS+'c'):
     ref=c.attrib.get('r',''); m=re.match(r'[A-Z]+',ref)
     if not m:continue
     col=0
     for char in m.group():col=col*26+ord(char)-64
     v=c.find(NS+'v'); inline=c.find(NS+'is'); value=v.text if v is not None else None
     if c.attrib.get('t')=='s' and value is not None:value=shared[int(value)]
     elif inline is not None:value=''.join(t.text or '' for t in inline.iter(NS+'t'))
     row[col-1]=value
    yield row
    e.clear()
def rows_csv(path):
 with open(path,encoding='utf-8-sig',newline='') as f:
  for values in csv.reader(f):yield dict(enumerate(values))
def profile(path, sheet_index=0, sample_limit=8):
 p=Path(path)
 if p.suffix.lower()=='.xlsx': source=rows_xlsx(p,sheet_index)
 elif p.suffix.lower()=='.csv':source=rows_csv(p)
 else:raise ValueError('Only .xlsx and .csv are supported in this importer')
 try:header_row=next(source)
 except StopIteration:raise ValueError('Empty worksheet')
 headers={i:str(v).strip() for i,v in header_row.items() if v is not None and str(v).strip()}
 hset=set(headers.values()); scores={name:len(hset.intersection(config['required'])) for name,config in PROFILES.items()}
 best=max(scores,key=scores.get); match=scores[best]; conf=PROFILES[best]
 issues=Counter(); count=0; samples=[]; seen=set(); entities=Counter(); centres=Counter(); movements=Counter()
 required_indexes={name:next((i for i,h in headers.items() if h==name),None) for name in conf['required']}
 mapped_indexes={field:next((i for i,h in headers.items() if h==name),None) for name,field in conf['map'].items()}
 for row in source:
  if not any(v is not None and str(v).strip() for v in row.values()):continue
  count+=1
  for name,idx in required_indexes.items():
   if idx is not None and (row.get(idx) is None or str(row.get(idx)).strip()==''):issues['blank_required:'+name]+=1
  entity=row.get(mapped_indexes.get('entity')) if mapped_indexes.get('entity') is not None else None
  centre=row.get(mapped_indexes.get('centre')) if mapped_indexes.get('centre') is not None else None
  if entity:entities[str(entity).strip().upper()]+=1
  if centre:centres[str(centre).strip()]+=1
  mt=row.get(mapped_indexes.get('movement_type')) if mapped_indexes.get('movement_type') is not None else None
  if mt:movements[str(mt).strip()]+=1
  if len(samples)<sample_limit:
   samples.append({field:row.get(idx) for field,idx in mapped_indexes.items() if idx is not None and row.get(idx) is not None})
 missing=[h for h in conf['required'] if h not in hset]
 if missing:issues['missing_columns']=len(missing)
 return {'file':p.name,'sheet_index':sheet_index,'rows':count,'detected_profile':best if match>=2 else 'unclassified','matched_required':match,'missing_required_columns':missing,'columns':list(headers.values()),'mapping':{field:headers[idx] for field,idx in mapped_indexes.items() if idx is not None},'issues':dict(issues),'entities':dict(entities.most_common(30)),'centre_count':len(centres),'movement_types':dict(movements.most_common(40)),'sample_mapped_rows':samples,'caution':'Structure/QA only; no stock valuation, COGS certification or reconciliation established.'}
