# Version 33 test execution

- Full Python suite: **62 passed, 1 skipped, 0 failed** (executed in this environment).
- The skipped test is the legacy browser E2E test, which cannot certify the React user workflow.
- Targeted reference and intercompany suite: **12 passed**.
- Excel reference workbook exported and confirmed to contain formula-bearing OOXML worksheets.
- React build, Node API runtime, mobile/desktop browser E2E, PostgreSQL and live ERP costing were **not** successfully verified in this release.

Do not treat this as production certification.
