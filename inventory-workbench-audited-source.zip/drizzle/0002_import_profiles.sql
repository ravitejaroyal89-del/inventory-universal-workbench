CREATE TABLE `import_profiles` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`entity` text NOT NULL,
	`name` text NOT NULL,
	`config_json` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `import_profile_owner_name` ON `import_profiles` (`owner`,`entity`,`name`);