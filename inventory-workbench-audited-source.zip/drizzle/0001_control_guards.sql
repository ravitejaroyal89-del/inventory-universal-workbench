CREATE TRIGGER live_audit_chain BEFORE INSERT ON live_audit
WHEN NEW.prev_hash <> COALESCE((SELECT hash FROM live_audit ORDER BY rowid DESC LIMIT 1),'GENESIS')
BEGIN SELECT RAISE(ABORT,'audit_chain_conflict'); END;
--> statement-breakpoint
CREATE TRIGGER live_audit_no_update BEFORE UPDATE ON live_audit
BEGIN SELECT RAISE(ABORT,'Audit events are append-only'); END;
--> statement-breakpoint
CREATE TRIGGER live_audit_no_delete BEFORE DELETE ON live_audit
BEGIN SELECT RAISE(ABORT,'Audit events are append-only'); END;
--> statement-breakpoint
CREATE TRIGGER live_review_no_delete BEFORE DELETE ON live_reviews
BEGIN SELECT RAISE(ABORT,'Review evidence cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER live_review_immutable BEFORE UPDATE ON live_reviews
WHEN NEW.input_json IS NOT OLD.input_json OR NEW.result_json IS NOT OLD.result_json OR NEW.notes_json IS NOT OLD.notes_json OR NEW.input_hash IS NOT OLD.input_hash OR NEW.result_hash IS NOT OLD.result_hash OR NEW.maker IS NOT OLD.maker OR NEW.entity IS NOT OLD.entity OR NEW.period IS NOT OLD.period OR NEW.kind IS NOT OLD.kind OR NEW.source IS NOT OLD.source OR NEW.fingerprint IS NOT OLD.fingerprint OR NEW.created_at IS NOT OLD.created_at OR NEW.id IS NOT OLD.id
BEGIN SELECT RAISE(ABORT,'Source evidence is immutable'); END;
--> statement-breakpoint
CREATE TRIGGER live_review_transition BEFORE UPDATE ON live_reviews
WHEN NEW.version <> OLD.version+1 OR NOT ((OLD.status='DRAFT' AND NEW.status='SUBMITTED' AND NEW.checker IS NULL) OR (OLD.status='SUBMITTED' AND NEW.status IN ('APPROVED','REJECTED') AND NEW.checker IS NOT NULL AND NEW.checker<>NEW.maker))
BEGIN SELECT RAISE(ABORT,'Invalid review transition or checker'); END;
--> statement-breakpoint
CREATE INDEX live_review_entity ON live_reviews(entity,created_at);
--> statement-breakpoint
CREATE INDEX live_audit_subject ON live_audit(subject);
