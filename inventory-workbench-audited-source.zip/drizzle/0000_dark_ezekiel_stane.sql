CREATE TABLE `members` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text,
	`email` text NOT NULL,
	`role` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `members_user_id_unique` ON `members` (`user_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `members_email_unique` ON `members` (`email`);--> statement-breakpoint
CREATE TABLE `entity_grants` (
	`id` text PRIMARY KEY NOT NULL,
	`member_id` text NOT NULL,
	`entity` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `grant_unique` ON `entity_grants` (`member_id`,`entity`);--> statement-breakpoint
CREATE TABLE `live_reviews` (
	`id` text PRIMARY KEY NOT NULL,
	`kind` text NOT NULL,
	`entity` text NOT NULL,
	`period` text NOT NULL,
	`maker` text NOT NULL,
	`checker` text,
	`status` text NOT NULL,
	`input_json` text NOT NULL,
	`result_json` text NOT NULL,
	`notes_json` text NOT NULL,
	`input_hash` text NOT NULL,
	`result_hash` text NOT NULL,
	`fingerprint` text NOT NULL,
	`source` text NOT NULL,
	`comment` text,
	`version` integer DEFAULT 1 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `live_reviews_fingerprint_unique` ON `live_reviews` (`fingerprint`);--> statement-breakpoint
CREATE TABLE `live_audit` (
	`id` text PRIMARY KEY NOT NULL,
	`actor` text NOT NULL,
	`action` text NOT NULL,
	`subject` text NOT NULL,
	`detail` text NOT NULL,
	`prev_hash` text NOT NULL,
	`hash` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `live_audit_prev_hash_unique` ON `live_audit` (`prev_hash`);--> statement-breakpoint
CREATE UNIQUE INDEX `live_audit_hash_unique` ON `live_audit` (`hash`);