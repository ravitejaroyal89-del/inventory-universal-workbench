import os,sys,importlib
from fastapi.testclient import TestClient

def test_entity_scoped_workflow(tmp_path,monkeypatch):
 monkeypatch.setenv('DATABASE_URL','sqlite:///'+str(tmp_path/'entity.db'))
 monkeypatch.setenv('ALLOW_BOOTSTRAP','1')
 sys.modules.pop('server',None)
 import server
 importlib.reload(server)
 c=TestClient(server.app)
 def post(path,data,t=None):return c.post('/api'+path,json=data,headers={'Authorization':'Bearer '+t} if t else {})
 def get(path,t):return c.get('/api'+path,headers={'Authorization':'Bearer '+t})
 pw='A-strong-password-2026!'
 assert post('/setup',{'username':'admin','password':pw}).status_code==200
 def token(name):return post('/login',{'username':name,'password':pw}).json()['access_token']
 admin=token('admin')
 for name,role in [('maker1','maker'),('checker1','checker'),('checker2','checker')]:
  assert post('/users',{'username':name,'password':pw,'role':role},admin).status_code==200
 maker,check1,check2=token('maker1'),token('checker1'),token('checker2')
 payload={'period':'2026-10','entity':'ENTITY_A','payload':{'sample':True}}
 assert post('/reviews',payload,maker).status_code==403
 for user in ('maker1','checker1'):
  assert post('/entity-access',{'username':user,'entity':'ENTITY_A'},admin).status_code==200
 r=post('/reviews',payload,maker)
 assert r.status_code==200,r.text
 rid=r.json()['id']
 assert get(f'/reviews/{rid}',check2).status_code==403
 assert get(f'/reviews/{rid}',check1).status_code==200
 assert get('/reviews',check2).json()['reviews']==[]
 assert any(x['id']==rid for x in get('/reviews',check1).json()['reviews'])
 assert post('/reviews',dict(payload,entity='ENTITY_B'),maker).status_code==403
 assert post('/entity-access',{'username':'checker1','entity':'ENTITY_B'},check1).status_code==403
