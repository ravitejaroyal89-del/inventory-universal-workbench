-- Retained PostgreSQL backend only; not a D1 migration.
-- 001's original status constraint omitted REJECTED although the API supports it.
BEGIN;
ALTER TABLE reviews DROP CONSTRAINT IF EXISTS reviews_status_check;
ALTER TABLE reviews ADD CONSTRAINT reviews_status_check
  CHECK (status IN ('DRAFT','SUBMITTED','APPROVED','REJECTED'));
COMMIT;
