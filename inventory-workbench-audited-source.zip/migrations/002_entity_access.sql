CREATE TABLE IF NOT EXISTS entity_access(user_id INTEGER NOT NULL, entity VARCHAR(128) NOT NULL, PRIMARY KEY(user_id,entity));
