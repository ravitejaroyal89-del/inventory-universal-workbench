from ivr_diagnostics_v16 import classify,diagnose
from pathlib import Path
import csv

def test_reference_classification():
 assert classify('Beginning balance')=='OPENING'
 assert classify('Sales order')=='SALES_REVIEW'
 assert classify('Transfer order shipment')=='TRANSFER_REVIEW'

def test_real_data_report_exists():
 p=Path(__file__).parent/'archive'/'historical_evidence'/'investigation_outputs'/'ivr_transaction_diagnostics.csv'
 with p.open(encoding='utf-8-sig',newline='') as f:
  r=csv.DictReader(f);first=next(r)
 assert first['wac_verification'].startswith('NOT_VERIFIED')
