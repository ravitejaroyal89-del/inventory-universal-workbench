"""Independent calculation checks for the published reference workbook examples."""
from decimal import Decimal
from pathlib import Path
from zipfile import ZipFile
from python_engine.reference_engine import calculate

def test_wac_reference_case():
 rows=[{'date':'2026-10-01','item':'ITEM-01','location':'C01','type':'OPEN','qty':10,'rate':5},
       {'date':'2026-10-02','item':'ITEM-01','location':'C01','type':'PURCHASE','qty':10,'rate':7},
       {'date':'2026-10-03','item':'ITEM-01','location':'C01','type':'ISSUE','qty':8,'rate':0}]
 result=calculate(rows,'moving')
 assert Decimal(result['valuation'][0]['value'])==Decimal('72')
 assert Decimal(result['metrics']['cogs'])==Decimal('48')
 assert Decimal(result['metrics']['rollforwardDifference'])==0

def test_fifo_reference_case():
 rows=[{'date':'2026-10-01','item':'ITEM-01','location':'C01','type':'OPEN','qty':10,'rate':5},
       {'date':'2026-10-02','item':'ITEM-01','location':'C01','type':'PURCHASE','qty':10,'rate':7},
       {'date':'2026-10-03','item':'ITEM-01','location':'C01','type':'ISSUE','qty':8,'rate':0}]
 result=calculate(rows,'fifo')
 assert Decimal(result['valuation'][0]['value'])==Decimal('80')
 assert Decimal(result['metrics']['cogs'])==Decimal('40')

def test_reference_workbook_contains_live_formulas():
 p=Path(__file__).parent/'excel_models/Inventory_Independent_Reference_Models.xlsx'
 with ZipFile(p) as z:
  sheets=[n for n in z.namelist() if n.startswith('xl/worksheets/sheet') and n.endswith('.xml')]
  assert len(sheets)==8
  xml=''.join(z.read(n).decode() for n in sheets)
  assert xml.count('<x:f')>=30
  assert 'MAX(0' in xml and 'IF(' in xml
