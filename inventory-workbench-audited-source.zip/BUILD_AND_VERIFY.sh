#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# First install requirements.txt, npm ci --prefix react, npm ci --prefix node_backend.
# Optional --browser requires Playwright and Chromium. Never points at the live site.
exec "${PYTHON_BIN:-python3}" verification/audit/run.py "$@"
