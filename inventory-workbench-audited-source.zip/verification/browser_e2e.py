"""Read-only UI checks against the current Worker QA harness (no real identities)."""
import os,shutil
from playwright.sync_api import sync_playwright,expect
URL=os.getenv('BASE_URL','http://127.0.0.1:4173')
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.getenv('CHROMIUM_PATH') or shutil.which('chromium'),headless=True,args=['--no-sandbox'])
    for width,height in [(1440,1050),(390,844)]:
        context=browser.new_context(viewport={'width':width,'height':height})
        context.add_cookies([{'name':'qa_user','value':'admin','url':URL}])
        page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(URL)
        def go(name):
            if width<850:page.get_by_role('button',name='Toggle navigation',exact=True).click()
            page.get_by_role('button',name=name,exact=True).click()
        go('Demo inventory')
        expect(page.locator('.inventory-card tbody tr')).to_have_count(5)
        page.get_by_label('Search inventory',exact=True).fill('copper')
        expect(page.locator('.inventory-card tbody tr')).to_have_count(1)
        page.get_by_role('button',name='View Copper wire coils',exact=True).click()
        expect(page.get_by_role('dialog')).to_contain_text('INV-003')
        close=page.get_by_role('button',name='Close item details',exact=True)
        rect=close.bounding_box();assert rect and rect['x']>=0 and rect['x']+rect['width']<=width
        close.click()
        with page.expect_download() as d:page.get_by_role('button',name='Export report',exact=True).click()
        assert 'Copper wire coils' in open(d.value.path()).read()
        go('Control desk');page.get_by_role('button',name='Load example data',exact=True).click()
        page.get_by_role('button',name='Compare balances',exact=True).click()
        expect(page.locator('.comparison-results tbody tr')).to_have_count(4)
        page.get_by_label('Show exceptions only',exact=True).check()
        expect(page.locator('.comparison-results tbody tr')).to_have_count(2)
        page.get_by_label('Investigation note 2',exact=True).fill('Independent audit example')
        with page.expect_download() as d:page.get_by_role('button',name='Export evidence',exact=True).click()
        body=open(d.value.path()).read();assert 'Independent audit example' in body and 'UNAPPROVED_BROWSER_REFERENCE' in body
        page.get_by_label('Absolute tolerance',exact=True).fill('-0.01')
        expect(page.locator('.comparison-results')).to_have_count(0)
        page.get_by_role('button',name='Compare balances',exact=True).click()
        expect(page.get_by_role('alert')).to_contain_text('nonnegative')
        go('Reports & Models')
        with page.expect_download() as d:page.get_by_role('link',name='Download Excel reference workbook',exact=True).click()
        assert open(d.value.path(),'rb').read(2)==b'PK'
        go('India benchmark')
        page.get_by_label('Search platforms',exact=True).fill('Tally')
        expect(page.locator('.benchmark-table tbody tr')).to_have_count(1)
        page.get_by_role('tab',name='Our capability status',exact=True).click()
        expect(page.locator('.capability-status')).to_contain_text('Incomplete product coverage')
        page.get_by_role('tab',name='Priority roadmap',exact=True).click()
        expect(page.locator('.roadmap-card').first).to_be_visible()
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
        assert not errors,errors
        print(f'PASS {width}px: demo search/details/export; GL comparison/notes/export/validation; Excel download; benchmark search/status/roadmap; layout; no JS errors')
        context.close()
    browser.close()
