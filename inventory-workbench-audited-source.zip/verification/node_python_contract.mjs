import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
const here=path.dirname(fileURLToPath(import.meta.url));
const cli=path.resolve(here,'../python_engine/cli.py');
function call(payload){return new Promise((resolve,reject)=>{
 const child=spawn(process.env.PYTHON_BIN||'python3',[cli],{stdio:['pipe','pipe','pipe']});
 let out='',err=''; const timeout=setTimeout(()=>child.kill('SIGKILL'),15000);
 child.stdout.on('data',b=>out+=b);child.stderr.on('data',b=>err+=b);
 child.on('error',reject);child.on('close',code=>{clearTimeout(timeout);try{resolve({code,...JSON.parse(out)})}catch(e){reject(Error(err||out||String(e)))}});
 child.stdin.end(JSON.stringify(payload));
})}
const rows=[{date:'2026-10-01',item:'TEST',location:'CENTRE',type:'OPEN',qty:10,rate:5},{date:'2026-10-02',item:'TEST',location:'CENTRE',type:'ISSUE',qty:2,rate:0}];
for(const method of ['fifo','moving']){
 const r=await call({action:'calculate',rows,method});assert.equal(r.code,0);assert.equal(r.ok,true);assert.equal(Number(r.valuation[0].qty),8);assert.equal(Number(r.valuation[0].value),40);console.log('PASS Node -> Python subprocess',method)
}
for(const action of ['intercompany_reconcile','intercompany_financial']){
 const key=action==='intercompany_reconcile'?'documents':'records';const r=await call({action,[key]:[]});assert.equal(typeof r.ok,'boolean');console.log('PASS Node -> Python response contract',action)
}
const invalid=await call({action:'unsupported'});assert.equal(invalid.ok,false);assert.equal(invalid.code,2);console.log('PASS invalid action fails closed');
