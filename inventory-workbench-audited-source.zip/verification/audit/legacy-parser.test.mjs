import assert from 'node:assert/strict';
import {build} from '../../react/node_modules/esbuild/lib/main.js';
import {mkdtempSync,rmSync} from 'node:fs';import {tmpdir} from 'node:os';import path from 'node:path';
const dir=mkdtempSync(path.join(tmpdir(),'inventory-parser-'));
try{
 await build({entryPoints:['react/src/Workbench.tsx'],outfile:dir+'/parser.mjs',bundle:true,format:'esm',platform:'node'});
 const {parseRows}=await import(dir+'/parser.mjs');
 const header='date,item,location,type,qty,rate\n';
 const rows=parseRows(header+'2026-10-01,A,W,OPEN,999999999999999.654321,987654321012345.123456\n');
 assert.equal(rows[0].qty,'999999999999999.654321');assert.equal(rows[0].rate,'987654321012345.123456');
 assert.equal(parseRows(header+'2026-10-01,A,W,ISSUE,1,\n')[0].rate,'0');
 assert.throws(()=>parseRows(header+'2026-10-01,A,W,OPEN,1,\n'));
 assert.throws(()=>parseRows(header+'2026-10-01,A,W,OPEN,1000000000000000,1\n'));
 console.log('PASS: legacy CSV preserves exact decimal strings; rejects missing inbound rates and unsupported precision; explicit zero for outbound cost input.');
}finally{rmSync(dir,{recursive:true,force:true})}
