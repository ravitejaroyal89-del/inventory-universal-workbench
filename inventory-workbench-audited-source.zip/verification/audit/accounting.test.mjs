import assert from 'node:assert/strict';
import {build} from '../../react/node_modules/esbuild/lib/main.js';
import {spawnSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
const tmp=mkdtempSync(path.join(tmpdir(),'workbench-oracle-'));
try {
 await build({entryPoints:['worker/engine.ts'],outfile:tmp+'/engine.mjs',bundle:true,format:'esm',platform:'node'});
 const {calculate}=await import(tmp+'/engine.mjs');
 const row=(id,type,qty,rate='0',location='W')=>({source_id:String(id),entity:'E1',date:'2026-10-01',item:'A',location,type,qty:String(qty),rate:String(rate)});
 const cases=[];
 for(const method of ['fifo','moving']){
  cases.push({method,currency:'INR',records:[row('large','OPEN','999999999999999.654321','987654321012345.123456')]});
  cases.push({method,currency:'INR',records:[row(1,'OPEN',10,5),row(2,'PURCHASE',10,7),row(3,'ISSUE',8)]});
  cases.push({method,currency:'INR',records:[row(1,'OPEN',3,'0.100001'),row(2,'ISSUE',3),row(3,'RECEIPT',2,'0.333333'),row(4,'CONSUMPTION',1),row(5,'ADJUST_OUT',1)]});
 }
 let seed=20261101;const random=n=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed%n};
 for(let c=0;c<80;c++){
  const records=[];let id=0;
  for(const loc of ['W1','W2']){
   let stock=10+random(40);records.push(row(++id,'OPEN',stock,`${random(1000)}.${String(random(1000000)).padStart(6,'0')}`,loc));
   for(let n=0;n<12;n++){
    if(!stock||random(2)){const q=1+random(15);stock+=q;records.push(row(++id,'PURCHASE',q,`${random(1000)}.${String(random(1000000)).padStart(6,'0')}`,loc))}
    else {const q=1+random(stock);stock-=q;records.push(row(++id,'ISSUE',q,'0',loc))}
   }
  }
  cases.push({method:c%2?'moving':'fifo',currency:'INR',records});
 }
 const oracle=spawnSync(process.env.PYTHON_BIN||'python3',['verification/audit/rational_oracle.py'],{input:JSON.stringify(cases),encoding:'utf8',timeout:20000,maxBuffer:8*1024*1024});
 assert.equal(oracle.status,0,String(oracle.error||oracle.stderr));const expected=JSON.parse(oracle.stdout);
 for(let i=0;i<cases.length;i++){
  const result=calculate('valuation',cases[i],'E1','2026-10');
  assert.deepEqual(result.metrics,expected[i].metrics,`case ${i} metrics`);
  assert.deepEqual(result.ledger.map(({source_id,movement_cost,closing_value})=>({source_id,movement_cost,closing_value})),expected[i].ledger,`case ${i} ledger`);
  assert.equal(result.journal_posted,false);
 }
 assert.throws(()=>calculate('valuation',{...cases[0],records:Array(5001).fill(cases[0].records[0])},'E1','2026-10'),/5,000/);
 assert.throws(()=>calculate('valuation',{...cases[0],records:[{...cases[0].records[0],date:'2026-11-01'}]},'E1','2026-10'),/cut-off/);
 const old=calculate('valuation',cases[0],'E1','2026-10',1);
 assert.equal(old.scope,'simple_fifo_moving_v1');assert.equal(old.metrics.closing,'987654321012344782044641966800.000000');
 assert.equal(calculate('valuation',cases[0],'E1','2026-10').metrics.closing,'987654321012344782044641966773.550069');
 console.log(`PASS: ${cases.length} independent rational FIFO/moving-average scenarios, every movement/closing value, high-magnitude bounds, depletion, fractional rates, locations, legacy replay, and no posting.`);
} finally {rmSync(tmp,{recursive:true,force:true})}
