import assert from 'node:assert/strict';
import {build} from '../../react/node_modules/esbuild/lib/main.js';
import {openDB} from '../d1-local.mjs';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
const tmp=mkdtempSync(path.join(tmpdir(),'workbench-api-audit-'));
const db=openDB();
try{
 await build({entryPoints:['worker/api.ts','worker/engine.ts'],outdir:tmp,bundle:true,platform:'node',format:'esm',outExtension:{'.js':'.mjs'}});
 const {api}=await import(tmp+'/api.mjs');const {calculate,canonical,sha}=await import(tmp+'/engine.mjs');
 const env={DB:db,WORKSPACE_OWNER_EMAIL:'admin@example.test'};
 async function call(path,body,user='admin',expected=200){const r=await api(new Request('http://local/api/live'+path,{method:body===undefined?'GET':'POST',headers:{origin:'http://local','content-type':'application/json','oai-authenticated-user-id':user,'oai-authenticated-user-email':user+'@example.test'},...(body===undefined?{}:{body:JSON.stringify(body)})}),env);const data=await r.json();assert.equal(r.status,expected,JSON.stringify(data));return data}
 await call('/join',{});const checker=await call('/members',{email:'checker@example.test',role:'checker'},'admin',201);await call('/join',{},'checker');await call('/grants',{member_id:checker.id,entity:'E1'});
 for(const body of [null,[],true,'bad',42])await call('/calculate',body,'admin',400);
 const record={entity:'E1',source_id:'A',date:'2026-10-01',item:'A',location:'W',type:'OPEN',qty:'10',rate:'5'};
 const input={currency:'INR',method:'fifo',records:[record]};const payload={kind:'valuation',entity:'E1',period:'2026-10',source:'Independent audit fixture',notes:{},input};
 // Duplicate concurrent requests produce exactly one draft, one creation event, and a conflict.
 const duplicate=await Promise.allSettled([call('/reviews',payload,'admin',201),call('/reviews',payload,'admin',409)]);for(const r of duplicate)assert.equal(r.status,'fulfilled',String(r.reason));
 assert.equal(db.sqlite.prepare("SELECT COUNT(*) n FROM live_audit WHERE action='CREATE_REVIEW'").get().n,1);
 // Old evidence retains its exact serialized result and creation hash. A safe v1 review can proceed.
 async function historical(id,qty,rate){const oldInput={...input,records:[{...record,source_id:id,qty,rate}]};const result=calculate('valuation',oldInput,'E1','2026-10',1);const input_json=canonical(oldInput),result_json=canonical(result),input_hash=await sha(input_json),result_hash=await sha(result_json),notes={};const maker=(await call('/session')).member.id;const at=new Date().toISOString();
 db.sqlite.prepare("INSERT INTO live_reviews(id,kind,entity,period,maker,status,input_json,result_json,notes_json,input_hash,result_hash,fingerprint,source,version,created_at,updated_at) VALUES(?,'valuation','E1','2026-10',?,'DRAFT',?,?,?,?,?,?,?,1,?,?)").run(id,maker,input_json,result_json,canonical(notes),input_hash,result_hash,await sha(canonical(['E1','2026-10','valuation',input_hash])),payload.source,at,at);
 const prev=db.sqlite.prepare('SELECT hash FROM live_audit ORDER BY rowid DESC LIMIT 1').get().hash;
 const detail=canonical({evidence_hash:await sha(canonical({entity:'E1',period:'2026-10',kind:'valuation',input_hash,result_hash,source:payload.source,notes}))});const hash=await sha(canonical([prev,maker,'CREATE_REVIEW',id,detail,at]));
 db.sqlite.prepare('INSERT INTO live_audit VALUES(?,?,?,?,?,?,?,?)').run(crypto.randomUUID(),maker,'CREATE_REVIEW',id,detail,prev,hash,at);return result_hash;
 }
 const safe=crypto.randomUUID(),bad=crypto.randomUUID();const hash=await historical(safe,'10','5');
 await call('/reviews/'+safe+'/submit',{version:1});await call('/reviews/'+safe+'/approve',{version:2,comment:'Independent historical evidence review'},'checker');
 assert.equal((await call('/reviews/'+safe)).result_hash,hash);
 await historical(bad,'999999999999999.654321','987654321012345.123456');
 const rejected=await call('/reviews/'+bad+'/submit',{version:1},'admin',409);assert.match(rejected.detail,/corrected precision/);
 assert.equal((await call('/reviews/'+bad)).status,'DRAFT');
 const correctedInput={...input,records:[{...record,source_id:bad,qty:'999999999999999.654321',rate:'987654321012345.123456'}]};
 const correction=await call('/reviews',{...payload,input:correctedInput},'admin',201);
 await call('/reviews/'+correction.id+'/submit',{version:1});
 assert.equal((await call('/reviews/'+correction.id)).result.scope,'simple_fifo_moving_v2');
 assert.equal((await call('/audit')).valid,true);
 console.log('PASS: malformed JSON types rejected, concurrent duplicates atomic/conflicted, safe historical hashes preserved, affected v1 valuations blocked and corrected replacements accepted, audit chain verified.');
}finally{db.sqlite.close();rmSync(tmp,{recursive:true,force:true})}
