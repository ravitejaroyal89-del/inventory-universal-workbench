"""Independent rational arithmetic oracle; imports no application accounting code."""
import json, sys
from fractions import Fraction as F
from decimal import Decimal, localcontext, ROUND_HALF_EVEN

def fixed(v):
    with localcontext() as c:
        c.prec=100
        return format((Decimal(v.numerator)/Decimal(v.denominator)).quantize(Decimal('.000001'),rounding=ROUND_HALF_EVEN),'f')

def calculate(case):
    states={};opening=receipts=issues=F(0);ledger=[]
    incoming={'OPEN','PURCHASE','RECEIPT','ADJUST_IN'}
    rows=sorted(enumerate(case['records']),key=lambda x:(x[1]['date'],x[1]['type']!='OPEN',x[0]))
    for _,r in rows:
        key=(r['item'],r['location']);s=states.setdefault(key,{'qty':F(0),'value':F(0),'layers':[]})
        q=F(r['qty'])
        if r['type'] in incoming:
            rate=F(r['rate']);cost=q*rate;s['qty']+=q;s['value']+=cost;s['layers'].append([q,rate])
            if r['type']=='OPEN':opening+=cost
            else:receipts+=cost
        else:
            assert q<=s['qty']
            if case['method']=='moving':cost=q*s['value']/s['qty']
            else:
                remaining=q;cost=F(0)
                while remaining:
                    take=min(s['layers'][0][0],remaining);cost+=take*s['layers'][0][1];s['layers'][0][0]-=take;remaining-=take
                    if not s['layers'][0][0]:s['layers'].pop(0)
            s['qty']-=q;s['value']-=cost;issues+=cost
        ledger.append({'source_id':r['source_id'],'movement_cost':fixed(cost),'closing_value':fixed(s['value'])})
    return {'ledger':ledger,'metrics':{k:fixed(v) for k,v in {'opening':opening,'receipts':receipts,'issues':issues,'closing':sum((s['value'] for s in states.values()),F(0)),'rollforwardDifference':F(0)}.items()}}
print(json.dumps([calculate(case) for case in json.load(sys.stdin)]))
