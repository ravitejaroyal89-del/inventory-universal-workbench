"""Run auditable checks without masking failures. --browser uses synthetic QA identities."""
import argparse,json,os,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parents[2];os.chdir(root)
parser=argparse.ArgumentParser();parser.add_argument('--browser',action='store_true');args=parser.parse_args()
artifacts=Path(os.environ.get('AUDIT_ARTIFACT_DIR',root/'.audit-artifacts')).resolve();artifacts.mkdir(parents=True,exist_ok=True)
env={**os.environ,'PYTHON_BIN':sys.executable,'AUDIT_ARTIFACT_DIR':str(artifacts/'browser')}
checks=[
 ('python',[sys.executable,'-m','pytest','-q','-ra']),
 ('frontend-build',['npm','--prefix','react','run','build']),
 ('node-typecheck',['npm','--prefix','node_backend','run','check']),
 ('node-api',['npm','--prefix','node_backend','test']),
 ('worker-build',['node','scripts/build-worker.mjs']),
 ('worker-typecheck',['node','react/node_modules/typescript/bin/tsc','--noEmit','--module','esnext','--moduleResolution','bundler','--target','ES2022','--lib','DOM,ES2022','--skipLibCheck','worker/api.ts','worker/index.ts','worker/engine.ts']),
 ('migration-metadata',['node','react/node_modules/drizzle-kit/bin.cjs','check','--config','drizzle.config.cjs']),
 ('typescript-syntax',['node','verification/typescript_syntax.mjs']),
 ('browser-monetary',['node','verification/test_browser_reconciliation.cjs']),
 ('python-contract',['node','verification/node_python_contract.mjs']),
 ('independent-rational-oracle',['node','verification/audit/accounting.test.mjs']),
 ('legacy-csv-parser',['node','verification/audit/legacy-parser.test.mjs']),
 ('live-api',['node','verification/live-api.test.mjs']),
 ('api-regressions',['node','verification/audit/api-regressions.test.mjs']),
 *[(f'archived-{n}',['node',f'test_{n}.js']) for n in ['controls','settlements','universal']]
]
results=[]
def run(name,command):
    start=time.monotonic()
    try:
        r=subprocess.run(command,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
        code,output=r.returncode,r.stdout
    except subprocess.TimeoutExpired as e:code,output=124,str(e)
    (artifacts/(name+'.txt')).write_text(output)
    results.append(dict(check=name,command=command,exit_code=code,seconds=round(time.monotonic()-start,2),log=name+'.txt'))
    print(('PASS' if code==0 else 'FAIL')+': '+name,flush=True)
for name,command in checks:run(name,command)
if args.browser and not any(r['exit_code'] for r in results):
    with tempfile.TemporaryDirectory(prefix='inventory-browser-') as tmp:
        with (artifacts/'browser-server.txt').open('w') as log:
            server=subprocess.Popen(['node','verification/local-live-server.mjs'],env={**env,'QA_DB_PATH':tmp+'/qa.db'},stdout=log,stderr=subprocess.STDOUT)
            try:
                for _ in range(50):
                    try:
                        with urllib.request.urlopen('http://127.0.0.1:4173/api/live/health',timeout=1) as r:assert r.status==200
                        break
                    except Exception:
                        if server.poll() is not None:raise RuntimeError('QA server exited; see browser-server.txt')
                        time.sleep(.1)
                run('browser-live',[sys.executable,'verification/live-browser.py'])
                run('browser-ui',[sys.executable,'verification/browser_e2e.py'])
            finally:server.terminate();server.wait(timeout=10)
else:
    results.append(dict(check='browser',status='NOT_RUN',reason='Pass --browser with Playwright and Chromium installed.'))
(artifacts/'summary.json').write_text(json.dumps({'results':results},indent=2))
sys.exit(1 if any(r.get('exit_code',0) for r in results) else 0)
