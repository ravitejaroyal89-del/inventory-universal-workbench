#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node verification/typescript_syntax.mjs
node verification/node_python_contract.mjs
python -m pytest -q test_intercompany_v27.py test_intercompany_financial_v28.py test_python_subprocess_v30.py
if [ -d react/node_modules ]; then (cd react && npm run build); else echo 'BLOCKED: React build requires npm install'; fi
if [ -d node_backend/node_modules ]; then (cd node_backend && npm run check); else echo 'BLOCKED: Node typecheck requires npm install'; fi
