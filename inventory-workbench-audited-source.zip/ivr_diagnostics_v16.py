"""Source-aware IVR diagnostic; DOES NOT certify weighted-average cost or COGS."""
from collections import defaultdict,Counter
from decimal import Decimal
from pathlib import Path
import csv,json,sys
from real_reconciliation import records,num,norm,key

def classify(ref):
 r=norm(ref)
 if 'BEGINNING BALANCE' in r or 'OPENING' in r:return 'OPENING'
 if 'TRANSFER' in r:return 'TRANSFER_REVIEW'
 if 'PURCHASE' in r:return 'PURCHASE_REVIEW'
 if 'SALES' in r:return 'SALES_REVIEW'
 if 'MOVEMENT' in r or 'ADJUST' in r:return 'ADJUSTMENT_REVIEW'
 if 'COUNT' in r:return 'COUNT_REVIEW'
 if 'PRODUCTION' in r:return 'PRODUCTION_REVIEW'
 return 'OTHER_REVIEW'

def diagnose(source,out):
 out=Path(out);out.mkdir(parents=True,exist_ok=True)
 groups=defaultdict(lambda:{'count':0,'opening_qty':Decimal(0),'opening_amount':Decimal(0),'net_qty':Decimal(0),'net_amount':Decimal(0),'zero_qty_nonzero_amount':0,'zero_qty_amount':Decimal(0),'missing_date':0,'types':Counter(),'qty_sources':Counter(),'negative_balance_events':0,'missing_cost_evidence':0})
 types=Counter();source_rows=0
 for r in records(source):
  k=key(r.get('Company Name'),r.get('Site'),r.get('Item Code'))
  if not all(k) or norm(r.get('Reference'))=='GRAND TOTAL':continue
  source_rows+=1
  g=groups[k];g['count']+=1
  kind=classify(r.get('Reference'));types[kind]+=1;g['types'][kind]+=1
  qty=num(r.get('Inventory: Quantity'));amount=num(r.get('Inventory: Amount'))
  g['net_qty']+=qty;g['net_amount']+=amount
  if kind=='OPENING':g['opening_qty']+=qty;g['opening_amount']+=amount
  if qty==0 and amount!=0:g['zero_qty_nonzero_amount']+=1;g['zero_qty_amount']+=amount
  if not r.get('Date'):g['missing_date']+=1
  g['qty_sources'][norm(r.get('Qty / Amount Source'))]+=1
  if r.get('Inventory: Financial Quantity') in (None,'') or r.get('Inventory: Financial Amount') in (None,''):g['missing_cost_evidence']+=1
 output=[];flags=Counter()
 for k,g in sorted(groups.items()):
  problems=[]
  if g['zero_qty_nonzero_amount']:problems.append('VALUE_WITH_ZERO_QUANTITY')
  if g['net_qty']<0:problems.append('NEGATIVE_NET_QUANTITY_REVIEW')
  if not g['types']['OPENING']:problems.append('OPENING_BALANCE_NOT_IDENTIFIED')
  if g['missing_cost_evidence']:problems.append('MISSING_FINANCIAL_COST_FIELDS')
  if g['missing_date']:problems.append('MISSING_TRANSACTION_DATE')
  for p in problems:flags[p]+=1
  output.append({'entity':k[0],'centre':k[1],'item':k[2],'transaction_rows':g['count'],'opening_qty':str(g['opening_qty']),'opening_amount':str(g['opening_amount']),'reported_net_qty':str(g['net_qty']),'reported_net_amount':str(g['net_amount']),'zero_qty_value_rows':g['zero_qty_nonzero_amount'],'zero_qty_value_amount':str(g['zero_qty_amount']),'reference_classes':json.dumps(dict(g['types']),sort_keys=True),'flags':';'.join(problems),'wac_verification':'NOT_VERIFIED: transaction financial/physical settlement semantics and opening cost layers must be established'})
 with (out/'ivr_transaction_diagnostics.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(output[0]) if output else ['entity','centre','item']);w.writeheader();w.writerows(output)
 summary={'source_transaction_rows':source_rows,'item_centre_keys':len(output),'reference_class_counts':dict(types),'flagged_key_counts':dict(flags),'critical_caution':'Summing inventory financial and physical amounts can double count or misstate valuation. Value-only postings with zero quantity are common. No weighted-average, COGS or closing stock certification is claimed.'}
 (out/'IVR_DIAGNOSTIC_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 return summary
if __name__=='__main__':print(json.dumps(diagnose(sys.argv[1],sys.argv[2]),indent=2))
