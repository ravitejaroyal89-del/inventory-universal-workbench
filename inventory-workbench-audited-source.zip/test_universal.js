const assert=require('node:assert/strict'),u=require('./archive/legacy_frontend/universal.js');let passed=0;function test(n,f){f();passed++;console.log('PASS',n)}
test('SAP mapping',()=>assert.equal(u.suggest(['Material','Posting Date','Quantity'],'SAP').item,'Material'));
test('Tally mapping',()=>assert.equal(u.suggest(['Stock Item','Godown'],'TallyPrime').location,'Godown'));
test('landed cost allocation',()=>{let x=u.normalize([{Item:'A',Date:'2026-10-01',Type:'PURCHASE',Qty:10,Rate:100,Freight:50}],{item:'Item',date:'Date',type:'Type',qty:'Qty',rate:'Rate',landed_cost:'Freight'});assert.equal(x.rows[0].rate,105)});
test('invalid input flagged',()=>assert.equal(u.normalize([{Item:'A',Date:'2026-10-01',Type:'COGS',Qty:'bad'}],{item:'Item',date:'Date',type:'Type',qty:'Qty'}).errors.length,1));
test('matching ERP',()=>assert.equal(u.compare([{item:'A',location:'WH',qty:3,net:30}],[{item:'A',location:'WH',qty:3,value:30}])[0].status,'MATCH'));
test('quantity variance',()=>assert.equal(u.compare([{item:'A',location:'WH',qty:3,net:30}],[{item:'A',location:'WH',qty:4,value:30}])[0].status,'REVIEW'));
test('NRV draft only',()=>assert.equal(u.journals({write:50})[0].amount,50));
test('unapproved evidence',()=>assert.equal(u.evidence([],{}).approved,false));
console.log(passed+' tests passed');
