# Version 29 — Node authentication, maker-checker and entity authorization

## Implemented
- Node/TypeScript built-in SQLite auth store, scrypt password hashing, random bearer sessions stored as SHA-256 hashes, eight-hour expiry and logout.
- Admin-only user creation and entity grants; maker/checker/admin roles.
- Authentication required on valuation, document reconciliation and financial reconciliation endpoints.
- Every intercompany row must carry both entity identifiers and caller must have permission for both; admin can access all entities.
- Review draft, owner-only submit, checker/admin decision, separation of duties, decision comment and hash-chain audit verification.
- Python valuation engine recomputes claimed closing value at submit and approve; no automatic journal posting.
- React frontend labels and warnings updated to match new backend.

## Verification
- Nine existing intercompany Python tests passed.
- npm install --offline failed (missing @types/cors from npm cache), so TypeScript compilation, Node API runtime and React browser tests remain **unverified**.
- No live PostgreSQL integration: Node's built-in SQLite is a local-development interim store, not the requested production PostgreSQL.
- Financial reconciliation remains evidence-based, not certified actual ERP costing or consolidation accounting.

## Run locally (Node 22+)
1. In `node_backend`, run `npm install`, then `npm run check` and `npm run dev`.
2. For first-time setup, start Node with `ALLOW_BOOTSTRAP=1` and a private `AUTH_DB_PATH` location; create an admin with a password of 12+ characters, then restart with `ALLOW_BOOTSTRAP=0`.
3. Start React with `cd react && npm install && npm run dev`; configure Vite proxy to Node API.
4. Grant maker/checker permissions for both selling and buying entities before importing intercompany data.
5. Never expose this release to the public Internet without HTTPS, production database migration, rate limiting for authentication endpoints, stronger session management, full E2E tests and security review.

## Remaining
- Live TypeScript compilation and browser end-to-end testing.
- Production PostgreSQL migration, operational backup and migrations.
- Production authentication hardening (login-specific throttling, password reset, secure cookie strategy, CSRF when using cookies, secrets management).
- Financial evidence audit sign-off, accounting validation against actual ERP, cross-period/FX/NRV/UPI elimination controls and user acceptance testing.
