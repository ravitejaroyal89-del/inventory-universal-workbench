from pathlib import Path

def test_bridge_submits_source_and_server_reference():
    s=(Path(__file__).parent/'archive'/'legacy_frontend'/'bridge.js').read_text()
    assert "'/reference-calculate'" in s
    assert 'source_rows,method,claimed_closing,blocking_errors:[]' in s
    assert 'server approval for transfers' in s
    assert "'/reviews','POST'" in s
