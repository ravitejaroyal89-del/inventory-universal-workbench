# Inventory Universal Workbench — GitHub and Codex

This package contains the **Version 39 development source** with its original folder structure, extracted and arranged at repository root. It is **not** a verified production build.

## Repository
Upload the **contents** of this folder to your private `inventory-universal-workbench` GitHub repository. Do not upload only this ZIP. On iPhone, GitHub's browser upload does not reliably preserve nested directories; a computer with Git is the recommended way to upload the whole project.

### Recommended upload using a computer with Git installed

1. Clone your private GitHub repository using its HTTPS clone URL.
2. Copy all files and directories from this package into the cloned repository root (retain folder names).
3. Check for secrets and real patient, customer, vendor, employee or company financial data before committing.
4. Run `git add .`, `git commit -m "Import Inventory Workbench v39 source"`, then `git push origin main`.
5. Connect this repository in Codex Cloud and request full build and test verification.

## Codex prompt

Inspect the existing repository and preserve its full-inventory-only scope. Install npm dependencies for `react` and `node_backend`, run production builds and tests, fix integration and 501 approval endpoints, verify Python tests, PostgreSQL migrations, security, maker-checker, independent Excel models, and mobile/desktop E2E. Do not claim success without actual logs; do not post accounting journals automatically. Produce a defects and blockers report.

## Known limitations as of v39

React/Node production builds were blocked by npm registry connectivity in the previous environment. PostgreSQL and browser E2E were not verified. Some approval actions were placeholders.
