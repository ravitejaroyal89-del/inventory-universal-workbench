"""Independent deterministic moving-average reference and guarded real-export evidence bridge.
Never infer physical issues from zero-quantity financial postings.
"""
from decimal import Decimal, InvalidOperation
from collections import defaultdict, Counter
from pathlib import Path
import csv, json, sys
from real_reconciliation import records, norm, key

def D(value):
    try:
        v=Decimal(str(value).strip().replace(',',''))
        if not v.is_finite(): raise ValueError('non-finite amount')
        return v
    except (InvalidOperation,ValueError,TypeError): raise ValueError('invalid numeric evidence: '+str(value))

def moving_average(events):
    """Signed receipt/issue quantities, receipt costs positive; ordered events.
    Value-only adjustments and negative stock are blocked, not estimated.
    """
    qty=Decimal(0); value=Decimal(0); issues=Decimal(0); journal=[]
    for i,event in enumerate(events):
        typ=event['type']; q=D(event['quantity'])
        if typ=='OPENING':
            if i!=0 or q<0:raise ValueError('opening must be first and nonnegative')
            qty=q;value=D(event['value']);
            if value<0:raise ValueError('negative opening value')
        elif typ=='RECEIPT':
            if q<=0:raise ValueError('receipt quantity must be positive')
            v=D(event['value'])
            if v<0:raise ValueError('negative receipt cost')
            qty+=q;value+=v
        elif typ=='ISSUE':
            if q<=0 or q>qty:raise ValueError('issue exceeds available inventory or invalid quantity')
            cost=(value/qty)*q
            qty-=q;value-=cost;issues+=cost
            if qty==0:value=Decimal(0)
        else:raise ValueError('unsupported event: '+str(typ))
        journal.append({'type':typ,'quantity':str(q),'running_qty':str(qty),'running_value':str(value),'unit_cost':str(value/qty) if qty else '0'})
    return {'closing_quantity':str(qty),'closing_value':str(value),'issue_cost':str(issues),'trace':journal}

def audit_real_ivr(path, output):
    """Do not compute unverifiable WAC; produce an item-level completeness gate."""
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    groups=defaultdict(lambda:{'rows':0,'opening':0,'opening_qty':Decimal(0),'opening_value':Decimal(0),'zero_qty_value':0,'other_movement':0,'missing_date':0,'missing_financial_qty':0,'negative_qty':0,'source_classes':Counter()})
    for r in records(path):
        k=key(r.get('Company Name'),r.get('Site'),r.get('Item Code'))
        if not all(k) or norm(r.get('Reference'))=='GRAND TOTAL':continue
        g=groups[k];g['rows']+=1;ref=norm(r.get('Reference'))
        q=D(r.get('Inventory: Quantity') or '0');v=D(r.get('Inventory: Amount') or '0')
        g['source_classes'][ref]+=1
        if 'BEGINNING BALANCE' in ref or 'OPENING' in ref:
            g['opening']+=1;g['opening_qty']+=q;g['opening_value']+=v
        else:g['other_movement']+=1
        if q==0 and v!=0:g['zero_qty_value']+=1
        if q<0:g['negative_qty']+=1
        if r.get('Inventory: Financial Quantity') in ('',None):g['missing_financial_qty']+=1
        if r.get('Date') in ('',None):g['missing_date']+=1
    rows=[];summary=Counter()
    for k,g in sorted(groups.items()):
        blockers=[]
        if g['opening']!=1:blockers.append('OPENING_BALANCE_UNCONFIRMED')
        if g['zero_qty_value']:blockers.append('VALUE_ONLY_POSTINGS_REQUIRE_SETTLEMENT_POLICY')
        if g['missing_date']:blockers.append('DATE_MISSING')
        if g['missing_financial_qty']:blockers.append('FINANCIAL_QUANTITY_MISSING')
        if g['negative_qty']:blockers.append('SIGNED_ISSUE_AND_RETURN_MAPPING_REQUIRED')
        # Even apparently clean rows need validated ERP source classification, sequence, physical/financial semantics.
        blockers.append('MOVEMENT_CLASSIFICATION_AND_POSTING_SEMANTICS_NOT_APPROVED')
        for b in blockers:summary[b]+=1
        rows.append({'entity':k[0],'centre':k[1],'item':k[2],'source_rows':g['rows'],'opening_rows':g['opening'],'opening_qty':str(g['opening_qty']),'opening_value':str(g['opening_value']),'zero_qty_value_rows':g['zero_qty_value'],'negative_quantity_rows':g['negative_qty'],'status':'BLOCKED_UNVERIFIED_WAC','blockers':';'.join(blockers)})
    with (out/'wac_evidence_gates.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['entity','centre','item','status']);w.writeheader();w.writerows(rows)
    report={'item_centre_keys':len(rows),'blocker_key_counts':dict(summary),'independent_wac_reference_engine':'IMPLEMENTED_AND_TESTED_WITH_DETERMINISTIC_EVENTS','real_erp_wac_recalculation':'BLOCKED_PENDING_SOURCE_TRANSACTION_SEMANTICS','financial_certification':'NOT_CERTIFIED'}
    (out/'WAC_EVIDENCE_SUMMARY.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report

def cogs_bridge(cogs_csv, ivr_gates_csv, out):
    """Centre-level completeness bridge, not a claim that inventory issues match COGS."""
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    counts=Counter()
    with open(ivr_gates_csv,encoding='utf-8-sig',newline='') as f:
        for row in csv.DictReader(f):counts[(row['entity'],row['centre'])]+=1
    rows=[]
    with open(cogs_csv,encoding='utf-8-sig',newline='') as f:
        for r in csv.DictReader(f):
            centre=norm(r['centre']);matches=[(e,c,n) for (e,c),n in counts.items() if norm(c)==centre]
            rows.append({'period':r['period'],'cogs_centre':centre,'reported_actual_components':r['dialysis_actual_components'],'reported_provision':r['dialysis_provision_reported'],'reported_total':r['dialysis_total_reported'],'inventory_item_centre_keys_with_same_centre':sum(n for _,_,n in matches),'inventory_entities_with_same_centre':';'.join(sorted({e for e,_,_ in matches})),'inventory_issues_independently_costed':'NO','bridge_status':'BLOCKED_SOURCE_MAPPING_OR_CUTOFF' if not matches else 'MATCHED_CENTRE_ONLY_NOT_COST_VERIFIED','limitation':'Inventory IVR movement-to-issue and accounting period mapping unapproved; cannot compare values or claim COGS agreement'})
    with (out/'inventory_to_cogs_evidence_bridge.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['period','cogs_centre']);w.writeheader();w.writerows(rows)
    summary={'cogs_centre_period_rows':len(rows),'centre_period_rows_with_matching_ivr_centre':sum(r['inventory_item_centre_keys_with_same_centre']>0 for r in rows),'independent_issues_vs_cogs':'NOT_VERIFIED','reason':'Centre identifiers alone do not prove common period, entity, transaction type or cost basis'}
    (out/'COGS_BRIDGE_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    return summary
if __name__=='__main__':
    root=Path(sys.argv[1]); out=Path(sys.argv[2]);print(json.dumps({'wac':audit_real_ivr(root/'Consol_IVR_Inventory_Oct_2026_All_Entities (2).xlsx',out),'cogs':cogs_bridge(out.parent/'cogs_outputs'/'cogs_centre_comparison.csv',out/'wac_evidence_gates.csv',out)},indent=2))
